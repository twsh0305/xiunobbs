# SMTP邮件配置

<cite>
**本文档引用的文件**
- [smtp.conf.php](file://conf/smtp.conf.php)
- [smtp.func.php](file://model/smtp.func.php)
- [setting.php](file://admin/route/setting.php)
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php)
- [bbs_admin.php](file://lang/zh-cn/bbs_admin.php)
- [conf.default.php](file://conf/conf.default.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)
10. [附录](#附录)

## 简介
本文件面向XiunoBBS 4.0的管理员与运维人员，提供SMTP邮件配置的完整说明。内容涵盖：
- SMTP服务器配置参数详解（邮件服务器地址、端口、用户名、密码等）
- 多SMTP配置的管理与切换
- SSL/TLS加密与安全连接设置
- 邮件发送测试与故障诊断
- 常见邮件服务商的配置示例

## 项目结构
围绕SMTP配置的关键文件分布如下：
- 配置存储：conf/smtp.conf.php（运行时配置文件）
- 配置模型：model/smtp.func.php（增删改查与持久化）
- 管理界面：admin/view/htm/setting_smtp.htm（表格化配置界面）
- 管理路由：admin/route/setting.php（接收表单提交并写入配置）
- 邮件发送：xiunophp/xn_send_mail.func.php（封装PHPMailer，负责实际发送）
- 语言资源：lang/zh-cn/bbs_admin.php（界面文案）
- 默认配置：conf/conf.default.php（系统默认项）

```mermaid
graph TB
AdminUI["管理界面<br/>setting_smtp.htm"] --> AdminRoute["管理路由<br/>admin/route/setting.php"]
AdminRoute --> ModelSMTP["SMTP模型<br/>model/smtp.func.php"]
ModelSMTP --> ConfFile["配置文件<br/>conf/smtp.conf.php"]
AdminRoute --> Lang["语言资源<br/>lang/zh-cn/bbs_admin.php"]
SendFunc["邮件发送函数<br/>xn_send_mail.func.php"] --> PHPMailer["PHPMailer类<br/>SMTP发送"]
```

图表来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L12-L50)
- [setting.php](file://admin/route/setting.php#L64-L108)
- [smtp.func.php](file://model/smtp.func.php#L44-L70)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3367-L3415)

章节来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L1-L117)
- [setting.php](file://admin/route/setting.php#L64-L108)
- [smtp.func.php](file://model/smtp.func.php#L51-L70)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3367-L3415)

## 核心组件
- SMTP配置模型
  - 提供创建、更新、读取、删除、查找、计数、最大ID等操作
  - 使用文件系统持久化，配置文件为conf/smtp.conf.php
- 管理界面
  - 表格形式展示多条SMTP配置，支持动态增删
  - 提交后由管理路由写入配置文件
- 邮件发送函数
  - 封装PHPMailer，支持SMTP发送、认证、超时、字符集、编码等
  - 提供调试开关，便于问题定位

章节来源
- [smtp.func.php](file://model/smtp.func.php#L7-L91)
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L12-L50)
- [setting.php](file://admin/route/setting.php#L82-L108)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3367-L3415)

## 架构总览
SMTP配置采用“界面-路由-模型-文件”的分层设计：
- 界面层：表格化配置，支持多行输入
- 路由层：接收POST数据，组装数组并写入配置文件
- 模型层：对配置数组进行增删改查与持久化
- 发送层：调用邮件发送函数，按需选择SMTP配置进行发送

```mermaid
sequenceDiagram
participant Admin as "管理员"
participant UI as "设置页面(setting_smtp.htm)"
participant Route as "管理路由(setting.php)"
participant Model as "SMTP模型(smtp.func.php)"
participant Conf as "配置文件(conf/smtp.conf.php)"
participant Mail as "邮件发送(xn_send_mail.func.php)"
Admin->>UI : 打开SMTP设置页面
UI->>Route : 提交表单(多行配置)
Route->>Model : 组装配置数组
Model->>Conf : 写入配置文件
Route-->>Admin : 返回保存成功
Admin->>Mail : 触发邮件发送(选择某条SMTP配置)
Mail-->>Admin : 返回发送结果/错误信息
```

图表来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L12-L50)
- [setting.php](file://admin/route/setting.php#L82-L108)
- [smtp.func.php](file://model/smtp.func.php#L44-L49)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3367-L3415)

## 详细组件分析

### SMTP配置参数说明
- email：发件邮箱地址（用于设置From与Reply-To）
- host：SMTP服务器地址（支持域名或IP）
- port：SMTP服务器端口（常用25、465、587）
- user：SMTP认证用户名
- pass：SMTP认证密码

章节来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L17-L32)
- [bbs_admin.php](file://lang/zh-cn/bbs_admin.php#L82-L86)

### 多SMTP配置管理
- 界面支持动态新增与删除行，每行对应一个SMTP配置对象
- 路由层将表单数组转换为配置数组并写入conf/smtp.conf.php
- 模型层提供查找、计数、最大ID等辅助能力

```mermaid
flowchart TD
Start(["进入SMTP设置页面"]) --> Load["加载现有配置列表"]
Load --> Edit{"编辑/新增/删除"}
Edit --> |新增| AddRow["添加一行配置"]
Edit --> |删除| DelRow["删除一行配置"]
Edit --> |保存| Submit["提交表单"]
Submit --> Write["写入conf/smtp.conf.php"]
Write --> Done(["保存成功"])
```

图表来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L25-L110)
- [setting.php](file://admin/route/setting.php#L82-L108)
- [smtp.func.php](file://model/smtp.func.php#L44-L49)

章节来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L12-L110)
- [setting.php](file://admin/route/setting.php#L82-L108)
- [smtp.func.php](file://model/smtp.func.php#L72-L91)

### SSL/TLS加密与安全连接
- PHPMailer支持SMTPSecure选项，可设置为""、"ssl"或"tls"
- SmtpConnect中根据SMTPSecure值决定是否启用SSL/TLS
- StartTLS在握手后协商加密通道

```mermaid
flowchart TD
A["SmtpConnect入口"] --> B["解析Host与Port"]
B --> C{"SMTPSecure为ssl/tls?"}
C --> |ssl| D["使用ssl://前缀连接"]
C --> |tls| E["建立明文连接后发起StartTLS"]
D --> F["认证(可选)"]
E --> F
F --> G["返回连接成功"]
```

图表来源
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L863-L921)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L2714-L2747)

章节来源
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L217-L217)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L885-L900)

### 邮件发送测试与使用
- 管理界面提供“如何设置SMTP”的帮助链接
- 邮件发送函数xn_send_mail封装了SMTP发送流程，支持HTML正文、字符集、编码等
- 可通过修改SMTPDebug进行调试输出

章节来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L44-L46)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3367-L3415)

### 常见邮件服务商配置示例
以下为常见服务商的典型配置要点（基于通用SMTP规范）：
- QQ邮箱
  - host：smtp.qq.com
  - port：465 或 587
  - user：你的QQ邮箱账号
  - pass：QQ邮箱授权码（非登录密码）
  - SMTPSecure：ssl 或 tls
- 163/126邮箱
  - host：smtp.163.com 或 smtp.126.com
  - port：25、465、587
  - user：你的邮箱账号
  - pass：邮箱密码或授权码
  - SMTPSecure：ssl 或 tls
- Gmail
  - host：smtp.gmail.com
  - port：465 或 587
  - user：你的Gmail账号
  - pass：应用专用密码
  - SMTPSecure：ssl 或 tls

说明
- 具体端口与加密方式以各服务商最新文档为准
- 若使用授权码而非登录密码，需在邮箱服务商处开启SMTP服务并生成授权码

## 依赖关系分析
- 管理界面依赖语言资源与路由
- 管理路由依赖SMTP模型与配置文件
- 邮件发送函数依赖PHPMailer类与SMTP连接

```mermaid
graph LR
UI["setting_smtp.htm"] --> LANG["bbs_admin.php"]
UI --> ROUTE["setting.php"]
ROUTE --> MODEL["smtp.func.php"]
MODEL --> CONF["smtp.conf.php"]
SEND["xn_send_mail.func.php"] --> PM["PHPMailer类"]
```

图表来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L1-L117)
- [bbs_admin.php](file://lang/zh-cn/bbs_admin.php#L82-L86)
- [setting.php](file://admin/route/setting.php#L64-L108)
- [smtp.func.php](file://model/smtp.func.php#L44-L49)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3367-L3415)

章节来源
- [setting.php](file://admin/route/setting.php#L64-L108)
- [smtp.func.php](file://model/smtp.func.php#L44-L49)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3367-L3415)

## 性能考虑
- SMTP连接复用：PHPMailer支持KeepAlive，可在多次发送时保持连接
- 超时控制：SmtpConnect与发送函数均提供超时参数，避免长时间阻塞
- 字符集与编码：合理设置CharSet与Encoding，减少传输体积与兼容性问题

章节来源
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L242-L256)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3389-L3392)

## 故障排除指南
- 连接失败
  - 检查host与port是否正确
  - 确认防火墙与网络策略放行相应端口
  - 如使用SSL/TLS，确认证书与加密方式匹配
- 认证失败
  - 核对user与pass是否正确
  - 对于授权码场景，确保已开启SMTP服务并使用授权码
- 发送超时
  - 调整Timeout参数
  - 检查服务器负载与网络质量
- 调试输出
  - 将SMTPDebug设为1或2，查看详细错误信息
  - 关注PHPMailer的语言错误提示

章节来源
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L945-L971)
- [xn_send_mail.func.php](file://xiunophp/xn_send_mail.func.php#L3381-L3381)

## 结论
XiunoBBS 4.0的SMTP配置采用简洁直观的表格化界面与文件持久化方案，结合PHPMailer的强大能力，能够满足多场景的邮件发送需求。通过合理的参数配置与加密设置，配合完善的故障排除流程，可稳定地保障邮件功能的可用性。

## 附录

### SMTP配置字段速查
- email：发件邮箱
- host：SMTP服务器地址
- port：SMTP端口
- user：SMTP用户名
- pass：SMTP密码

章节来源
- [setting_smtp.htm](file://admin/view/htm/setting_smtp.htm#L17-L32)
- [bbs_admin.php](file://lang/zh-cn/bbs_admin.php#L82-L86)