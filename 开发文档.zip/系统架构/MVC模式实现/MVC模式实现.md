# MVC模式实现

<cite>
**本文档引用的文件**
- [index.inc.php](file://index.inc.php)
- [model.inc.php](file://model.inc.php)
- [admin/index.inc.php](file://admin/index.inc.php)
- [route/index.php](file://route/index.php)
- [route/thread.php](file://route/thread.php)
- [route/user.php](file://route/user.php)
- [admin/route/index.php](file://admin/route/index.php)
- [admin/route/user.php](file://admin/route/user.php)
- [model/user.func.php](file://model/user.func.php)
- [model/thread.func.php](file://model/thread.func.php)
- [view/htm/index.htm](file://view/htm/index.htm)
- [view/htm/thread.htm](file://view/htm/thread.htm)
- [view/htm/user.htm](file://view/htm/user.htm)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm)
- [xiunophp/xiunophp.php](file://xiunophp/xiunophp.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
本文件面向XiunoBBS 4.0的MVC模式实现，系统性阐述其函数风格的MVC架构设计，包括控制器、模型和视图的分离原则；详解入口文件如何协调MVC流程，从请求接收、路由分发到模板渲染的完整过程；说明模型层的组织方式与加载机制；解释视图层模板系统的组织结构与渲染机制；并总结控制器层的路由处理逻辑与最佳实践。

## 项目结构
XiunoBBS 4.0采用“函数风格”的MVC架构，强调清晰的职责分离：
- 控制器层：位于route目录（前台）与admin/route目录（后台），每个路由对应一个控制器脚本，负责参数解析、权限校验、业务调用与视图渲染。
- 模型层：位于model目录，每个数据模型以独立函数文件组织，提供基础CRUD与业务封装函数。
- 视图层：位于view/htm与admin/view/htm，采用包含式模板，通过PHP原生语法与钩子点实现可扩展的页面结构。

```mermaid
graph TB
A["入口文件<br/>index.inc.php"] --> B["路由分发<br/>route/index.php"]
A --> C["后台入口<br/>admin/index.inc.php"]
C --> D["后台路由分发<br/>admin/route/index.php"]
B --> E["视图模板<br/>view/htm/index.htm"]
D --> F["后台视图模板<br/>admin/view/htm/index.htm"]
A --> G["模型加载<br/>model.inc.php"]
G --> H["用户模型<br/>model/user.func.php"]
G --> I["主题模型<br/>model/thread.func.php"]
B --> H
B --> I
D --> H
D --> I
```

图表来源
- [index.inc.php](file://index.inc.php#L49-L80)
- [admin/index.inc.php](file://admin/index.inc.php#L24-L47)
- [route/index.php](file://route/index.php#L47-L48)
- [admin/route/index.php](file://admin/route/index.php#L90-L91)
- [model.inc.php](file://model.inc.php#L10-L62)
- [model/user.func.php](file://model/user.func.php#L1-L200)
- [model/thread.func.php](file://model/thread.func.php#L1-L200)

章节来源
- [index.inc.php](file://index.inc.php#L1-L84)
- [admin/index.inc.php](file://admin/index.inc.php#L1-L50)
- [model.inc.php](file://model.inc.php#L1-L86)

## 核心组件
- 入口与框架初始化：入口文件负责会话启动、语言与用户组加载、权限过滤、运行时数据初始化、站点运行级别检测、路由分发等。
- 路由控制器：根据请求路径选择对应的控制器脚本，执行业务逻辑并渲染视图。
- 模型层：集中管理数据访问与业务封装，提供基础CRUD与格式化、缓存、统计等辅助函数。
- 视图层：采用包含式模板，通过钩子点与局部模板组合，实现页面结构的模块化与可扩展性。

章节来源
- [index.inc.php](file://index.inc.php#L7-L44)
- [route/index.php](file://route/index.php#L1-L49)
- [model/user.func.php](file://model/user.func.php#L1-L200)
- [view/htm/index.htm](file://view/htm/index.htm#L1-L79)

## 架构总览
下面的序列图展示了从前台入口到视图渲染的完整流程，以及后台入口的类似流程。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Entry as "入口文件<br/>index.inc.php"
participant Router as "路由分发<br/>route/index.php"
participant Model as "模型层<br/>model/user.func.php<br/>model/thread.func.php"
participant View as "视图模板<br/>view/htm/index.htm"
Client->>Entry : "HTTP 请求"
Entry->>Entry : "会话启动/语言/用户组/权限/运行时数据"
Entry->>Router : "根据路由参数选择控制器"
Router->>Model : "查询数据/业务处理"
Model-->>Router : "返回数据/结果"
Router->>View : "渲染视图"
View-->>Client : "HTML 响应"
```

图表来源
- [index.inc.php](file://index.inc.php#L49-L80)
- [route/index.php](file://route/index.php#L20-L47)
- [model/user.func.php](file://model/user.func.php#L65-L75)
- [model/thread.func.php](file://model/thread.func.php#L158-L164)
- [view/htm/index.htm](file://view/htm/index.htm#L1-L79)

## 详细组件分析

### 入口文件与控制流协调
- 会话与用户上下文：入口文件启动会话、加载语言包、获取用户组列表、尝试Token登录并构建用户与组上下文。
- 权限与版块：加载版块列表并按用户组进行权限过滤，生成导航与SEO元信息。
- 运行时数据：初始化运行时统计数据，检测站点运行级别。
- 路由分发：读取路由参数，按高频命中顺序匹配控制器文件，若未命中则回落至首页控制器。
- 钩子机制：在关键节点插入钩子，便于扩展与定制。

```mermaid
flowchart TD
Start(["请求进入"]) --> Session["启动会话/加载语言/用户组"]
Session --> UserGroup["构建用户与组上下文"]
UserGroup --> Forum["加载版块并权限过滤"]
Forum --> Runtime["初始化运行时数据/检测运行级别"]
Runtime --> RouteParam["读取路由参数"]
RouteParam --> Switch{"匹配控制器？"}
Switch --> |是| IncludeCtrl["包含对应控制器文件"]
Switch --> |否| DefaultCtrl["包含首页控制器"]
IncludeCtrl --> Render["渲染视图"]
DefaultCtrl --> Render
Render --> End(["响应输出"])
```

图表来源
- [index.inc.php](file://index.inc.php#L7-L80)

章节来源
- [index.inc.php](file://index.inc.php#L7-L84)

### 模型层组织与加载机制
- 加载策略：model.inc.php集中声明待加载的模型文件列表；在调试模式逐个include，非调试模式合并压缩为单文件并缓存，提升加载性能。
- 数据模型：用户模型与主题模型分别提供基础CRUD、业务封装、格式化、缓存与统计更新等函数。
- 缓存与静态变量：模型内部使用静态数组或缓存接口，避免重复查询数据库，提升前端展示性能。

```mermaid
classDiagram
class ModelLoader {
+include_model_files
+load_models()
+merge_and_cache()
}
class UserModel {
+user__create()
+user__read()
+user_create()
+user_read()
+user_read_cache()
+user_update()
+user_delete()
+user_count()
+user_format()
}
class ThreadModel {
+thread__create()
+thread__read()
+thread_create()
+thread_read()
+thread_read_cache()
+thread_update()
+thread_delete()
+thread_inc_views()
}
ModelLoader --> UserModel : "加载"
ModelLoader --> ThreadModel : "加载"
```

图表来源
- [model.inc.php](file://model.inc.php#L10-L62)
- [model/user.func.php](file://model/user.func.php#L11-L136)
- [model/thread.func.php](file://model/thread.func.php#L7-L118)

章节来源
- [model.inc.php](file://model.inc.php#L1-L86)
- [model/user.func.php](file://model/user.func.php#L1-L200)
- [model/thread.func.php](file://model/thread.func.php#L1-L200)

### 视图层模板系统
- 模板组织：前台模板位于view/htm，后台模板位于admin/view/htm；模板通过include局部模板与钩子点实现模块化。
- 页面结构：首页模板包含头部、主内容区、侧边栏、分页与底部；主题详情模板包含面包屑、主题信息、回帖列表与快速回复等。
- 钩子机制：模板中预留钩子点，便于插件或二次开发扩展。

```mermaid
graph TB
VIndex["前台首页模板<br/>view/htm/index.htm"] --> Header["头部模板<br/>view/htm/header.inc.htm"]
VIndex --> Footer["底部模板<br/>view/htm/footer.inc.htm"]
VIndex --> TList["主题列表局部模板<br/>view/htm/thread_list.inc.htm"]
VThread["主题详情模板<br/>view/htm/thread.htm"] --> Header2["头部模板"]
VThread --> Footer2["底部模板"]
VThread --> PList["回帖列表局部模板<br/>view/htm/post_list.inc.htm"]
AIndex["后台首页模板<br/>admin/view/htm/index.htm"] --> AHeader["后台头部模板<br/>admin/view/htm/header.inc.htm"]
AIndex --> AFooter["后台底部模板<br/>admin/view/htm/footer.inc.htm"]
```

图表来源
- [view/htm/index.htm](file://view/htm/index.htm#L1-L79)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L200)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm#L1-L94)

章节来源
- [view/htm/index.htm](file://view/htm/index.htm#L1-L79)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L200)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm#L1-L94)

### 控制器层路由处理逻辑
- 前台路由：入口文件根据路由参数选择对应控制器，如首页、主题、论坛、用户、个人中心、附件、回帖、版主操作、浏览器兼容等。
- 后台路由：后台入口同样基于路由参数选择控制器，如首页、设置、论坛、友链、用户、主题、插件等。
- 参数解析与业务调用：控制器内解析请求参数、执行权限校验、调用模型函数、构造视图变量、设置SEO与导航、最终渲染模板。
- URL解析与业务逻辑：控制器通过param函数获取参数，结合conf配置与用户上下文执行业务逻辑，如主题创建、用户登录注册、后台用户管理等。

```mermaid
sequenceDiagram
participant Entry as "入口文件<br/>index.inc.php"
participant Router as "前台路由<br/>route/thread.php"
participant Model as "模型层<br/>model/thread.func.php"
participant View as "视图模板<br/>view/htm/thread.htm"
Entry->>Router : "路由参数 : thread-{tid}"
Router->>Router : "解析参数/校验权限"
Router->>Model : "thread_read()/post_find_by_tid()"
Model-->>Router : "返回主题与回帖数据"
Router->>View : "渲染主题详情模板"
View-->>Entry : "HTML 响应"
```

图表来源
- [index.inc.php](file://index.inc.php#L49-L80)
- [route/thread.php](file://route/thread.php#L80-L142)
- [model/thread.func.php](file://model/thread.func.php#L158-L164)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L200)

章节来源
- [route/index.php](file://route/index.php#L1-L49)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/user.php](file://route/user.php#L1-L200)
- [admin/route/index.php](file://admin/route/index.php#L1-L111)
- [admin/route/user.php](file://admin/route/user.php#L1-L198)

### 用户与主题控制器示例
- 用户控制器：处理用户主页、主题列表、登录、注册、登出等动作，包含参数校验、密码验证、Token设置、统计更新与消息提示。
- 主题控制器：处理主题创建与详情展示，包含权限校验、内容长度限制、视图统计、分页与SEO设置。

章节来源
- [route/user.php](file://route/user.php#L13-L200)
- [route/thread.php](file://route/thread.php#L10-L142)

## 依赖关系分析
- 入口文件依赖：会话、语言、用户组、版块、运行时数据与路由分发。
- 路由控制器依赖：模型函数、工具函数、视图模板。
- 模型层依赖：数据库与缓存抽象层（由xiunophp提供），以及统计与格式化工具。
- 视图层依赖：模板与钩子点，以及语言包与配置。

```mermaid
graph TB
Entry["index.inc.php"] --> RouterF["route/*.php"]
Entry --> RouterA["admin/route/*.php"]
RouterF --> Model["model/*.func.php"]
RouterA --> Model
Model --> Xiu["xiunophp/xiunophp.php"]
RouterF --> ViewF["view/htm/*.htm"]
RouterA --> ViewA["admin/view/htm/*.htm"]
```

图表来源
- [index.inc.php](file://index.inc.php#L49-L80)
- [admin/index.inc.php](file://admin/index.inc.php#L24-L47)
- [model.inc.php](file://model.inc.php#L10-L62)
- [xiunophp/xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)

章节来源
- [index.inc.php](file://index.inc.php#L1-L84)
- [admin/index.inc.php](file://admin/index.inc.php#L1-L50)
- [model.inc.php](file://model.inc.php#L1-L86)
- [xiunophp/xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)

## 性能考虑
- 模型文件合并：非调试模式下将多个模型文件合并为单个压缩文件，减少include次数，提升加载性能。
- 缓存与静态变量：模型内部使用静态数组与缓存接口，避免重复查询数据库，适合前端展示场景。
- 路由命中优化：入口文件按使用频率排序匹配路由，提高命中率与效率。
- 运行时数据：统一初始化运行时统计，减少重复计算。

章节来源
- [model.inc.php](file://model.inc.php#L36-L62)
- [model/user.func.php](file://model/user.func.php#L79-L102)
- [model/thread.func.php](file://model/thread.func.php#L167-L174)
- [index.inc.php](file://index.inc.php#L55-L79)

## 故障排除指南
- 404/路由未命中：入口文件提供了默认回退逻辑，若启用严格模式可替换为404处理。
- 权限不足：控制器中对用户组权限进行校验，若无权限将提示或跳转。
- 登录状态异常：入口文件支持Token与Session双重登录机制，若出现异常可检查Token设置与Session存储。
- 模板钩子缺失：模板中的钩子点需确保对应钩子已注册，否则页面结构可能不完整。

章节来源
- [index.inc.php](file://index.inc.php#L69-L79)
- [route/thread.php](file://route/thread.php#L45-L46)
- [route/user.php](file://route/user.php#L75-L82)

## 结论
XiunoBBS 4.0采用函数风格的MVC架构，通过入口文件统一协调会话、语言、用户组、权限与路由分发，控制器专注于参数解析与业务调用，模型层提供清晰的数据访问与业务封装，视图层通过包含式模板与钩子点实现模块化与可扩展性。该架构在保证清晰职责的同时，兼顾了性能与可维护性，适合中小型论坛系统的快速开发与扩展。