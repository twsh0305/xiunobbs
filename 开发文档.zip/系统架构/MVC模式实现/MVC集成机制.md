# MVC集成机制

<cite>
**本文档引用的文件**
- [index.php](file://index.php)
- [index.inc.php](file://index.inc.php)
- [model.inc.php](file://model.inc.php)
- [xiunophp.php](file://xiunophp/xiunophp.php)
- [plugin.func.php](file://model/plugin.func.php)
- [user.func.php](file://model/user.func.php)
- [thread.func.php](file://model/thread.func.php)
- [forum.func.php](file://model/forum.func.php)
- [session.func.php](file://model/session.func.php)
- [index.htm](file://view/htm/index.htm)
- [conf.default.php](file://conf/conf.default.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
本文件系统性阐述 XiunoBBS 4.0 的 MVC 集成机制，重点说明：
- 请求从 HTTP 到页面渲染的完整流程
- MVC 各层之间的协作模式与数据流转
- 依赖注入与解耦机制（通过统一入口协调各层）
- 函数式编程在 MVC 中的实现方式（全局变量与作用域管理）
- 扩展点与插件机制（Hook/Overwrite）
- 设计原则、性能考量与维护策略

## 项目结构
XiunoBBS 4.0 采用“统一入口 + 路由分发 + 模型聚合 + 视图模板”的结构：
- 统一入口：index.php 作为应用启动器，加载配置、框架内核与模型层
- 路由层：route/ 下按功能模块划分，根据请求参数选择对应路由文件
- 模型层：model/ 下按领域模型划分，提供数据访问与业务逻辑
- 视图层：view/htm/ 下为模板文件，配合 Hook 系统实现可插拔渲染
- 插件层：model/plugin.func.php 提供 Hook/Overwrite 合并与编译

```mermaid
graph TB
A["index.php<br/>统一入口"] --> B["xiunophp.php<br/>框架内核"]
A --> C["model.inc.php<br/>模型聚合"]
A --> D["index.inc.php<br/>请求初始化"]
D --> E["route/index.php<br/>路由分发"]
E --> F["model/thread.func.php<br/>模型调用"]
F --> G["view/htm/index.htm<br/>视图渲染"]
A --> H["model/plugin.func.php<br/>插件合并"]
```

图表来源
- [index.php](file://index.php#L1-L56)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)
- [model.inc.php](file://model.inc.php#L1-L86)
- [index.inc.php](file://index.inc.php#L1-L84)
- [route/index.php](file://route/index.php#L1-L49)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [index.htm](file://view/htm/index.htm#L1-L79)
- [plugin.func.php](file://model/plugin.func.php#L1-L530)

章节来源
- [index.php](file://index.php#L1-L56)
- [model.inc.php](file://model.inc.php#L1-L86)
- [index.inc.php](file://index.inc.php#L1-L84)

## 核心组件
- 统一入口与框架内核
  - index.php：定义常量、加载配置、选择内核文件、引入插件与模型、执行入口逻辑
  - xiunophp.php：初始化全局状态、数据库与缓存、请求解析、错误处理、超级全局变量注入
- 请求初始化与路由
  - index.inc.php：会话启动、语言包、用户组、论坛列表、运行时数据、路由分发
  - route/index.php：首页路由，构造分页、查询主题列表、权限过滤、SEO 设置、视图包含
- 模型层
  - model.inc.php：模型文件聚合与最小化打包，提升加载性能
  - user.func.php/thread.func.php/forum.func.php：领域模型的 CRUD 与业务逻辑
- 视图层
  - view/htm/index.htm：模板文件，内置 Hook 点位，用于插件扩展
- 插件机制
  - model/plugin.func.php：Hook/Overwrite 合并、编译、临时文件缓存、插件启用/禁用/卸载

章节来源
- [index.php](file://index.php#L1-L56)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)
- [index.inc.php](file://index.inc.php#L1-L84)
- [route/index.php](file://route/index.php#L1-L49)
- [model.inc.php](file://model.inc.php#L1-L86)
- [user.func.php](file://model/user.func.php#L1-L434)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [forum.func.php](file://model/forum.func.php#L1-L210)
- [index.htm](file://view/htm/index.htm#L1-L79)
- [plugin.func.php](file://model/plugin.func.php#L1-L530)

## 架构总览
下面的序列图展示了从 HTTP 请求到页面渲染的完整流程，体现 MVC 各层的协作与数据流：

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Index as "index.php"
participant Kernel as "xiunophp.php"
participant Init as "index.inc.php"
participant Route as "route/index.php"
participant Model as "model/thread.func.php"
participant View as "view/htm/index.htm"
Client->>Index : 发起HTTP请求
Index->>Kernel : 加载框架内核
Kernel->>Kernel : 初始化全局状态/数据库/缓存
Index->>Init : 引入初始化逻辑
Init->>Init : 会话启动/语言/用户组/论坛列表
Init->>Route : 根据路由参数选择路由
Route->>Model : 查询主题列表/权限过滤
Model-->>Route : 返回格式化后的主题数据
Route->>View : 包含模板并渲染
View-->>Client : 输出HTML响应
```

图表来源
- [index.php](file://index.php#L1-L56)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)
- [index.inc.php](file://index.inc.php#L1-L84)
- [route/index.php](file://route/index.php#L1-L49)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [index.htm](file://view/htm/index.htm#L1-L79)

## 详细组件分析

### 组件A：统一入口与框架内核
- 统一入口职责
  - 定义调试模式、路径常量
  - 加载配置文件，兼容旧版键名
  - 选择加载 xiunophp.min.php 或 xiunophp.php
  - 引入插件系统、模型聚合、入口初始化
- 框架内核职责
  - 初始化全局时间、IP、UA、AJAX 标识
  - 注入超级全局变量（$_SERVER、$conf、$lang 等）
  - 初始化数据库与缓存连接
  - 解析请求参数、合并 GET/POST/COOKIE

```mermaid
flowchart TD
Start(["进入 index.php"]) --> LoadConf["加载 conf/conf.php"]
LoadConf --> ChooseKernel{"DEBUG > 1 ?"}
ChooseKernel --> |是| UseDev["include xiunophp.php"]
ChooseKernel --> |否| UseProd["include xiunophp.min.php"]
UseDev --> InitKernel["初始化全局状态/数据库/缓存"]
UseProd --> InitKernel
InitKernel --> IncludePlugin["引入插件系统"]
IncludePlugin --> IncludeModels["引入模型聚合"]
IncludeModels --> IncludeEntry["引入入口初始化"]
IncludeEntry --> End(["完成初始化"])
```

图表来源
- [index.php](file://index.php#L1-L56)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)

章节来源
- [index.php](file://index.php#L1-L56)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)

### 组件B：请求初始化与路由分发
- 会话与用户上下文
  - 启动会话、加载语言包、用户组、论坛列表
  - 支持 Token 登录（与 Session 双重校验）
  - 构建运行时数据与站点运行级别检查
- 路由分发
  - 从请求参数提取 route，按高频命中顺序 switch 分发
  - 默认兜底到首页路由
  - 路由文件负责业务数据准备与视图包含

```mermaid
flowchart TD
InitStart(["index.inc.php 开始"]) --> StartSess["启动会话"]
StartSess --> LoadLang["加载语言包"]
LoadLang --> LoadGroups["加载用户组"]
LoadGroups --> LoadUser["Token/Session 获取用户"]
LoadUser --> LoadForum["加载论坛列表与权限过滤"]
LoadForum --> BuildRuntime["构建运行时数据"]
BuildRuntime --> CheckRunlevel["检查站点运行级别"]
CheckRunlevel --> GetRoute["param(0) 获取路由"]
GetRoute --> SwitchRoute{"switch 路由"}
SwitchRoute --> |index| RouteIndex["include route/index.php"]
SwitchRoute --> |thread| RouteThread["include route/thread.php"]
SwitchRoute --> |...| OtherRoutes["include 对应路由"]
RouteIndex --> RenderView["包含视图模板"]
OtherRoutes --> RenderView
RenderView --> End(["完成渲染"])
```

图表来源
- [index.inc.php](file://index.inc.php#L1-L84)
- [route/index.php](file://route/index.php#L1-L49)

章节来源
- [index.inc.php](file://index.inc.php#L1-L84)
- [route/index.php](file://route/index.php#L1-L49)

### 组件C：模型层（函数式 + 领域模型）
- 模型聚合与最小化
  - model.inc.php 汇聚所有模型文件，开发模式逐个 include，生产模式合并为 model.min.php
- 领域模型示例
  - 用户模型：user.func.php 提供 create/update/read/delete 与格式化、Token 登录等
  - 主题模型：thread.func.php 提供主题创建、读取、删除、列表查询、权限过滤、格式化
  - 论坛模型：forum.func.php 提供论坛 CRUD、列表缓存、权限过滤

```mermaid
classDiagram
class UserModel {
+user__create(arr)
+user__update(uid, arr)
+user__read(uid)
+user__delete(uid)
+user_create(arr)
+user_update(uid, arr)
+user_read(uid)
+user_read_cache(uid)
+user_token_get()
+user_token_set(uid)
+user_login_check()
}
class ThreadModel {
+thread__create(arr)
+thread__update(tid, arr)
+thread__read(tid)
+thread__delete(tid)
+thread_create(arr, pid)
+thread_update(tid, arr)
+thread_read(tid)
+thread_read_cache(tid)
+thread_find_by_fid(fid, page, pagesize, order)
+thread_find_by_fids(fids, page, pagesize, order, threads)
+thread_list_access_filter(list, gid)
}
class ForumModel {
+forum__create(arr)
+forum__update(fid, arr)
+forum__read(fid)
+forum__delete(fid)
+forum_create(arr)
+forum_update(fid, arr)
+forum_read(fid)
+forum_delete(fid)
+forum_list_cache()
+forum_list_access_filter(list, gid, allow)
}
UserModel <.. ThreadModel : "关联用户"
ThreadModel <.. ForumModel : "关联论坛"
```

图表来源
- [user.func.php](file://model/user.func.php#L1-L434)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [forum.func.php](file://model/forum.func.php#L1-L210)

章节来源
- [model.inc.php](file://model.inc.php#L1-L86)
- [user.func.php](file://model/user.func.php#L1-L434)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [forum.func.php](file://model/forum.func.php#L1-L210)

### 组件D：视图层与插件机制
- 视图模板
  - index.htm 作为首页模板，内置大量 Hook 点位，便于插件扩展
- 插件机制
  - Hook：在模板或 PHP 文件中插入代码，多个插件按权重合并
  - Overwrite：替换源文件内容，支持权重排序
  - 编译与缓存：_include() 合并插件后写入 tmp 目录，避免每次合并

```mermaid
flowchart TD
SrcFile["源文件<br/>如 view/htm/index.htm"] --> Compile["_include()<br/>合并插件"]
Compile --> MergeHooks["正则替换 // hook ..."]
MergeHooks --> SortRank["按 hooks_rank 排序"]
SortRank --> WriteTmp["写入 tmp 目录"]
WriteTmp --> Include["include 合并后的文件"]
```

图表来源
- [plugin.func.php](file://model/plugin.func.php#L1-L530)
- [index.htm](file://view/htm/index.htm#L1-L79)

章节来源
- [index.htm](file://view/htm/index.htm#L1-L79)
- [plugin.func.php](file://model/plugin.func.php#L1-L530)

### 组件E：会话与全局变量管理
- 会话管理
  - 自定义 Session Handler，存储于数据库，支持延迟更新与大数据拆分
  - 会话生命周期与 Cookie 配置，保障安全性
- 全局变量
  - 框架内核将 conf、lang、db、cache、ip、time 等注入到 $_SERVER
  - 路由与模型通过全局变量共享上下文

```mermaid
flowchart TD
Start(["sess_start()"]) --> SetHandler["注册 Session Handler"]
SetHandler --> StartSession["session_start()"]
StartSession --> ReadSession["sess_read(sid)"]
ReadSession --> UpdateSession["sess_write(sid, data)"]
UpdateSession --> DelayUpdate{"延迟更新?"}
DelayUpdate --> |是| PartialUpdate["仅更新必要字段"]
DelayUpdate --> |否| FullUpdate["全量更新"]
PartialUpdate --> End(["完成"])
FullUpdate --> End
```

图表来源
- [session.func.php](file://model/session.func.php#L1-L224)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)

章节来源
- [session.func.php](file://model/session.func.php#L1-L224)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)

## 依赖关系分析
- 入口依赖
  - index.php 依赖 conf/default 配置、xiunophp 内核、插件系统、模型聚合、入口初始化
- 路由依赖
  - route/index.php 依赖模型层（thread.list/access_filter）、视图层（index.htm）
- 模型依赖
  - 模型函数依赖数据库与缓存抽象层（db.func.php/cache.func.php），以及全局配置
- 视图依赖
  - 视图模板依赖全局变量（$conf、$runtime、$header 等）与 Hook 系统

```mermaid
graph TB
Index["index.php"] --> Conf["conf/conf.default.php"]
Index --> Kernel["xiunophp.php"]
Index --> Plugin["plugin.func.php"]
Index --> ModelInc["model.inc.php"]
Index --> Entry["index.inc.php"]
Entry --> RouteIndex["route/index.php"]
RouteIndex --> ThreadModel["thread.func.php"]
ThreadModel --> ViewIndex["view/htm/index.htm"]
```

图表来源
- [index.php](file://index.php#L1-L56)
- [conf.default.php](file://conf/conf.default.php#L1-L123)
- [plugin.func.php](file://model/plugin.func.php#L1-L530)
- [model.inc.php](file://model.inc.php#L1-L86)
- [index.inc.php](file://index.inc.php#L1-L84)
- [route/index.php](file://route/index.php#L1-L49)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [index.htm](file://view/htm/index.htm#L1-L79)

章节来源
- [index.php](file://index.php#L1-L56)
- [conf.default.php](file://conf/conf.default.php#L1-L123)
- [plugin.func.php](file://model/plugin.func.php#L1-L530)
- [model.inc.php](file://model.inc.php#L1-L86)
- [index.inc.php](file://index.inc.php#L1-L84)
- [route/index.php](file://route/index.php#L1-L49)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [index.htm](file://view/htm/index.htm#L1-L79)

## 性能考量
- 模型聚合与最小化
  - 生产模式将模型文件合并为 model.min.php，减少 include 次数与解析开销
- 缓存策略
  - 论坛列表缓存、用户信息静态缓存、主题列表缓存页数控制
  - 运行时统计与在线用户统计
- 数据库与会话
  - 会话延迟更新降低写入压力
  - 读写分离与多缓存类型支持（Redis/Memcached/MySQL/XCache/YAC/APC）
- 插件编译缓存
  - 合并后的文件写入 tmp 目录，避免每次请求重复合并

章节来源
- [model.inc.php](file://model.inc.php#L1-L86)
- [forum.func.php](file://model/forum.func.php#L136-L162)
- [user.func.php](file://model/user.func.php#L78-L102)
- [thread.func.php](file://model/thread.func.php#L166-L174)
- [session.func.php](file://model/session.func.php#L138-L168)
- [plugin.func.php](file://model/plugin.func.php#L15-L37)

## 故障排除指南
- 安装与配置
  - 若未找到 conf/conf.php，将跳转至安装目录
  - 配置项缺失时进行兼容赋值（如 logo_*、user_create_on）
- 数据库连接
  - 框架内核初始化时创建 db/cache 实例，若异常可在相应模块捕获
- 会话异常
  - Cookie 测试失败或 IP 变化可能导致会话无效，需检查 Cookie 设置与代理
- 插件冲突
  - 启用/禁用插件后需清空 tmp 目录与 model.min.php，确保合并结果生效
- 路由兜底
  - 未知路由将回退到首页路由，避免 404

章节来源
- [index.php](file://index.php#L25-L56)
- [xiunophp.php](file://xiunophp/xiunophp.php#L117-L131)
- [session.func.php](file://model/session.func.php#L54-L90)
- [plugin.func.php](file://model/plugin.func.php#L164-L169)
- [index.inc.php](file://index.inc.php#L69-L79)

## 结论
XiunoBBS 4.0 的 MVC 集成以“统一入口 + 路由分发 + 模型聚合 + 视图模板 + 插件系统”为核心，通过以下设计实现了高内聚、低耦合与可扩展：
- 统一入口协调各层组件，确保全局状态一致
- 路由层专注业务入口与数据准备，视图层专注展示与扩展
- 模型层采用函数式封装与领域模型，兼顾性能与可维护性
- 插件机制通过 Hook/Overwrite 实现无侵入扩展
- 性能层面通过模型最小化、缓存与延迟更新等策略优化