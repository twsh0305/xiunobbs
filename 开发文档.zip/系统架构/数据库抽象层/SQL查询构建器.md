# SQL查询构建器

<cite>
**本文档引用的文件**
- [db.func.php](file://xiunophp/db.func.php)
- [db_mysql.class.php](file://xiunophp/db_mysql.class.php)
- [user.func.php](file://model/user.func.php)
- [thread.func.php](file://model/thread.func.php)
- [dx32_to_xn4.php](file://tool/dx32_to_xn4.php)
- [xiunophp.php](file://xiunophp/xiunophp.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)

## 简介
本文件系统性梳理 XiunoBBS 4.0 的 SQL 查询构建器，重点解析以下函数：
- 条件构建：db_cond_to_sqladd()
- 插入构建：db_array_to_insert_sqladd()
- 更新构建：db_array_to_update_sqladd()
- 排序构建：db_orderby_to_sqladd()

并结合实际使用场景（模型层、工具脚本）说明其工作机制、性能优化技巧、SQL 注入防护与参数安全处理方式。

## 项目结构
围绕 SQL 构建器的核心文件与职责如下：
- xiunophp/db.func.php：提供通用 SQL 构建与执行接口，包含上述四个关键函数
- xiunophp/db_mysql.class.php：数据库适配层，负责实际 SQL 执行与连接管理
- model/user.func.php、model/thread.func.php：业务模型层，广泛调用 db_* 函数进行查询与更新
- tool/dx32_to_xn4.php：数据迁移工具，展示批量插入时的 SQL 构建用法
- xiunophp/xiunophp.php：框架入口，加载 db.func.php 与 db_mysql.class.php

```mermaid
graph TB
subgraph "应用层"
MUser["model/user.func.php"]
MThread["model/thread.func.php"]
Tool["tool/dx32_to_xn4.php"]
end
subgraph "框架层"
XPH["xiunophp/xiunophp.php"]
DBF["xiunophp/db.func.php"]
DBM["xiunophp/db_mysql.class.php"]
end
MUser --> DBF
MThread --> DBF
Tool --> DBF
XPH --> DBF
XPH --> DBM
DBF --> DBM
```

图表来源
- [db.func.php](file://xiunophp/db.func.php#L1-L344)
- [db_mysql.class.php](file://xiunophp/db_mysql.class.php#L1-L212)
- [user.func.php](file://model/user.func.php#L1-L434)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [dx32_to_xn4.php](file://tool/dx32_to_xn4.php#L1-L200)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)

章节来源
- [db.func.php](file://xiunophp/db.func.php#L1-L344)
- [db_mysql.class.php](file://xiunophp/db_mysql.class.php#L1-L212)
- [user.func.php](file://model/user.func.php#L1-L434)
- [thread.func.php](file://model/thread.func.php#L1-L437)
- [dx32_to_xn4.php](file://tool/dx32_to_xn4.php#L1-L200)
- [xiunophp.php](file://xiunophp/xiunophp.php#L1-L132)

## 核心组件
本节聚焦四个 SQL 构建函数的职责与行为：
- db_cond_to_sqladd(cond): 将数组条件转换为 WHERE 子句，支持等值、范围、IN/OR、LIKE 等
- db_array_to_insert_sqladd(arr): 将键值对数组转换为 INSERT 的列与值片段
- db_array_to_update_sqladd(arr): 将键值对数组转换为 UPDATE 的 SET 片段，支持自增/自减语法
- db_orderby_to_sqladd(orderby): 将排序数组转换为 ORDER BY 子句

章节来源
- [db.func.php](file://xiunophp/db.func.php#L242-L342)

## 架构总览
SQL 查询构建器位于应用层与数据库适配层之间，承担“条件/插入/更新/排序”的字符串拼接职责，最终由 db_mysql.class.php 执行 SQL。

```mermaid
sequenceDiagram
participant Model as "业务模型"
participant DBF as "db.func.php"
participant DBM as "db_mysql.class.php"
participant MySQL as "MySQL 服务器"
Model->>DBF : 调用 db_find()/db_update()/db_insert() 等
DBF->>DBF : db_cond_to_sqladd()/db_orderby_to_sqladd()
DBF->>DBF : db_array_to_insert_sqladd()/db_array_to_update_sqladd()
DBF->>DBM : 执行 SQLINSERT/UPDATE/SELECT
DBM->>MySQL : query/exec
MySQL-->>DBM : 结果集/影响行数
DBM-->>DBF : 返回结果
DBF-->>Model : 返回数据或受影响行数
```

图表来源
- [db.func.php](file://xiunophp/db.func.php#L122-L188)
- [db_mysql.class.php](file://xiunophp/db_mysql.class.php#L84-L153)

## 详细组件分析

### 条件构建：db_cond_to_sqladd()
该函数将数组条件转换为 WHERE 子句，支持多种比较与集合形式：
- 等值条件：键值为标量时，生成字段=值
- IN/OR 条件：键值为索引数组时，生成若干 OR 条件（注释中指出 OR 在某些情况下效率高于 IN）
- 范围条件：键值为关联数组时，键为比较操作符（如 >、<、>=、<=、==），值为比较值
- LIKE 条件：键为 LIKE，值会被包裹为 %value%

实现要点
- 字段名使用反引号包裹，值通过转义处理
- 数字类型不加引号，字符串类型经转义后加单引号
- 多个条件以 AND 连接，IN/OR 条件外层加括号

```mermaid
flowchart TD
Start(["进入 db_cond_to_sqladd"]) --> CheckEmpty{"cond 是否为空？"}
CheckEmpty --> |是| ReturnEmpty["返回空字符串"]
CheckEmpty --> |否| Init["初始化 s=' WHERE '"]
Init --> Loop["遍历每个条件项 k=>v"]
Loop --> IsScalar{"v 是否为标量？"}
IsScalar --> |是| BuildEq["生成 `k`=v 条件<br/>数字不加引号，字符串转义后加引号"]
IsScalar --> |否| IsIndexArr{"v 是否为索引数组？"}
IsIndexArr --> |是| BuildOr["为每个元素生成 OR 条件<br/>外层括号包裹"]
IsIndexArr --> |否| LoopOps["遍历关联数组中的操作符"]
LoopOps --> LikeOp{"操作符是否为 LIKE？"}
LikeOp --> |是| WrapLike["值包裹为 %value%"]
LikeOp --> |否| NoWrap["保持原值"]
WrapLike --> BuildOp["生成 `k` 操作符 值 条件"]
NoWrap --> BuildOp
BuildEq --> Join["追加 AND"]
BuildOr --> Join
BuildOp --> Join
Join --> Next["继续下一个条件"]
Next --> |循环结束| Trim["去除末尾 AND"]
Trim --> Return["返回 WHERE 子句"]
```

图表来源
- [db.func.php](file://xiunophp/db.func.php#L242-L279)

章节来源
- [db.func.php](file://xiunophp/db.func.php#L242-L279)

### 插入构建：db_array_to_insert_sqladd()
该函数将键值对数组转换为 INSERT 的列与值片段：
- 列名使用反引号包裹，键同样经过转义
- 值按类型处理：数字不加引号，字符串转义后加引号
- 生成形如 (col1,col2,...) VALUES (val1,val2,...)

实现要点
- 使用数组收集键与值，最后拼接为标准 INSERT 片段
- 适用于批量导入场景（见工具脚本）

章节来源
- [db.func.php](file://xiunophp/db.func.php#L327-L342)
- [dx32_to_xn4.php](file://tool/dx32_to_xn4.php#L63-L68)

### 更新构建：db_array_to_update_sqladd()
该函数将键值对数组转换为 UPDATE 的 SET 片段：
- 支持自增/自减语法：键名以 + 或 - 结尾表示增量/减量更新
- 非自增键：生成字段=值
- 自增键：生成字段=字段±值

实现要点
- 值按类型处理：数字不加引号，字符串转义后加引号
- 自增/自减时，字段名去掉尾部运算符，然后拼接运算符与值

章节来源
- [db.func.php](file://xiunophp/db.func.php#L303-L318)

### 排序构建：db_orderby_to_sqladd()
该函数将排序数组转换为 ORDER BY 子句：
- 键为字段名，值为 1 表示升序，-1 或其他非 1 视为降序
- 多字段排序以逗号分隔

章节来源
- [db.func.php](file://xiunophp/db.func.php#L281-L292)

### 实际使用示例与集成点
- 模型层使用
  - 用户模型：用户查找、读取、更新、删除均通过 db_find、db_find_one、db_update、db_delete 等间接调用 db_cond_to_sqladd 与 db_orderby_to_sqladd
  - 主题模型：主题列表、关键字搜索、按版块筛选等均使用条件构建函数
- 工具脚本使用
  - 数据迁移工具批量导入用户、论坛、主题等数据，使用 db_array_to_insert_sqladd 生成插入片段

章节来源
- [user.func.php](file://model/user.func.php#L138-L184)
- [thread.func.php](file://model/thread.func.php#L289-L302)
- [dx32_to_xn4.php](file://tool/dx32_to_xn4.php#L63-L98)

## 依赖关系分析
- db.func.php 依赖 db_mysql.class.php 提供的执行能力（find/find_one/exec/query 等）
- 模型层通过 db.func.php 的高层封装进行查询与更新
- 工具脚本直接调用 db.func.php 的构建函数进行批量导入

```mermaid
graph LR
DBF["db.func.php"] --> DBM["db_mysql.class.php"]
MUser["model/user.func.php"] --> DBF
MThread["model/thread.func.php"] --> DBF
Tool["tool/dx32_to_xn4.php"] --> DBF
XPH["xiunophp.php"] --> DBF
XPH --> DBM
```

图表来源
- [db.func.php](file://xiunophp/db.func.php#L122-L188)
- [db_mysql.class.php](file://xiunophp/db_mysql.class.php#L84-L153)
- [user.func.php](file://model/user.func.php#L138-L184)
- [thread.func.php](file://model/thread.func.php#L289-L302)
- [dx32_to_xn4.php](file://tool/dx32_to_xn4.php#L63-L98)
- [xiunophp.php](file://xiunophp/xiunophp.php#L41-L59)

## 性能考量
- IN 与 OR 的选择
  - 条件构建函数注释明确指出：在某些情况下，将 IN 条件展开为多个 OR 条件的效率更高。这通常与 MySQL 的查询优化器对 IN 与 OR 的处理策略有关，具体取决于基数、索引与数据分布
- 分页与排序
  - 分页通过 LIMIT offset, pagesize 实现，排序通过 ORDER BY 子句实现
  - 大数据量时，建议配合合适的索引与合理的排序字段
- 批量插入
  - 工具脚本展示了多次调用 db_array_to_insert_sqladd 与 db_exec 的批量导入模式，适合离线迁移场景

章节来源
- [db.func.php](file://xiunophp/db.func.php#L251-L264)
- [db_mysql.class.php](file://xiunophp/db_mysql.class.php#L84-L99)
- [dx32_to_xn4.php](file://tool/dx32_to_xn4.php#L63-L98)

## 故障排查指南
- 错误码与错误信息
  - db_errno_errstr 会将底层错误码与错误信息保存至全局变量，并记录到日志文件
  - db_errstr_safe 在非调试模式下对常见错误进行友好化处理
- 日志定位
  - db_exec 与 db_mysql.class.php 的 query/exec 在 DEBUG 模式下会记录 SQL 执行耗时与 SQL 文本
- 常见问题
  - SQL 注入：构建器通过 addslashes 对字符串值进行转义，但不建议在生产环境中仅依赖此机制
  - 参数安全：建议在输入层使用 param 系列函数进行统一清洗与转义，避免直接拼接用户输入

章节来源
- [db.func.php](file://xiunophp/db.func.php#L201-L224)
- [db_mysql.class.php](file://xiunophp/db_mysql.class.php#L101-L153)
- [xiunophp.php](file://xiunophp/xiunophp.php#L17-L20)

## 结论
- 条件构建函数 db_cond_to_sqladd() 提供了灵活的 WHERE 子句生成能力，涵盖等值、范围、IN/OR、LIKE 等常用场景
- 插入与更新构建函数 db_array_to_insert_sqladd() 与 db_array_to_update_sqladd() 以简单直观的方式将数组映射为 SQL 片段，便于批量导入与动态更新
- 排序构建函数 db_orderby_to_sqladd() 支持多字段排序，满足复杂查询需求
- 性能方面，条件构建注释提示在特定条件下 OR 可能优于 IN；结合索引与分页可进一步提升查询效率
- 安全方面，构建器内置 addslashes 转义，但建议在输入层加强参数清洗与校验，确保整体安全