# MySQL缓存实现

<cite>
**本文档引用的文件**
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php)
- [cache.func.php](file://xiunophp/cache.func.php)
- [db.func.php](file://xiunophp/db.func.php)
- [install.sql](file://install/install.sql)
- [conf.default.php](file://conf/conf.default.php)
- [misc.func.php](file://xiunophp/misc.func.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)

## 简介
本文件面向XiunoBBS 4.0的MySQL缓存实现，系统性解析cache_mysql类的设计与实现，涵盖数据库表结构、连接管理、查询优化、持久化与可靠性保障、性能调优建议以及高并发场景下的表现与瓶颈分析。文档同时结合安装脚本中的表定义，明确key、value、life等字段的作用与约束，帮助读者在生产环境中安全、高效地使用MySQL作为缓存层。

## 项目结构
与MySQL缓存相关的核心文件位于xiunophp目录，关键模块如下：
- cache_mysql.class.php：MySQL缓存实现类，封装set/get/delete/truncate等操作
- cache.func.php：缓存工厂与统一入口，负责根据配置选择具体缓存类型
- db.func.php：数据库通用函数，封装db_new/db_connect/db_replace/db_find_one等底层操作
- install.sql：安装脚本，包含bbs_kv、bbs_cache等缓存相关表的建表语句
- conf.default.php：默认配置，包含cache.type=mysql及cachepre等参数
- misc.func.php：JSON序列化/反序列化工具函数

```mermaid
graph TB
subgraph "缓存层"
CF["cache.func.php<br/>缓存工厂/统一入口"]
CM["cache_mysql.class.php<br/>MySQL缓存实现"]
end
subgraph "数据库层"
DF["db.func.php<br/>数据库通用函数"]
SQL["install.sql<br/>缓存表结构定义"]
end
subgraph "配置与工具"
CONF["conf.default.php<br/>默认配置"]
MISC["misc.func.php<br/>JSON工具"]
end
CF --> CM
CM --> DF
DF --> SQL
CF --> CONF
CM --> MISC
```

图表来源
- [cache.func.php](file://xiunophp/cache.func.php#L3-L21)
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L13-L33)
- [db.func.php](file://xiunophp/db.func.php#L4-L25)
- [install.sql](file://install/install.sql#L257-L273)
- [conf.default.php](file://conf/conf.default.php#L39-L64)
- [misc.func.php](file://xiunophp/misc.func.php#L274-L278)

章节来源
- [cache.func.php](file://xiunophp/cache.func.php#L3-L21)
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L13-L33)
- [db.func.php](file://xiunophp/db.func.php#L4-L25)
- [install.sql](file://install/install.sql#L257-L273)
- [conf.default.php](file://conf/conf.default.php#L39-L64)
- [misc.func.php](file://xiunophp/misc.func.php#L274-L278)

## 核心组件
- cache_mysql类：提供键值缓存能力，支持过期时间控制，基于REPLACE写入，按主键k唯一
- cache_new工厂：根据配置选择缓存类型，当前支持mysql、redis、memcached、xcache、apc、yac等
- db通用函数：封装数据库连接、替换写入、查找、删除、清空等操作
- JSON工具：序列化/反序列化缓存值，确保复杂数据结构的持久化与读取一致性
- 安装脚本：定义bbs_kv与bbs_cache两张缓存表，含k、v、expiry字段及主键约束

章节来源
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L13-L95)
- [cache.func.php](file://xiunophp/cache.func.php#L3-L21)
- [db.func.php](file://xiunophp/db.func.php#L132-L168)
- [misc.func.php](file://xiunophp/misc.func.php#L274-L278)
- [install.sql](file://install/install.sql#L257-L273)

## 架构总览
MySQL缓存的整体流程如下：
- 应用通过cache_get/cache_set/cache_delete/cache_truncate统一入口访问缓存
- cache_new根据配置选择cache_mysql实现
- cache_mysql内部通过db_replace/db_find_one/db_delete/db_truncate等函数与数据库交互
- JSON序列化/反序列化确保复杂对象的持久化
- 过期时间由应用层传入，cache_mysql在读取时判断并自动清理过期项

```mermaid
sequenceDiagram
participant App as "应用"
participant CF as "cache.func.php"
participant CM as "cache_mysql.class.php"
participant DBF as "db.func.php"
participant SQL as "install.sql(缓存表)"
App->>CF : 调用cache_set(k,v,life)
CF->>CM : new cache_mysql(conf.mysql)
CF->>CM : set(k,v,life)
CM->>DBF : db_replace(table,arr,db)
DBF->>SQL : REPLACE INTO bbs_cache(k,v,expiry)
SQL-->>DBF : 成功/失败
DBF-->>CM : 返回影响行数
CM-->>CF : 返回布尔结果
CF-->>App : 返回布尔结果
App->>CF : 调用cache_get(k)
CF->>CM : get(k)
CM->>DBF : db_find_one(table,{k})
DBF->>SQL : SELECT * FROM bbs_cache WHERE k=?
SQL-->>DBF : 返回记录或空
DBF-->>CM : 返回记录
CM->>CM : 判断过期并清理
CM-->>CF : 返回反序列化后的值
CF-->>App : 返回值
```

图表来源
- [cache.func.php](file://xiunophp/cache.func.php#L35-L45)
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L37-L68)
- [db.func.php](file://xiunophp/db.func.php#L132-L168)
- [install.sql](file://install/install.sql#L266-L273)

## 详细组件分析

### cache_mysql类设计与实现
- 构造与连接
  - 支持复用已有的$db对象或新建数据库连接
  - 可配置cachepre前缀，用于区分不同站点或环境
- 写入流程(set)
  - 计算过期时间：life为0表示永不过期
  - 使用REPLACE INTO写入，保证同一k的幂等覆盖
  - 错误状态通过errno/errstr透传
- 读取流程(get)
  - 通过主键k精确查找
  - 若记录存在但已过期，立即删除并返回NULL
  - JSON反序列化后返回
- 删除与清空
  - delete按k删除
  - truncate清空整个缓存表
- 错误处理
  - 所有底层操作失败时，将db的errno/errstr复制到cache对象，便于上层统一处理

```mermaid
classDiagram
class cache_mysql {
+conf array
+db object
+link object
+table string
+cachepre string
+errno int
+errstr string
+__construct(dbconf)
+connect()
+set(k, v, life) bool
+get(k) mixed
+delete(k) bool
+truncate() bool
+error(errno, errstr)
}
```

图表来源
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L13-L95)

章节来源
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L23-L95)

### 数据库表结构与字段定义
- bbs_kv与bbs_cache两张表结构一致，均包含以下字段：
  - k(char(32))：主键，作为缓存键
  - v(mediumtext)：缓存值，使用JSON序列化存储
  - expiry(int)：过期时间戳，0表示永不过期
- 索引与约束
  - 主键k确保唯一性与快速定位
  - MyISAM引擎适用于读多写少的缓存场景
- 注意事项
  - v为mediumtext，单条记录大小受MySQL限制，需控制缓存值大小
  - 过期清理在读取时触发，写入时不主动删除过期记录

章节来源
- [install.sql](file://install/install.sql#L257-L273)

### 连接管理与生命周期
- 连接延迟建立
  - cache_new仅初始化，实际连接在首次使用时通过db_connect建立
- 多实例支持
  - db_new支持多种数据库类型，cache_mysql可复用全局$db实例
- 错误传播
  - 底层数据库错误通过errno/errstr传递至cache对象，便于统一处理

章节来源
- [cache.func.php](file://xiunophp/cache.func.php#L3-L21)
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L23-L36)
- [db.func.php](file://xiunophp/db.func.php#L4-L25)

### 查询优化与SQL策略
- 写入优化
  - 使用REPLACE INTO替代INSERT+UPDATE，减少两步操作，提升写入吞吐
- 读取优化
  - 通过主键k精确查找，利用主键索引实现O(1)级别的定位
- 过期清理
  - 读取时发现过期即删除，避免脏数据长期占用空间
- 索引设计
  - 主键k已满足等值查询需求，无需额外索引
- 查询计划
  - MyISAM在读多写少场景下具备较好性能，但需关注锁粒度与崩溃恢复特性

章节来源
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L37-L68)
- [db.func.php](file://xiunophp/db.func.php#L132-L168)
- [install.sql](file://install/install.sql#L257-L273)

### 持久化特性与可靠性
- 持久化
  - 缓存数据存储在MySQL表中，具备事务与崩溃恢复能力
- 可靠性
  - 通过REPLACE写入保证幂等性
  - 读取时过期清理避免脏数据
  - 错误状态透传，便于上层感知与重试
- 一致性
  - JSON序列化确保复杂对象的一致存储与读取

章节来源
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L37-L68)
- [misc.func.php](file://xiunophp/misc.func.php#L274-L278)

### 高并发场景下的表现与瓶颈
- 优势
  - MyISAM在读多写少场景下性能稳定
  - 主键索引支持快速定位
- 潜在瓶颈
  - MyISAM表级锁在高并发写入时可能成为瓶颈
  - mediumtext字段对单条记录大小有限制
  - 读取时过期清理属于“惰性”策略，极端情况下可能产生少量过期记录
- 建议
  - 结合业务特征评估是否切换InnoDB或引入Redis/Memcached作为热点缓存
  - 控制缓存值大小，避免超过mediumtext上限
  - 对频繁过期的键，考虑缩短life或在应用层主动清理

章节来源
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L37-L68)
- [install.sql](file://install/install.sql#L257-L273)

## 依赖关系分析
- 组件耦合
  - cache_mysql依赖db通用函数完成数据库操作
  - cache_func通过工厂模式选择具体缓存实现
  - JSON工具用于序列化/反序列化
- 外部依赖
  - MySQL数据库
  - PHP运行时（JSON扩展）
- 循环依赖
  - 无循环依赖，职责清晰

```mermaid
graph LR
CF["cache.func.php"] --> CM["cache_mysql.class.php"]
CM --> DF["db.func.php"]
CM --> MISC["misc.func.php"]
DF --> SQL["install.sql"]
```

图表来源
- [cache.func.php](file://xiunophp/cache.func.php#L3-L21)
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L13-L33)
- [db.func.php](file://xiunophp/db.func.php#L4-L25)
- [misc.func.php](file://xiunophp/misc.func.php#L274-L278)
- [install.sql](file://install/install.sql#L257-L273)

章节来源
- [cache.func.php](file://xiunophp/cache.func.php#L3-L21)
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L13-L33)
- [db.func.php](file://xiunophp/db.func.php#L4-L25)
- [misc.func.php](file://xiunophp/misc.func.php#L274-L278)
- [install.sql](file://install/install.sql#L257-L273)

## 性能考量
- 表结构与引擎
  - MyISAM适合读多写少的缓存场景，但注意表级锁与崩溃恢复
  - 若写入频繁，可考虑InnoDB或引入Redis/Memcached
- 字段大小控制
  - mediumtext单条记录大小受限，建议控制缓存值大小
- 过期策略
  - 惰性过期清理在读取时触发，避免额外后台任务
- 并发写入
  - MyISAM表级锁可能导致写入竞争，建议评估锁粒度与业务特征
- 配置建议
  - cachepre前缀用于隔离不同站点或环境
  - cache.type=mysql在conf.default.php中配置

章节来源
- [install.sql](file://install/install.sql#L257-L273)
- [conf.default.php](file://conf/conf.default.php#L39-L64)
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L37-L68)

## 故障排查指南
- 常见错误与定位
  - errno/errstr：cache_mysql在底层操作失败时会将db的错误状态复制到自身
  - db_errstr_safe：对常见MySQL错误码进行友好化提示
- 排查步骤
  - 检查数据库连接配置与权限
  - 确认缓存表是否存在且结构正确
  - 关注JSON序列化/反序列化异常
  - 观察过期键是否被及时清理
- 建议
  - 在DEBUG模式下启用SQL日志，便于定位问题
  - 对频繁失败的操作增加重试逻辑

章节来源
- [cache_mysql.class.php](file://xiunophp/cache_mysql.class.php#L46-L49)
- [db.func.php](file://xiunophp/db.func.php#L201-L224)

## 结论
cache_mysql类以简洁的REPLACE写入与主键索引读取为核心，实现了可靠的MySQL缓存能力。配合惰性过期清理与JSON序列化，能够在大多数应用场景下提供稳定的性能与易维护性。对于高并发写入或超大缓存值的场景，建议结合业务特征评估是否引入Redis/Memcached或调整表结构/引擎。通过合理的配置与监控，MySQL缓存可作为XiunoBBS 4.0的可靠持久化缓存方案。