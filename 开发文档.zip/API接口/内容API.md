# 内容API

<cite>
**本文引用的文件**
- [route/attach.php](file://route/attach.php)
- [model/attach.func.php](file://model/attach.func.php)
- [model/post.func.php](file://model/post.func.php)
- [model/forum_access.func.php](file://model/forum_access.func.php)
- [model/session.func.php](file://model/session.func.php)
- [conf/attach.conf.php](file://conf/attach.conf.php)
- [xiunophp/image.func.php](file://xiunophp/image.func.php)
- [view/js/upload.js](file://view/js/upload.js)
- [view/js/xiuno.js](file://view/js/xiuno.js)
- [index.php](file://index.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)
10. [附录](#附录)

## 简介
本文件面向内容管理相关API，聚焦附件上传、图片处理、文件管理与下载等能力，涵盖以下要点：
- multipart/form-data 格式的文件上传流程与进度回调
- 服务端接收Base64数据流的临时存储与会话关联
- 图片缩略、裁剪、水印叠加与格式转换的前端处理与后端落盘
- 文件存储策略、访问权限控制与安全校验机制
- 错误处理与异常恢复，以及并发场景下的会话写入优化

## 项目结构
围绕内容API的关键目录与文件如下：
- 路由入口与控制器：route/attach.php
- 业务模型：model/attach.func.php、model/post.func.php、model/forum_access.func.php、model/session.func.php
- 配置：conf/attach.conf.php
- 图像处理：xiunophp/image.func.php
- 前端上传与图片处理：view/js/upload.js、view/js/xiuno.js
- 应用入口：index.php

```mermaid
graph TB
A["浏览器/前端"] --> B["路由: route/attach.php"]
B --> C["模型: model/attach.func.php"]
B --> D["模型: model/post.func.php"]
B --> E["权限: model/forum_access.func.php"]
B --> F["会话: model/session.func.php"]
C --> G["配置: conf/attach.conf.php"]
A --> H["前端: view/js/upload.js"]
A --> I["前端: view/js/xiuno.js"]
I --> J["图像处理: xiunophp/image.func.php"]
A --> K["应用入口: index.php"]
```

图表来源
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/post.func.php](file://model/post.func.php#L1-L200)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/session.func.php](file://model/session.func.php#L1-L150)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L1-L287)
- [view/js/upload.js](file://view/js/upload.js#L1-L206)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [index.php](file://index.php#L1-L56)

章节来源
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/post.func.php](file://model/post.func.php#L1-L200)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/session.func.php](file://model/session.func.php#L1-L150)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L1-L287)
- [view/js/upload.js](file://view/js/upload.js#L1-L206)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [index.php](file://index.php#L1-L56)

## 核心组件
- 附件上传与下载
  - 通过路由 route/attach.php 提供 create/delete/download 接口，支持Base64数据流上传与临时会话存储，以及正式发布时的关联落盘。
- 附件模型与归档
  - model/attach.func.php 提供附件的创建、读取、更新、删除、查找、格式化、垃圾清理与与帖子消息关联等功能。
- 权限与访问控制
  - model/forum_access.func.php 提供用户与版主权限判定，确保下载与删除操作的合法性。
- 图像处理与水印
  - view/js/xiuno.js 与 view/js/upload.js 在前端完成图片缩略、裁剪与水印叠加；xiunophp/image.func.php 提供服务端安全缩略与命名规则。
- 会话与并发控制
  - model/session.func.php 通过延迟更新与“丢弃旧会话数据、重启会话”的方式降低并发写入冲突；route/attach.php 在上传流程中显式调用会话重启。

章节来源
- [route/attach.php](file://route/attach.php#L9-L179)
- [model/attach.func.php](file://model/attach.func.php#L44-L272)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [view/js/upload.js](file://view/js/upload.js#L107-L206)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L88-L164)
- [model/session.func.php](file://model/session.func.php#L105-L150)

## 架构总览
内容API整体交互流程如下：

```mermaid
sequenceDiagram
participant U as "用户/客户端"
participant JS as "前端上传脚本<br/>view/js/xiuno.js/view/js/upload.js"
participant R as "路由 : route/attach.php"
participant S as "会话 : model/session.func.php"
participant M as "模型 : model/attach.func.php"
participant P as "模型 : model/post.func.php"
participant IMG as "图像处理 : xiunophp/image.func.php"
U->>JS : 选择文件/粘贴图片
JS->>JS : 前端缩略/裁剪/水印<br/>生成Base64数据
JS->>R : POST multipart/form-data<br/>name/data/width/height/is_image
R->>S : 会话重启/并发写入保护
R->>R : 校验尺寸/类型/权限
R->>M : 临时文件写入/保存至会话
U->>P : 发布帖子/编辑内容
P->>M : 关联会话中的临时附件并落盘
M->>IMG : 安全缩略/命名/目录分层
R-->>U : 返回附件信息/URL
```

图表来源
- [route/attach.php](file://route/attach.php#L9-L76)
- [model/session.func.php](file://model/session.func.php#L105-L150)
- [model/attach.func.php](file://model/attach.func.php#L175-L272)
- [model/post.func.php](file://model/post.func.php#L50-L114)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L88-L164)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [view/js/upload.js](file://view/js/upload.js#L107-L206)

## 详细组件分析

### 附件上传接口（Base64流 + 临时会话）
- 请求方式与参数
  - 方法：POST
  - 路由：/route/attach.php?action=create
  - 参数：name（原始文件名）、data（Base64编码的二进制数据）、width/height/is_image（可选，图片元信息）
- 服务端处理流程
  - 登录态校验与用户组权限检查
  - 校验文件大小上限（默认20MB）
  - 解析扩展名并归类到附件类型（参考 conf/attach.conf.php）
  - 将数据写入 upload/tmp 目录的临时文件，同时将附件信息写入会话（tmp_files）
  - 返回临时附件信息（不含路径），用于后续发布时关联
- 进度与并发
  - 前端通过 XMLHttpRequest 的 upload.onprogress 回调上报进度
  - 服务端在上传前执行会话重启，降低并发写入冲突
- 错误处理
  - 空数据、超限、类型不被允许、写入失败等情况均返回错误码与提示

```mermaid
flowchart TD
Start(["开始: 接收POST请求"]) --> CheckLogin["校验登录与权限"]
CheckLogin --> ValidateSize["校验文件大小/扩展名"]
ValidateSize --> WriteTmp["写入upload/tmp临时文件"]
WriteTmp --> SaveToSession["保存到会话: tmp_files"]
SaveToSession --> ReturnTmp["返回临时附件信息"]
ReturnTmp --> End(["结束"])
```

图表来源
- [route/attach.php](file://route/attach.php#L9-L76)
- [model/session.func.php](file://model/session.func.php#L105-L150)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)

章节来源
- [route/attach.php](file://route/attach.php#L9-L76)
- [model/session.func.php](file://model/session.func.php#L105-L150)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)

### 附件发布关联与落盘
- 触发时机
  - 用户提交发帖或编辑内容时，调用 attach_assoc_post(pid)
- 处理流程
  - 读取会话中的临时附件列表
  - 按日期规则生成目标目录（attach_dir_save_rule），移动并重命名
  - 插入数据库记录，更新帖子消息中的图片URL
  - 清空会话临时数据
  - 更新帖子/主题的图片/文件计数
- 安全与命名
  - 使用安全文件名与目录分层（按时间维度），避免目录过深与文件过多

```mermaid
sequenceDiagram
participant P as "帖子模型 : model/post.func.php"
participant A as "附件模型 : model/attach.func.php"
participant IMG as "图像处理 : xiunophp/image.func.php"
P->>A : attach_assoc_post(pid)
A->>A : 读取会话tmp_files
A->>IMG : 安全缩略/命名/目录分层
A->>A : 写入数据库并替换消息中的URL
A-->>P : 返回关联结果
```

图表来源
- [model/post.func.php](file://model/post.func.php#L50-L114)
- [model/attach.func.php](file://model/attach.func.php#L175-L272)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L273-L282)

章节来源
- [model/post.func.php](file://model/post.func.php#L50-L114)
- [model/attach.func.php](file://model/attach.func.php#L175-L272)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L273-L282)

### 附件删除与下载
- 删除
  - 临时附件：根据会话索引删除 upload/tmp 中的文件并清理会话
  - 已发布附件：校验权限（版主或作者本人），删除物理文件与数据库记录
- 下载
  - 校验用户对板块的下载权限
  - 设置响应头（含缓存控制、文件名编码），输出文件内容或跳转到静态URL

```mermaid
flowchart TD
DStart(["删除/下载入口"]) --> IsTemp{"是否临时附件?"}
IsTemp -- 是 --> DelTmp["删除upload/tmp文件并清理会话"]
IsTemp -- 否 --> CheckPerm["校验下载/删除权限"]
CheckPerm --> DelOrOut{"删除还是输出?"}
DelOrOut -- 删除 --> DoDel["删除物理文件与记录"]
DelOrOut -- 输出 --> OutFile["设置响应头并输出文件"]
DelTmp --> DEnd(["结束"])
DoDel --> DEnd
OutFile --> DEnd
```

图表来源
- [route/attach.php](file://route/attach.php#L78-L179)
- [model/attach.func.php](file://model/attach.func.php#L66-L76)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)

章节来源
- [route/attach.php](file://route/attach.php#L78-L179)
- [model/attach.func.php](file://model/attach.func.php#L66-L76)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)

### 图片处理与水印（前端）
- 功能特性
  - 缩略：按目标宽高等比缩放
  - 裁剪：按目标宽高在中心区域裁剪
  - 水印：在右下角叠加透明水印（可配置水印图）
  - 格式转换：支持 jpeg/png/gif（gif不缩放）
- 前端实现
  - view/js/xiuno.js 的 xn.image_resize 完成Canvas处理与toDataURL导出
  - view/js/upload.js 的 FileUploader 提供批量上传与进度回调

```mermaid
flowchart TD
ImgIn["输入Base64图片"] --> Detect["检测Action: thumb/clip"]
Detect --> Canvas["创建Canvas并绘制"]
Canvas --> Water["按需叠加水印"]
Water --> Export["toDataURL导出为目标格式"]
Export --> Send["发送name/data/width/height"]
```

图表来源
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [view/js/upload.js](file://view/js/upload.js#L107-L206)

章节来源
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [view/js/upload.js](file://view/js/upload.js#L107-L206)

### 服务端安全缩略与命名
- 目录分层：按ID分组（三位一组），避免单目录文件过多
- 安全命名：去除非法字符，必要时追加时间戳与随机数
- 缩略算法：等比缩放，保证不超过目标尺寸
- 临时文件：使用临时目录，完成后复制到目标位置并清理

```mermaid
flowchart TD
Src["源文件"] --> SafeName["安全命名"]
SafeName --> Dir["目录分层"]
Dir --> Thumb["生成缩略图"]
Thumb --> Copy["复制到目标并清理临时文件"]
```

图表来源
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L24-L79)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L88-L164)

章节来源
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L24-L164)

### 权限控制与访问校验
- 用户权限
  - forum_access_user(fid, gid, allowattach/allowdown/...) 判断用户是否允许上传/下载
- 版主权限
  - forum_access_mod(fid, gid, allowdelete/...) 判断是否允许删除他人附件
- 下载响应
  - 设置缓存头与文件名编码，适配不同浏览器

章节来源
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)
- [route/attach.php](file://route/attach.php#L116-L179)

### 会话并发与安全
- 会话写入优化
  - 延迟更新：减少非关键字段频繁写入
  - 大数据拆分：超长会话数据写入额外表
- 上传流程中的会话重启
  - 避免多并发请求同时写入同一会话，降低竞争风险

章节来源
- [model/session.func.php](file://model/session.func.php#L105-L150)
- [route/attach.php](file://route/attach.php#L53-L53)

## 依赖关系分析
- 路由依赖模型与权限模块，模型依赖配置与图像处理库
- 前端脚本依赖应用入口提供的全局配置与工具函数

```mermaid
graph LR
R["route/attach.php"] --> M1["model/attach.func.php"]
R --> M2["model/post.func.php"]
R --> M3["model/forum_access.func.php"]
R --> S["model/session.func.php"]
M1 --> C["conf/attach.conf.php"]
M2 --> M1
JS1["view/js/xiuno.js"] --> IMG["xiunophp/image.func.php"]
JS2["view/js/upload.js"] --> R
IDX["index.php"] --> JS1
IDX --> JS2
```

图表来源
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/post.func.php](file://model/post.func.php#L1-L200)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/session.func.php](file://model/session.func.php#L1-L150)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L1-L287)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [view/js/upload.js](file://view/js/upload.js#L1-L206)
- [index.php](file://index.php#L1-L56)

章节来源
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/post.func.php](file://model/post.func.php#L1-L200)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/session.func.php](file://model/session.func.php#L1-L150)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [xiunophp/image.func.php](file://xiunophp/image.func.php#L1-L287)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [view/js/upload.js](file://view/js/upload.js#L1-L206)
- [index.php](file://index.php#L1-L56)

## 性能考量
- 前端压缩与缩略
  - 在上传前进行Canvas缩略与水印，减少带宽与服务器压力
- 目录分层与命名
  - 采用安全命名与目录分层，避免文件系统性能退化
- 会话写入优化
  - 延迟更新与会话重启，降低并发写入冲突
- 缓存控制
  - 下载响应设置缓存头，提升静态资源访问效率

## 故障排查指南
- 上传失败
  - 检查文件大小是否超过限制、扩展名是否在允许列表、用户是否有上传权限
  - 查看会话是否正确写入临时附件
- 下载失败
  - 校验用户对板块的下载权限；确认文件是否存在且未被清理
- 图片处理异常
  - 确认前端Action参数（thumb/clip）与目标尺寸；检查水印图加载状态
- 并发冲突
  - 若出现会话写入冲突，确认是否在上传前执行了会话重启

章节来源
- [route/attach.php](file://route/attach.php#L26-L31)
- [model/attach.func.php](file://model/attach.func.php#L158-L172)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [model/session.func.php](file://model/session.func.php#L105-L150)

## 结论
本内容API以“前端预处理 + 服务端安全落盘”为核心设计，结合会话并发优化与严格的权限控制，实现了稳定高效的附件上传与图片处理能力。通过目录分层与命名策略，兼顾了性能与可维护性；通过水印与格式转换，满足多样化媒体需求。

## 附录
- 配置项参考
  - 附件类型与扩展名映射：见 conf/attach.conf.php
  - 上传路径与URL：由应用入口 index.php 初始化并注入全局配置
- 前端工具
  - 图片缩略/裁剪/水印：view/js/xiuno.js
  - 批量上传与进度回调：view/js/upload.js

章节来源
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [index.php](file://index.php#L25-L39)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1193-L1392)
- [view/js/upload.js](file://view/js/upload.js#L107-L206)