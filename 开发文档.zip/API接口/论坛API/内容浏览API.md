# 内容浏览API

<cite>
**本文档引用的文件**
- [route/attach.php](file://route/attach.php)
- [model/attach.func.php](file://model/attach.func.php)
- [model/forum_access.func.php](file://model/forum_access.func.php)
- [model/post.func.php](file://model/post.func.php)
- [conf/attach.conf.php](file://conf/attach.conf.php)
- [conf/conf.default.php](file://conf/conf.default.php)
- [route/browser.php](file://route/browser.php)
- [view/htm/browser.htm](file://view/htm/browser.htm)
- [view/js/xiuno.js](file://view/js/xiuno.js)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php)
- [model/misc.func.php](file://model/misc.func.php)
</cite>

## 目录
1. [引言](#引言)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)
10. [附录](#附录)

## 引言
本文件面向内容浏览API，聚焦以下能力与实现要点：
- 内容预览：基于回帖内容的渲染与权限过滤，以及附件列表生成。
- 图片浏览：图片类型识别、缩略与展示策略（结合配置项）。
- 附件下载：权限校验、浏览器兼容性处理、缓存头与下载计数。
- 浏览器兼容性：针对IE/Edge等旧内核的文件名编码与响应头适配。
- 安全与权限：基于用户组与板块访问控制的综合判定。
- 性能优化：缓存机制、CDN集成、请求路径与URL重写策略。
- 多媒体处理：附件类型分类、图片处理工具函数。
- 最佳实践：用户体验优化建议与常见问题处理。

## 项目结构
围绕内容浏览API的关键模块分布如下：
- 路由层：处理附件上传、删除、下载等入口路由。
- 模型层：封装附件、论坛访问权限、回帖内容格式化等核心逻辑。
- 配置层：附件类型白名单、上传路径/URL、CDN开关、URL重写等。
- 视图与前端：浏览器提示页、图片处理工具、通用URL生成与消息输出。

```mermaid
graph TB
subgraph "路由层"
RAttach["route/attach.php"]
RBrowser["route/browser.php"]
end
subgraph "模型层"
MAttach["model/attach.func.php"]
MForumAccess["model/forum_access.func.php"]
MPost["model/post.func.php"]
end
subgraph "配置层"
CAttach["conf/attach.conf.php"]
CConf["conf/conf.default.php"]
end
subgraph "视图与前端"
VBrowser["view/htm/browser.htm"]
FXiuno["view/js/xiuno.js"]
end
subgraph "通用工具"
UCache["xiunophp/cache.func.php"]
UMisc["model/misc.func.php"]
end
RAttach --> MAttach
RAttach --> MForumAccess
RAttach --> MPost
RAttach --> CAttach
RAttach --> CConf
RAttach --> UCache
RAttach --> UMisc
RBrowser --> VBrowser
FXiuno -.-> RAttach
```

**图表来源**
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [route/browser.php](file://route/browser.php#L1-L23)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1062-L1191)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L1-L70)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)

**章节来源**
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [route/browser.php](file://route/browser.php#L1-L23)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1062-L1191)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L1-L70)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)

## 核心组件
- 附件路由与下载
  - 提供附件上传、删除、下载的统一入口，包含尺寸限制、类型检查、权限校验与浏览器兼容处理。
- 附件模型
  - 提供附件的增删改查、格式化、类型判定、临时文件关联、垃圾清理等。
- 论坛访问权限
  - 提供普通用户与版主权限的综合判定，支持按板块与用户组组合的细粒度控制。
- 回帖内容与附件列表
  - 回帖格式化时注入附件列表，支持文件/图片两类附件的HTML模板生成。
- 附件类型配置
  - 定义各类附件类型的扩展名集合，用于上传与展示的分类。
- 配置与CDN
  - 上传路径/URL、CDN开关、URL重写策略、缓存配置等。
- 浏览器提示
  - 针对低版本浏览器的引导页面与跳转策略。
- 前端工具
  - 图片背景透明处理、图片类型识别等工具函数。

**章节来源**
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)
- [model/post.func.php](file://model/post.func.php#L286-L311)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [conf/conf.default.php](file://conf/conf.default.php#L68-L122)
- [route/browser.php](file://route/browser.php#L1-L23)
- [view/js/xiuno.js](file://view/js/xiuno.js#L1062-L1191)

## 架构总览
内容浏览API的调用链路与职责划分如下：

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Route as "路由(route/attach.php)"
participant ModelAttach as "模型(model/attach.func.php)"
participant ModelAccess as "权限(model/forum_access.func.php)"
participant Post as "回帖(model/post.func.php)"
participant Conf as "配置(conf/attach.conf.php, conf/conf.default.php)"
Client->>Route : "POST/GET 请求"
Route->>ModelAccess : "权限校验(allowdown/allowread)"
ModelAccess-->>Route : "允许/拒绝"
alt 下载场景
Route->>ModelAttach : "读取附件元数据"
ModelAttach-->>Route : "返回附件信息"
Route->>Route : "浏览器兼容处理(文件名编码/响应头)"
Route-->>Client : "二进制流/重定向"
else 附件列表/预览
Route->>Post : "回帖格式化并生成附件列表"
Post-->>Route : "返回带附件的回帖"
Route-->>Client : "HTML/JSON"
end
Route->>Conf : "读取上传路径/URL/CDN配置"
Conf-->>Route : "返回配置"
```

**图表来源**
- [route/attach.php](file://route/attach.php#L116-L179)
- [model/attach.func.php](file://model/attach.func.php#L58-L64)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)
- [model/post.func.php](file://model/post.func.php#L286-L311)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [conf/conf.default.php](file://conf/conf.default.php#L68-L122)

## 详细组件分析

### 组件A：附件下载流程
- 功能要点
  - 权限校验：基于板块访问控制，判断用户是否有下载权限。
  - 文件存在性校验：确保物理文件存在。
  - 浏览器兼容：对IE/Edge内核进行文件名URL编码处理。
  - 响应头：设置缓存控制、传输编码、内容类型与下载行为。
  - 计数更新：下载次数自增。
- 关键路径
  - 路由入口与权限判断：[route/attach.php](file://route/attach.php#L116-L129)
  - 读取附件与物理路径：[route/attach.php](file://route/attach.php#L120-L132)
  - 浏览器兼容处理与响应头设置：[route/attach.php](file://route/attach.php#L144-L157)
  - 下载计数更新与文件输出：[route/attach.php](file://route/attach.php#L141-L162)
  - 附件模型读取与格式化：[model/attach.func.php](file://model/attach.func.php#L58-L64)

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Attach as "路由(route/attach.php)"
participant Access as "权限(model/forum_access.func.php)"
participant DB as "附件模型(model/attach.func.php)"
participant FS as "文件系统"
Client->>Attach : "GET /attach-download-{aid}"
Attach->>Access : "forum_access_user(fid,gid,'allowdown')"
Access-->>Attach : "允许/拒绝"
Attach->>DB : "attach_read(aid)"
DB-->>Attach : "返回附件元数据"
Attach->>FS : "检查文件是否存在"
Attach->>Attach : "IE/Edge文件名编码处理"
Attach->>Client : "设置响应头并输出文件"
Attach->>DB : "attach_update(downloads+1)"
```

**图表来源**
- [route/attach.php](file://route/attach.php#L116-L179)
- [model/attach.func.php](file://model/attach.func.php#L58-L64)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L139)

**章节来源**
- [route/attach.php](file://route/attach.php#L116-L179)
- [model/attach.func.php](file://model/attach.func.php#L58-L64)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L139)

### 组件B：附件上传与临时文件管理
- 功能要点
  - 登录校验与用户组权限：禁止未登录或无权限用户上传。
  - 上传限制：大小上限、扩展名白名单、类型判定。
  - 临时文件存储：写入临时目录，保存至会话，便于后续关联到回帖。
  - 会话重启：降低并发写入冲突。
- 关键路径
  - 登录与权限校验：[route/attach.php](file://route/attach.php#L9-L26)
  - 上传限制与类型判定：[route/attach.php](file://route/attach.php#L14-L36)
  - 临时文件写入与会话保存：[route/attach.php](file://route/attach.php#L46-L70)
  - 会话重启与并发优化：[route/attach.php](file://route/attach.php#L53-L53)

```mermaid
flowchart TD
Start(["进入上传"]) --> Login["登录校验"]
Login --> Perm{"用户组允许上传?"}
Perm --> |否| Deny["返回权限错误"]
Perm --> |是| Size["校验文件大小/扩展名"]
Size --> Type["判定附件类型"]
Type --> SaveTmp["写入临时目录"]
SaveTmp --> Session["保存到会话(tmp_files)"]
Session --> Done(["返回临时附件信息"])
```

**图表来源**
- [route/attach.php](file://route/attach.php#L9-L76)

**章节来源**
- [route/attach.php](file://route/attach.php#L9-L76)

### 组件C：附件删除与清理
- 功能要点
  - 临时附件删除：直接删除临时文件并从会话移除。
  - 正式附件删除：校验归属与权限（作者或版主），删除物理文件并更新数据库。
  - 垃圾清理：定时扫描并清理超过一天未处理的临时文件。
- 关键路径
  - 临时删除逻辑：[route/attach.php](file://route/attach.php#L78-L114)
  - 正式删除与权限校验：[route/attach.php](file://route/attach.php#L96-L110)
  - 垃圾清理：[model/attach.func.php](file://model/attach.func.php#L159-L172)

```mermaid
flowchart TD
DelStart(["进入删除"]) --> AidType{"aid前缀"}
AidType --> |临时| TmpDel["删除临时文件并从会话移除"]
AidType --> |正式| CheckPerm["校验归属/权限"]
CheckPerm --> DeleteFile["删除物理文件"]
DeleteFile --> DBDelete["删除数据库记录"]
TmpDel --> Done(["完成"])
DBDelete --> Done
```

**图表来源**
- [route/attach.php](file://route/attach.php#L78-L114)
- [model/attach.func.php](file://model/attach.func.php#L66-L76)

**章节来源**
- [route/attach.php](file://route/attach.php#L78-L114)
- [model/attach.func.php](file://model/attach.func.php#L66-L76)
- [model/attach.func.php](file://model/attach.func.php#L159-L172)

### 组件D：回帖内容与附件列表
- 功能要点
  - 回帖格式化：注入用户信息、楼层、权限标记、附件列表。
  - 附件列表HTML：根据文件类型生成图标与链接。
  - 附件数量统计：更新回帖与主题的图片/文件计数。
- 关键路径
  - 附件列表生成：[model/post.func.php](file://model/post.func.php#L286-L311)
  - 回帖格式化与附件注入：[model/post.func.php](file://model/post.func.php#L313-L346)
  - 附件数量统计更新：[model/post.func.php](file://model/post.func.php#L155-L166)

```mermaid
classDiagram
class PostModel {
+post_format(post)
+post_file_list_html(filelist, include_delete)
+post_read(pid)
+post_update(pid, arr)
}
class AttachModel {
+attach_find_by_pid(pid)
+attach_format(attach)
}
PostModel --> AttachModel : "生成附件列表"
```

**图表来源**
- [model/post.func.php](file://model/post.func.php#L286-L346)
- [model/attach.func.php](file://model/attach.func.php#L112-L124)

**章节来源**
- [model/post.func.php](file://model/post.func.php#L286-L346)
- [model/attach.func.php](file://model/attach.func.php#L112-L124)

### 组件E：浏览器兼容性处理
- 功能要点
  - IE/Edge内核对文件名编码的特殊处理，避免中文文件名被替换为空格。
  - 通过响应头设置缓存控制与传输编码，提升下载稳定性。
- 关键路径
  - 文件名编码与响应头设置：[route/attach.php](file://route/attach.php#L144-L157)

```mermaid
flowchart TD
UA["检测User-Agent"] --> IE{"IE/Edge?"}
IE --> |是| Encode["URL编码文件名<br/>替换空格"]
IE --> |否| Normal["正常响应"]
Encode --> Header["设置缓存/传输头"]
Normal --> Header
Header --> Out["输出文件"]
```

**图表来源**
- [route/attach.php](file://route/attach.php#L144-L157)

**章节来源**
- [route/attach.php](file://route/attach.php#L144-L157)

### 组件F：浏览器提示与引导
- 功能要点
  - 针对低版本浏览器提供下载引导页，包含Chrome/Firefox/IE的下载链接。
  - 路由根据参数决定直接渲染页面或重定向到外部下载地址。
- 关键路径
  - 路由逻辑：[route/browser.php](file://route/browser.php#L7-L21)
  - 页面模板：[view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Browser as "路由(route/browser.php)"
participant View as "模板(view/htm/browser.htm)"
Client->>Browser : "GET /browser"
Browser->>View : "渲染浏览器提示页"
View-->>Client : "返回HTML"
```

**图表来源**
- [route/browser.php](file://route/browser.php#L7-L21)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)

**章节来源**
- [route/browser.php](file://route/browser.php#L7-L21)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)

### 组件G：多媒体内容处理与图片工具
- 功能要点
  - 图片背景透明处理：基于像素邻域传播算法处理背景透明。
  - 图片类型识别：根据Base64前缀识别图片类型。
- 关键路径
  - 背景透明处理：[view/js/xiuno.js](file://view/js/xiuno.js#L1062-L1179)
  - 图片类型识别：[view/js/xiuno.js](file://view/js/xiuno.js#L1181-L1191)

```mermaid
flowchart TD
ImgIn["输入图片数据"] --> Detect["识别图片类型"]
Detect --> Process["背景透明处理算法"]
Process --> ImgOut["输出处理后的图片数据"]
```

**图表来源**
- [view/js/xiuno.js](file://view/js/xiuno.js#L1062-L1191)

**章节来源**
- [view/js/xiuno.js](file://view/js/xiuno.js#L1062-L1191)

## 依赖关系分析
- 路由依赖模型与配置
  - 附件路由依赖权限模型与附件模型；同时读取附件类型配置与全局配置。
- 模型间耦合
  - 回帖模型依赖附件模型以生成附件列表；附件模型依赖配置以确定URL与路径。
- 前端与后端协作
  - 前端工具函数辅助上传与图片处理；路由负责权限与下载响应。

```mermaid
graph LR
RouteAttach["route/attach.php"] --> ModelAttach["model/attach.func.php"]
RouteAttach --> ModelAccess["model/forum_access.func.php"]
RouteAttach --> ModelPost["model/post.func.php"]
RouteAttach --> ConfAttach["conf/attach.conf.php"]
RouteAttach --> ConfDefault["conf/conf.default.php"]
ModelPost --> ModelAttach
```

**图表来源**
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)

**章节来源**
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [conf/attach.conf.php](file://conf/attach.conf.php#L1-L22)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)

## 性能考量
- 缓存机制
  - 支持多种缓存后端（Redis/Memcached/MySQL/XCache/APC/Yac），可通过配置启用。
  - 通用缓存接口提供get/set/delete/truncate等操作。
- CDN集成
  - 通过配置开启CDN，分别设置view与upload的CDN域名，减少静态资源与附件的带宽压力。
- URL重写与路径
  - 支持多种URL格式，配合CDN与反向代理提升SEO与加载速度。
- 附件存储策略
  - 可配置附件按年月目录分片存储，降低单目录文件过多带来的I/O压力。
- 前端优化
  - 使用jQuery/Ajax进行异步上传与进度反馈，减少页面刷新。
- 会话与并发
  - 上传时重启会话以降低并发写入冲突风险。

**章节来源**
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L1-L70)
- [conf/conf.default.php](file://conf/conf.default.php#L39-L122)
- [route/attach.php](file://route/attach.php#L53-L53)
- [model/attach.func.php](file://model/attach.func.php#L200-L212)

## 故障排查指南
- 下载失败
  - 检查权限：确认用户组与板块访问控制是否允许下载。
  - 检查文件存在性：确认物理文件是否存在。
  - 浏览器兼容：确认IE/Edge下的文件名编码是否正确。
- 上传失败
  - 检查大小限制与扩展名白名单。
  - 检查临时目录写入权限与会话状态。
- 附件未显示
  - 检查回帖格式化是否正确注入附件列表。
  - 检查附件类型判定与URL拼接。
- 性能问题
  - 检查缓存后端是否启用与可用。
  - 检查CDN配置与URL重写设置。
  - 检查附件目录分片策略与磁盘I/O。

**章节来源**
- [route/attach.php](file://route/attach.php#L116-L179)
- [model/attach.func.php](file://model/attach.func.php#L58-L64)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L139)
- [model/post.func.php](file://model/post.func.php#L286-L311)
- [conf/conf.default.php](file://conf/conf.default.php#L68-L122)

## 结论
内容浏览API围绕“权限校验—数据读取—响应输出”形成闭环，具备完善的浏览器兼容处理与安全控制。通过配置化的CDN与缓存策略，可在保证安全性的同时显著提升性能与用户体验。附件上传/删除/下载流程清晰，与回帖内容渲染紧密耦合，满足多类型多媒体内容的浏览需求。

## 附录
- 最佳实践
  - 优先使用CDN与URL重写，减少主站带宽压力。
  - 启用合适的缓存后端，合理设置缓存生命周期。
  - 严格控制附件类型白名单，避免恶意文件上传。
  - 对图片类附件进行必要的缩略与水印处理，兼顾性能与版权保护。
  - 在下载场景下，结合浏览器兼容处理与响应头优化，提升兼容性与稳定性。
- 用户体验优化
  - 异步上传与进度反馈，减少等待时间。
  - 针对低版本浏览器提供明确的升级引导。
  - 附件列表清晰展示文件类型与大小，便于用户选择。