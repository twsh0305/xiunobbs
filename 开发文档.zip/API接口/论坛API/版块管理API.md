# 版块管理API

<cite>
**本文档引用的文件**
- [route/forum.php](file://route/forum.php)
- [model/forum.func.php](file://model/forum.func.php)
- [model/forum_access.func.php](file://model/forum_access.func.php)
- [admin/route/forum.php](file://admin/route/forum.php)
- [view/htm/forum.htm](file://view/htm/forum.htm)
- [model/thread.func.php](file://model/thread.func.php)
- [model/thread_top.func.php](file://model/thread_top.func.php)
- [model/misc.func.php](file://model/misc.func.php)
- [view/htm/header.inc.htm](file://view/htm/header.inc.htm)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概览](#架构概览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介

本文件为XiunoBBS系统的版块管理API提供详细的接口文档。该系统实现了完整的论坛功能，包括版块列表获取、版块详情查询、权限检查等功能。本文档重点说明以下方面：
- 版块列表获取接口的实现方式
- 版块详情查询接口的实现方式  
- 版块权限检查机制
- 路由参数、访问控制验证、分页机制和排序规则
- 版块数据结构、权限验证逻辑和错误处理机制
- 请求示例和响应格式
- 版块浏览权限、内容展示和SEO优化的相关API调用

## 项目结构

XiunoBBS采用经典的MVC架构模式，围绕论坛功能构建了完整的模块体系：

```mermaid
graph TB
subgraph "路由层"
RF["route/forum.php<br/>版块路由处理"]
AF["admin/route/forum.php<br/>管理员版块管理"]
end
subgraph "模型层"
FF["model/forum.func.php<br/>版块核心功能"]
FAF["model/forum_access.func.php<br/>版块权限控制"]
TF["model/thread.func.php<br/>主题查询"]
TTF["model/thread_top.func.php<br/>置顶主题"]
MF["model/misc.func.php<br/>通用工具"]
end
subgraph "视图层"
FH["view/htm/forum.htm<br/>版块模板"]
HIH["view/htm/header.inc.htm<br/>头部模板"]
end
RF --> FF
RF --> FAF
RF --> TF
RF --> TTF
AF --> FF
AF --> FAF
FF --> FH
TF --> FH
FAF --> FH
MF --> RF
MF --> AF
FH --> HIH
```

**图表来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [admin/route/forum.php](file://admin/route/forum.php#L1-L261)
- [model/forum.func.php](file://model/forum.func.php#L1-L210)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)

**章节来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [admin/route/forum.php](file://admin/route/forum.php#L1-L261)

## 核心组件

### 版块路由处理器

版块路由处理器负责处理版块相关的HTTP请求，实现版块列表展示和权限验证功能。

**路由参数定义**：
- `fid`: 版块ID（必填）
- `page`: 页码，默认为1
- `orderby`: 排序字段，支持'tid'和'lastpid'

**核心流程**：
1. 参数解析和验证
2. 版块信息读取
3. 权限检查
4. 主题列表查询
5. 分页计算
6. SEO元数据设置

**章节来源**
- [route/forum.php](file://route/forum.php#L6-L17)

### 版块数据模型

版块数据模型提供了完整的版块CRUD操作和权限管理功能。

**主要功能**：
- 版块基础操作：创建、更新、读取、删除
- 版块列表查询和格式化
- 权限过滤和访问控制
- 缓存管理和性能优化

**章节来源**
- [model/forum.func.php](file://model/forum.func.php#L7-L120)

### 权限控制系统

权限控制系统实现了细粒度的版块访问控制，支持普通用户和版主权限分离。

**权限类型**：
- 浏览权限：allowread
- 发帖权限：allowthread
- 回帖权限：allowpost
- 附件权限：allowattach
- 下载权限：allowdown

**权限级别**：
- 管理员组（gid=1,2）：拥有所有权限
- 版主组（gid=3,4）：仅对特定版块有效
- 普通用户组：基于配置的默认权限

**章节来源**
- [model/forum_access.func.php](file://model/forum_access.func.php#L126-L162)

## 架构概览

系统采用分层架构设计，各层职责明确，耦合度低：

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Route as "路由处理器"
participant Model as "数据模型"
participant View as "视图模板"
participant DB as "数据库"
Client->>Route : GET /forum-{fid}-{page}?orderby={field}
Route->>Model : forum_read(fid)
Model->>DB : 查询版块信息
DB-->>Model : 版块数据
Model-->>Route : 格式化后的版块信息
Route->>Model : forum_access_user(fid, gid, 'allowread')
Model-->>Route : 权限验证结果
alt 权限通过
Route->>Model : thread_find_by_fid(fid, page, pagesize, orderby)
Model->>DB : 查询主题列表
DB-->>Model : 主题数据
Model-->>Route : 格式化后的主题列表
Route->>View : 渲染版块页面
View-->>Client : HTML页面
else 权限不足
Route-->>Client : 错误响应
end
```

**图表来源**
- [route/forum.php](file://route/forum.php#L15-L32)
- [model/forum_access.func.php](file://model/forum_access.func.php#L126-L139)

## 详细组件分析

### 版块列表获取接口

#### 接口定义

**URL模式**：`/forum-{fid}-{page}` 或 `/forum-{fid}?orderby={field}&page={num}`

**请求方法**：GET

**路由参数**：
- `{fid}`: 版块ID（必需）
- `{page}`: 页码（可选，默认1）
- `orderby`: 排序方式（可选，默认'lastpid'）

**查询参数**：
- `orderby`: 排序字段（'tid'或'lastpid'）
- `page`: 页码（数字）

#### 处理流程

```mermaid
flowchart TD
Start([请求到达]) --> ParseParam["解析路由参数"]
ParseParam --> ValidateFid{"验证版块ID"}
ValidateFid --> |无效| Error404["返回404错误"]
ValidateFid --> |有效| LoadForum["加载版块信息"]
LoadForum --> CheckAccess["检查浏览权限"]
CheckAccess --> |无权限| Error403["返回403错误"]
CheckAccess --> |有权限| SetOrderby["设置排序规则"]
SetOrderby --> GetTopList["获取置顶主题"]
GetTopList --> CalcPagination["计算分页信息"]
CalcPagination --> QueryThreads["查询主题列表"]
QueryThreads --> FormatData["格式化数据"]
FormatData --> RenderTemplate["渲染模板"]
RenderTemplate --> End([响应完成])
Error404 --> End
Error403 --> End
```

**图表来源**
- [route/forum.php](file://route/forum.php#L6-L32)

#### 数据结构

**版块基本信息**：
- `fid`: 版块ID
- `name`: 版块名称
- `brief`: 版块简介
- `threads`: 主题总数
- `todayposts`: 今日回帖数
- `todaythreads`: 今日主题数
- `icon_url`: 图标URL
- `modlist`: 版主列表
- `accesslist`: 权限配置

**主题列表项**：
- `tid`: 主题ID
- `subject`: 主题标题
- `uid`: 发帖用户ID
- `create_date`: 创建时间
- `last_date`: 最后回复时间
- `top`: 置顶级别
- `views`: 查看次数

#### 排序规则

系统支持两种排序方式：
- `tid`: 按主题创建时间排序（新主题在前）
- `lastpid`: 按最后回复时间排序（最新回复在前）

排序规则通过`orderby`参数控制，默认使用`lastpid`。

#### 分页机制

**分页配置**：
- 每页显示数量：由系统配置决定
- 总记录数：从版块信息中获取
- 页码限制：第100页以后进行特殊处理

**性能优化**：
- 对第100页以后的请求进行安全限制
- 使用缓存减少数据库查询
- 置顶主题优先显示

**章节来源**
- [route/forum.php](file://route/forum.php#L11-L32)
- [model/thread.func.php](file://model/thread.func.php#L220-L253)

### 版块详情查询接口

#### 接口定义

**URL模式**：`/forum-{fid}`

**请求方法**：GET

**路由参数**：
- `{fid}`: 版块ID（必需）

#### 处理流程

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Route as "路由处理器"
participant Forum as "版块模型"
participant Access as "权限模型"
participant Template as "模板引擎"
Client->>Route : GET /forum-{fid}
Route->>Forum : forum_read(fid)
Forum->>Forum : 检查缓存
Forum-->>Route : 返回版块信息
Route->>Access : forum_access_user(fid, gid, 'allowread')
Access-->>Route : 返回权限结果
alt 权限验证通过
Route->>Template : 渲染版块详情
Template-->>Client : 返回HTML页面
else 权限验证失败
Route-->>Client : 返回错误信息
end
```

**图表来源**
- [route/forum.php](file://route/forum.php#L15-L17)
- [model/forum.func.php](file://model/forum.func.php#L60-L71)

#### SEO优化

系统自动为版块页面生成SEO元数据：

**页面标题**：
- 优先使用版块的SEO标题
- 否则使用"版块名称-站点名称"

**描述信息**：
- 使用版块简介作为页面描述
- 支持移动端标题和链接

**章节来源**
- [route/forum.php](file://route/forum.php#L34-L38)
- [view/htm/header.inc.htm](file://view/htm/header.inc.htm#L24-L28)

### 权限检查机制

#### 权限验证流程

```mermaid
flowchart TD
Start([开始权限检查]) --> CheckGroup{"检查用户组"}
CheckGroup --> |管理员组| AllowAll["允许所有操作"]
CheckGroup --> |版主组| CheckForum{"检查是否为版主"}
CheckGroup --> |普通用户| CheckDefault["检查默认权限"]
CheckForum --> |是版主| CheckAccess["检查具体权限"]
CheckForum --> |非版主| Deny["拒绝访问"]
CheckAccess --> Compare{"比较权限配置"}
Compare --> |有权限| Allow["允许访问"]
Compare --> |无权限| Deny
CheckDefault --> Compare
AllowAll --> Allow
Allow --> End([结束])
Deny --> End
```

**图表来源**
- [model/forum_access.func.php](file://model/forum_access.func.php#L126-L162)

#### 权限类型详解

**普通用户权限**：
- `allowread`: 浏览权限
- `allowthread`: 发帖权限
- `allowpost`: 回帖权限
- `allowattach`: 上传附件权限
- `allowdown`: 下载附件权限

**版主权限**：
- `allowtop`: 置顶主题权限
- `allowmove`: 移动主题权限
- `allowupdate`: 编辑主题权限
- `allowdelete`: 删除主题权限
- `allowbanuser`: 封禁用户权限
- `allowviewip`: 查看IP权限
- `allowdeleteuser`: 删除用户权限

#### 权限配置策略

**全局权限**：
- 管理员组（gid=1,2）：拥有所有权限
- 版主组（gid=3,4）：仅对指定版块有效

**版块级权限**：
- 当版块启用独立权限时，按版块配置执行
- 当版块使用默认权限时，按用户组默认权限执行

**章节来源**
- [model/forum_access.func.php](file://model/forum_access.func.php#L126-L162)

### 管理员版块管理API

管理员版块管理提供了完整的版块管理功能，包括列表管理、编辑修改和权限配置。

#### 列表管理接口

**接口定义**：
- URL: `/admin/forum`
- 方法: GET/POST

**GET请求**：
- 功能：显示版块列表管理界面
- 返回：版块列表页面

**POST请求**：
- 功能：批量更新版块信息
- 参数：包含版块ID、名称、排序等数组

#### 版块编辑接口

**接口定义**：
- URL: `/admin/forum/update/{fid}`
- 方法: GET/POST

**GET请求**：
- 功能：显示版块编辑表单
- 返回：编辑页面

**POST请求**：
- 功能：更新版块配置
- 参数：名称、简介、公告、版主、权限设置等

#### 权限配置接口

**接口定义**：
- URL: `/admin/forum/update/{fid}`
- 方法: POST

**权限参数**：
- `allowread`: 浏览权限数组
- `allowthread`: 发帖权限数组
- `allowpost`: 回帖权限数组
- `allowattach`: 附件权限数组
- `allowdown`: 下载权限数组

**章节来源**
- [admin/route/forum.php](file://admin/route/forum.php#L12-L180)

## 依赖关系分析

系统各组件之间的依赖关系清晰，遵循单一职责原则：

```mermaid
graph TB
subgraph "路由层依赖"
RF["route/forum.php"] --> FF["model/forum.func.php"]
RF --> FAF["model/forum_access.func.php"]
RF --> TF["model/thread.func.php"]
RF --> TTF["model/thread_top.func.php"]
RF --> MF["model/misc.func.php"]
end
subgraph "视图层依赖"
FH["view/htm/forum.htm"] --> RF
FH --> FF
FH --> TF
FH --> FAF
HIH["view/htm/header.inc.htm"] --> MF
end
subgraph "模型层内部依赖"
FF --> FAF
FF --> MF
TF --> MF
TTF --> MF
end
subgraph "管理员接口依赖"
AF["admin/route/forum.php"] --> FF
AF --> FAF
AF --> MF
end
```

**图表来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [admin/route/forum.php](file://admin/route/forum.php#L1-L261)

**依赖特点**：
- 路由层只依赖模型层，不直接操作数据库
- 视图层依赖路由层和模型层的数据
- 模型层内部有清晰的职责分工
- 管理员接口与前台接口共享底层模型

**章节来源**
- [model/forum.func.php](file://model/forum.func.php#L1-L210)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)

## 性能考虑

### 缓存策略

系统实现了多层次的缓存机制以提升性能：

**版块列表缓存**：
- 缓存键：`forumlist`
- 缓存时间：60秒
- 触发条件：版块创建、更新、删除时清除缓存

**置顶主题缓存**：
- 缓存键：`thread_top_list`
- 自动更新：当主题置顶状态改变时更新缓存

**请求级缓存**：
- 线程读取缓存：在同一请求生命周期内缓存线程数据
- 静态变量缓存：避免重复数据库查询

### 安全优化

**分页安全**：
- 对第100页以后的请求进行特殊处理
- 限制最大页码范围，防止恶意请求

**权限验证**：
- 在数据库层面进行权限过滤
- 使用静态变量缓存权限结果，减少重复计算

**输入验证**：
- 所有外部输入都经过参数验证
- 防止SQL注入和XSS攻击

## 故障排除指南

### 常见问题及解决方案

**问题1：版块权限不足**
- 现象：访问版块时提示权限不足
- 原因：用户组权限或版块独立权限配置不当
- 解决：检查用户组权限设置或版块权限配置

**问题2：版块列表为空**
- 现象：版块页面显示空列表
- 原因：版块中没有主题或权限过滤导致
- 解决：确认版块中存在主题且用户有相应权限

**问题3：分页异常**
- 现象：翻页时出现重复或缺失数据
- 原因：分页参数错误或缓存问题
- 解决：检查分页参数，清理相关缓存

**问题4：SEO信息不正确**
- 现象：页面标题或描述不符合预期
- 原因：版块SEO设置或默认配置问题
- 解决：检查版块SEO设置或系统配置

### 调试建议

1. **启用调试模式**：在开发环境中启用DEBUG常量
2. **检查日志**：查看系统日志中的错误信息
3. **验证权限**：使用管理员账户测试权限设置
4. **清理缓存**：定期清理缓存以确保数据一致性

**章节来源**
- [route/forum.php](file://route/forum.php#L16-L17)
- [model/forum_access.func.php](file://model/forum_access.func.php#L126-L139)

## 结论

XiunoBBS的版块管理API设计合理，实现了完整的论坛功能。系统具有以下特点：

**优点**：
- 清晰的分层架构，职责明确
- 完善的权限控制机制
- 良好的性能优化策略
- 丰富的SEO支持
- 易于扩展和维护

**适用场景**：
- 中小型论坛网站
- 需要灵活权限控制的社区平台
- 对SEO友好的内容管理系统

**改进建议**：
- 可以考虑添加API版本控制
- 增加更多的缓存策略
- 提供更详细的错误信息
- 支持RESTful API格式

该API为开发者提供了完整而灵活的版块管理解决方案，能够满足大多数论坛应用的需求。