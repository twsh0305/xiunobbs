# 帖子管理API

<cite>
**本文档引用的文件**
- [route/thread.php](file://route/thread.php)
- [model/thread.func.php](file://model/thread.func.php)
- [route/post.php](file://route/post.php)
- [model/post.func.php](file://model/post.func.php)
- [route/attach.php](file://route/attach.php)
- [model/attach.func.php](file://model/attach.func.php)
- [model/forum_access.func.php](file://model/forum_access.func.php)
- [conf/conf.default.php](file://conf/conf.default.php)
- [view/htm/thread.htm](file://view/htm/thread.htm)
- [view/htm/post.htm](file://view/htm/post.htm)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php)
</cite>

## 目录
1. [引言](#引言)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)
10. [附录](#附录)

## 引言
本文件面向开发者与运维人员，系统性梳理 XiunoBBS 4.0 的“帖子管理API”。围绕主题（Thread）与回帖（Post）两大核心实体，详细说明：
- 帖子列表获取、帖子详情查询、帖子创建、帖子编辑、帖子删除的实现方式与调用流程
- 分页机制与页面布局
- 权限控制与内容审核相关流程
- Markdown/HTML/UBB 等内容格式化与渲染
- 附件上传、关联与下载
- 实时更新机制（浏览量、楼层号等）
- 提供具体 API 调用示例与响应格式说明

## 项目结构
围绕帖子管理的关键文件组织如下：
- 路由层：route/thread.php、route/post.php、route/attach.php
- 模型层：model/thread.func.php、model/post.func.php、model/attach.func.php、model/forum_access.func.php
- 配置：conf/conf.default.php
- 视图：view/htm/thread.htm、view/htm/post.htm
- 工具与通用：xiunophp/misc.func.php

```mermaid
graph TB
subgraph "路由层"
RT["route/thread.php"]
RP["route/post.php"]
RA["route/attach.php"]
end
subgraph "模型层"
MT["model/thread.func.php"]
MP["model/post.func.php"]
MA["model/attach.func.php"]
MF["model/forum_access.func.php"]
end
subgraph "视图层"
VTH["view/htm/thread.htm"]
VPH["view/htm/post.htm"]
end
CFG["conf/conf.default.php"]
RT --> MT
RP --> MP
RA --> MA
MT --> MP
MP --> MA
MT --> MF
MP --> MF
RA --> MF
RT --> VTH
RP --> VPH
CFG --> RT
CFG --> RP
CFG --> RA
```

图表来源
- [route/thread.php](file://route/thread.php#L1-L146)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [route/post.php](file://route/post.php#L1-L226)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L310)
- [view/htm/post.htm](file://view/htm/post.htm#L1-L191)

章节来源
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [route/attach.php](file://route/attach.php#L1-L183)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L310)
- [view/htm/post.htm](file://view/htm/post.htm#L1-L191)

## 核心组件
- 帖子（Thread）：主题列表、主题详情、创建、编辑、删除
- 回帖（Post）：回帖创建、编辑、删除；支持引用回帖
- 附件（Attach）：上传、关联、删除、下载
- 权限（Forum Access）：用户组与板块访问控制
- 配置（Conf）：分页大小、浏览量更新策略、URL重写等

章节来源
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [model/attach.func.php](file://model/attach.func.php#L1-L277)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [conf/conf.default.php](file://conf/conf.default.php#L88-L123)

## 架构总览
帖子管理API遵循“路由 → 模型 → 视图/输出”的分层设计：
- 路由负责参数解析、鉴权与入口分发
- 模型负责数据持久化、格式化与业务规则
- 视图负责页面渲染或返回JSON消息体
- 配置统一管理运行参数

```mermaid
sequenceDiagram
participant C as "客户端"
participant R as "路由(route)"
participant M as "模型(model)"
participant V as "视图(view)"
C->>R : 发起请求(如创建主题/回帖/删除)
R->>R : 参数校验/登录检查/权限判断
alt GET 请求
R->>V : 渲染表单/详情页
V-->>C : HTML 页面
else POST 请求
R->>M : 调用业务方法(创建/更新/删除)
M-->>R : 返回结果/错误码
R-->>C : JSON 响应(code,message)
end
```

图表来源
- [route/thread.php](file://route/thread.php#L10-L77)
- [route/post.php](file://route/post.php#L11-L99)
- [route/attach.php](file://route/attach.php#L9-L77)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L3-L8)

## 详细组件分析

### 帖子列表获取
- 路由入口：通过路由参数选择版块或关键词筛选，调用模型查询主题列表
- 分页策略：按版块 fid 查询，支持 lastpid/tid 排序，首页特殊处理置顶主题
- 权限过滤：对非公开板块或禁止阅读的用户进行过滤
- 响应：返回主题列表与分页导航

关键实现要点
- 版块主题查询：使用模型方法按 fid 分页查询
- 置顶主题：第一页合并全局/板块置顶主题
- 权限控制：基于用户组与板块访问规则

章节来源
- [model/thread.func.php](file://model/thread.func.php#L220-L275)
- [model/thread.func.php](file://model/thread.func.php#L387-L402)
- [conf/conf.default.php](file://conf/conf.default.php#L88-L98)

### 帖子详情查询
- 路由入口：thread-{tid}-{page}-{keyword}.htm
- 数据加载：读取主题、所属版块、分页回帖列表；第一页包含首帖内容并增加浏览量
- 关键字高亮：对标题进行关键词高亮
- 权限控制：需具备版块“允许阅读”权限
- 响应：渲染主题详情页，包含分页导航与快速回复

章节来源
- [route/thread.php](file://route/thread.php#L79-L142)
- [model/thread.func.php](file://model/thread.func.php#L146-L164)
- [model/post.func.php](file://model/post.func.php#L200-L217)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L310)

### 帖子创建（主题）
- 路由入口：thread-create
- 登录与权限：必须登录，且用户组对目标版块具备“允许发主题”
- 参数校验：标题长度限制、内容长度限制、文档类型限制
- 业务流程：先创建首回帖，再创建主题，更新统计数据与缓存
- 响应：成功返回提示消息

章节来源
- [route/thread.php](file://route/thread.php#L9-L77)
- [model/thread.func.php](file://model/thread.func.php#L48-L118)

### 帖子编辑（主题）
- 路由入口：post-update-{pid}
- 权限要求：编辑主题需具备“允许发主题”或版块管理员权限；主题关闭时仅管理员可编辑
- 参数校验：标题长度限制、内容长度限制
- 业务流程：更新主题字段（如标题/版块），更新回帖内容
- 响应：成功返回提示消息

章节来源
- [route/post.php](file://route/post.php#L101-L181)
- [model/thread.func.php](file://model/thread.func.php#L121-L144)
- [model/post.func.php](file://model/post.func.php#L92-L114)

### 帖子删除（主题）
- 路由入口：post-delete-{pid}
- 权限要求：删除主题需具备“允许发主题”或版块管理员权限；主题关闭时仅管理员可删除
- 业务流程：删除主题及其所有回帖，更新统计数据与缓存
- 响应：成功返回提示消息

章节来源
- [route/post.php](file://route/post.php#L183-L222)
- [model/thread.func.php](file://model/thread.func.php#L177-L208)

### 回帖创建
- 路由入口：post-create-{tid}-{quick?}
- 权限要求：必须登录，且具备“允许回帖”，主题未关闭
- 参数校验：内容长度限制、文档类型限制
- 业务流程：创建回帖，更新主题统计（回帖数、最后回帖信息），更新用户统计与运行时统计
- 响应：可直接返回回帖HTML片段或提示消息

章节来源
- [route/post.php](file://route/post.php#L11-L99)
- [model/post.func.php](file://model/post.func.php#L50-L89)

### 回帖编辑
- 路由入口：post-update-{pid}
- 权限要求：编辑者本人或版块管理员；主题关闭时仅管理员可编辑
- 业务流程：更新回帖内容，重新关联附件
- 响应：成功返回提示消息

章节来源
- [route/post.php](file://route/post.php#L101-L181)
- [model/post.func.php](file://model/post.func.php#L92-L114)

### 回帖删除
- 路由入口：post-delete-{pid}
- 权限要求：删除者本人或版块管理员；主题关闭时仅管理员可删除
- 业务流程：删除回帖，更新主题统计；若为最后回帖则更新主题最后回帖信息
- 响应：成功返回提示消息

章节来源
- [route/post.php](file://route/post.php#L183-L222)
- [model/post.func.php](file://model/post.func.php#L135-L166)

### 附件处理
- 上传：attach-create，接收Base64数据，保存至临时目录，写入用户会话
- 关联：在主题或回帖保存时，将临时附件移动至正式目录并建立关联
- 删除：attach-delete，支持删除临时附件与已关联附件
- 下载：attach-download，校验权限后输出文件或跳转

章节来源
- [route/attach.php](file://route/attach.php#L9-L115)
- [model/attach.func.php](file://model/attach.func.php#L175-L272)

### 权限控制
- 用户权限：allowread/allowthread/allowpost/allowattach/allowdown
- 管理员权限：allowtop/allowmove/allowupdate/allowdelete/allowbanuser/allowviewip/allowdeleteuser
- 权限判断：基于用户组与板块访问规则，支持缓存加速

章节来源
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)

### 内容格式与渲染
- 文档类型：0: HTML, 1: TXT, 2: Markdown, 3: UBB
- 存储策略：message 保存原始内容，message_fmt 保存安全过滤后的HTML
- 引用回帖：支持引用指定回帖并在内容前添加引用块
- 简介生成：对富文本内容提取纯文本摘要

章节来源
- [model/post.func.php](file://model/post.func.php#L348-L401)
- [view/htm/thread.htm](file://view/htm/thread.htm#L57-L74)

### 分页机制
- 主题列表：按 lastpid/tid 倒序，支持置顶合并
- 回帖列表：按 pid 正序，每页固定数量
- URL参数：thread-{tid}-{page}-{keyword}.htm
- 导航：使用分页工具生成分页链接

章节来源
- [route/thread.php](file://route/thread.php#L82-L127)
- [model/thread.func.php](file://model/thread.func.php#L220-L253)
- [model/post.func.php](file://model/post.func.php#L200-L217)
- [conf/conf.default.php](file://conf/conf.default.php#L88-L98)

### 实时更新机制
- 浏览量：第一页加载时自增浏览量，支持配置开关
- 楼层数：快速回复时动态计算新楼层号
- 统计：主题/回帖/今日统计等运行时统计项

章节来源
- [route/thread.php](file://route/thread.php#L102-L113)
- [model/thread.func.php](file://model/thread.func.php#L146-L156)
- [view/htm/thread.htm](file://view/htm/thread.htm#L212-L231)

## 依赖关系分析

```mermaid
classDiagram
class ThreadRoute {
+创建主题()
+查看主题详情()
}
class PostRoute {
+创建回帖()
+编辑回帖()
+删除回帖()
}
class AttachRoute {
+上传()
+删除()
+下载()
}
class ThreadModel {
+创建主题()
+更新主题()
+删除主题()
+查询列表()
}
class PostModel {
+创建回帖()
+更新回帖()
+删除回帖()
+查询列表()
}
class AttachModel {
+创建()
+删除()
+查找()
+关联()
}
class AccessModel {
+用户权限()
+管理员权限()
}
ThreadRoute --> ThreadModel : "调用"
PostRoute --> PostModel : "调用"
AttachRoute --> AttachModel : "调用"
ThreadModel --> PostModel : "关联"
PostModel --> AttachModel : "关联"
ThreadModel --> AccessModel : "权限"
PostModel --> AccessModel : "权限"
AttachRoute --> AccessModel : "权限"
```

图表来源
- [route/thread.php](file://route/thread.php#L9-L142)
- [route/post.php](file://route/post.php#L11-L222)
- [route/attach.php](file://route/attach.php#L9-L183)
- [model/thread.func.php](file://model/thread.func.php#L48-L208)
- [model/post.func.php](file://model/post.func.php#L50-L166)
- [model/attach.func.php](file://model/attach.func.php#L44-L109)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)

## 性能考量
- 分页与排序：主题列表按 lastpid/tid 倒序，避免全表扫描；置顶合并仅在首页执行
- 缓存与统计：浏览量更新可配置；运行时统计项集中维护
- 附件处理：临时文件在会话中聚合，批量移动与关联，减少IO次数
- 客户端并发：附件上传采用串行处理，避免会话并发写入问题

章节来源
- [model/thread.func.php](file://model/thread.func.php#L220-L275)
- [model/post.func.php](file://model/post.func.php#L175-L177)
- [model/attach.func.php](file://model/attach.func.php#L175-L272)
- [view/htm/post.htm](file://view/htm/post.htm#L134-L169)

## 故障排查指南
- 常见错误码与提示：统一通过消息封装返回，前端根据 code 判断
- 参数校验失败：检查必填字段、长度限制、文档类型
- 权限不足：确认用户组权限与板块访问规则
- 附件上传失败：检查文件大小限制、后缀白名单、临时目录权限
- 删除失败：确认删除权限与对象状态（主题关闭时仅管理员可删）

章节来源
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L3-L8)
- [route/thread.php](file://route/thread.php#L40-L77)
- [route/post.php](file://route/post.php#L25-L99)
- [route/attach.php](file://route/attach.php#L22-L77)

## 结论
本API以清晰的路由与模型分层实现帖子管理的完整生命周期，结合权限控制、内容格式化与附件处理，满足论坛场景下的高可用需求。通过合理的分页策略与统计机制，兼顾性能与用户体验。

## 附录

### API 调用示例与响应格式

- 创建主题
  - 方法与路径：POST thread-create
  - 请求参数：fid, subject, message, doctype
  - 响应：JSON {code,message}

- 查看主题详情
  - 方法与路径：GET thread-{tid}-{page}-{keyword}.htm
  - 响应：HTML 页面（包含主题内容、回帖列表、分页导航）

- 快速回帖
  - 方法与路径：POST post-create-{tid}-1
  - 请求参数：message, doctype, return_html=1
  - 响应：JSON {code, message(html片段)}

- 编辑主题/回帖
  - 方法与路径：POST post-update-{pid}
  - 请求参数：subject/message/doctype/fid(主题编辑)
  - 响应：JSON {code,message}

- 删除主题/回帖
  - 方法与路径：POST post-delete-{pid}
  - 响应：JSON {code,message}

- 上传附件
  - 方法与路径：POST attach-create
  - 请求参数：name,data,width,height,is_image
  - 响应：JSON {code, message:{url,path,orgfilename,filetype,...}}

- 删除附件
  - 方法与路径：POST attach-delete-{aid/_n}
  - 响应：JSON {code,message}

- 下载附件
  - 方法与路径：GET attach-download-{aid}
  - 响应：文件流或跳转

章节来源
- [route/thread.php](file://route/thread.php#L9-L77)
- [route/post.php](file://route/post.php#L11-L181)
- [route/attach.php](file://route/attach.php#L9-L115)
- [view/htm/thread.htm](file://view/htm/thread.htm#L118-L142)
- [view/htm/post.htm](file://view/htm/post.htm#L53-L97)