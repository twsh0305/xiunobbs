# 论坛API

<cite>
**本文档引用的文件**
- [route/forum.php](file://route/forum.php)
- [route/thread.php](file://route/thread.php)
- [route/post.php](file://route/post.php)
- [route/index.php](file://route/index.php)
- [model/forum.func.php](file://model/forum.func.php)
- [model/thread.func.php](file://model/thread.func.php)
- [model/post.func.php](file://model/post.func.php)
- [model/thread_top.func.php](file://model/thread_top.func.php)
- [model/forum_access.func.php](file://model/forum_access.func.php)
- [model/misc.func.php](file://model/misc.func.php)
- [conf/conf.default.php](file://conf/conf.default.php)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php)
- [view/htm/forum.htm](file://view/htm/forum.htm)
- [view/htm/thread.htm](file://view/htm/thread.htm)
</cite>

## 目录
1. [引言](#引言)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)
10. [附录](#附录)

## 引言
本文件面向论坛核心功能的API设计与实现，覆盖版块管理、主题发布、帖子回复、内容浏览等RESTful接口。文档说明HTTP方法映射、URL路由规则、请求参数校验、响应数据格式、权限验证、内容审核、置顶推荐、分页机制、排序规则与搜索功能的实现方式。为便于不同技术背景的读者理解，文档采用逐层递进的方式组织内容，并辅以可视化图表。

## 项目结构
- 路由层（route）：定义URL到控制器的映射，负责参数解析、权限检查、调用模型层并渲染视图或输出消息。
- 模型层（model）：封装数据访问与业务逻辑，包括版块、主题、帖子、权限、置顶、工具等模块。
- 配置（conf）：全局配置项，如分页大小、默认排序、URL重写模式等。
- 视图（view）：页面模板，用于渲染版块列表、主题详情、帖子列表等。
- 基础库（xiunophp）：通用工具函数，如分页、URL生成、运行级别控制等。

```mermaid
graph TB
subgraph "路由层"
RForum["route/forum.php"]
RThread["route/thread.php"]
RPost["route/post.php"]
RIndex["route/index.php"]
end
subgraph "模型层"
MForum["model/forum.func.php"]
MThread["model/thread.func.php"]
MPost["model/post.func.php"]
MTop["model/thread_top.func.php"]
MAccess["model/forum_access.func.php"]
MUrl["model/misc.func.php"]
end
subgraph "配置"
CConf["conf/conf.default.php"]
end
subgraph "视图"
VForum["view/htm/forum.htm"]
VThread["view/htm/thread.htm"]
end
subgraph "基础库"
XMisc["xiunophp/misc.func.php"]
end
RForum --> MForum
RForum --> MThread
RForum --> MTop
RThread --> MThread
RThread --> MPost
RPost --> MPost
RIndex --> MThread
RIndex --> MTop
MThread --> MPost
MThread --> MForum
MPost --> MForum
MAccess --> MForum
MUrl --> CConf
RForum --> VForum
RThread --> VThread
RIndex --> VForum
XMisc --> CConf
```

**图表来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [route/index.php](file://route/index.php#L1-L49)
- [model/forum.func.php](file://model/forum.func.php#L1-L210)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [model/thread_top.func.php](file://model/thread_top.func.php#L1-L82)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [view/htm/forum.htm](file://view/htm/forum.htm#L1-L130)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L200)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L371-L467)

**章节来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [route/index.php](file://route/index.php#L1-L49)
- [model/forum.func.php](file://model/forum.func.php#L1-L210)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [model/thread_top.func.php](file://model/thread_top.func.php#L1-L82)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [view/htm/forum.htm](file://view/htm/forum.htm#L1-L130)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L200)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L371-L467)

## 核心组件
- 版块（Forum）
  - 读取版块信息、权限过滤、版块列表缓存、版块增删改查。
- 主题（Thread）
  - 主题创建、读取、分页查询、置顶管理、统计更新、格式化。
- 帖子（Post）
  - 帖子创建、更新、删除、按主题分页、格式化、引用处理。
- 权限（Forum Access）
  - 用户权限与版块权限判断、板块管理员判定。
- 置顶（Thread Top）
  - 置顶变更、置顶列表查询与缓存。
- 工具（Misc）
  - URL生成、分页、运行级别控制、消息输出。

**章节来源**
- [model/forum.func.php](file://model/forum.func.php#L1-L210)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/thread_top.func.php](file://model/thread_top.func.php#L1-L82)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)

## 架构总览
论坛API遵循“路由-模型-视图”的分层架构。路由层负责接收HTTP请求、解析参数、执行权限校验；模型层封装数据持久化与业务规则；视图层负责渲染HTML或通过消息函数输出统一JSON响应。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Route as "路由层"
participant Model as "模型层"
participant View as "视图层"
Client->>Route : "HTTP 请求"
Route->>Route : "参数解析/权限校验"
Route->>Model : "调用业务方法"
Model-->>Route : "返回数据/状态"
alt "渲染页面"
Route->>View : "渲染模板"
View-->>Client : "HTML 响应"
else "返回消息"
Route-->>Client : "统一消息(JSON)"
end
```

**图表来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [model/misc.func.php](file://model/misc.func.php#L91-L124)

**章节来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [model/misc.func.php](file://model/misc.func.php#L91-L124)

## 详细组件分析

### 版块管理 API
- 功能概述
  - 版块列表获取：基于权限过滤后的版块列表，支持缓存。
  - 版块详情与主题列表：读取版块信息，按页返回主题列表，支持排序。
  - 权限控制：根据用户组与版块访问策略判断允许读取/发帖/回帖等。
- 关键路由与模型
  - 路由：版块主题列表与排序参数处理。
  - 模型：版块读取、权限判断、主题分页查询、置顶合并。
- URL与参数
  - 版块主题列表：/forum-{fid}-{page}?orderby={tid|lastpid}
  - 参数：fid（版块ID）、page（页码）、orderby（排序字段）。
- 响应与分页
  - 返回主题列表与分页导航；首页合并置顶主题。
- 权限与访问控制
  - 允许读取：allowread；允许发帖：allowthread；允许回帖：allowpost。
- 示例流程（版块主题列表）

```mermaid
sequenceDiagram
participant Client as "客户端"
participant ForumRoute as "route/forum.php"
participant ThreadModel as "model/thread.func.php"
participant ForumModel as "model/forum.func.php"
participant TopModel as "model/thread_top.func.php"
Client->>ForumRoute : "GET /forum-{fid}-{page}?orderby={tid|lastpid}"
ForumRoute->>ForumModel : "forum_read(fid)"
ForumModel-->>ForumRoute : "版块信息"
ForumRoute->>ThreadModel : "thread_find_by_fid(fid, page, pagesize, orderby)"
ThreadModel-->>ForumRoute : "主题列表"
ForumRoute->>TopModel : "thread_top_find(0) 合并置顶"
TopModel-->>ForumRoute : "置顶主题"
ForumRoute-->>Client : "主题列表 + 分页"
```

**图表来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [model/thread.func.php](file://model/thread.func.php#L257-L275)
- [model/forum.func.php](file://model/forum.func.php#L60-L71)
- [model/thread_top.func.php](file://model/thread_top.func.php#L32-L43)

**章节来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [model/forum.func.php](file://model/forum.func.php#L60-L71)
- [model/thread.func.php](file://model/thread.func.php#L257-L275)
- [model/thread_top.func.php](file://model/thread_top.func.php#L32-L43)

### 主题发布 API
- 功能概述
  - 新建主题：校验用户登录、版块权限、标题与内容长度限制，创建主题与首帖。
- 关键路由与模型
  - 路由：/thread-create-{fid}（GET/POST）。
  - 模型：主题创建、首帖创建、统计更新。
- 请求参数
  - GET：fid（目标版块ID）。
  - POST：subject（标题）、message（内容）、doctype（内容类型）。
- 响应
  - 成功返回统一消息；失败返回带字段标识的错误。
- 示例流程（新建主题）

```mermaid
sequenceDiagram
participant Client as "客户端"
participant ThreadRoute as "route/thread.php"
participant ForumModel as "model/forum.func.php"
participant ThreadModel as "model/thread.func.php"
participant PostModel as "model/post.func.php"
Client->>ThreadRoute : "POST /thread-create-{fid}"
ThreadRoute->>ThreadRoute : "user_login_check()"
ThreadRoute->>ForumModel : "forum_read(fid)"
ForumModel-->>ThreadRoute : "版块信息"
ThreadRoute->>ThreadRoute : "权限校验 allowthread"
ThreadRoute->>ThreadRoute : "参数校验 subject/message"
ThreadRoute->>ThreadModel : "thread_create(thread)"
ThreadModel->>PostModel : "创建首帖"
PostModel-->>ThreadModel : "首帖ID"
ThreadModel-->>ThreadRoute : "主题ID"
ThreadRoute-->>Client : "统一消息(成功/失败)"
```

**图表来源**
- [route/thread.php](file://route/thread.php#L10-L77)
- [model/thread.func.php](file://model/thread.func.php#L48-L118)
- [model/post.func.php](file://model/post.func.php#L7-L18)

**章节来源**
- [route/thread.php](file://route/thread.php#L10-L77)
- [model/thread.func.php](file://model/thread.func.php#L48-L118)
- [model/post.func.php](file://model/post.func.php#L7-L18)

### 帖子回复 API
- 功能概述
  - 新建回帖：校验登录、版块/主题权限、内容长度，支持快速回复与返回HTML。
  - 更新回帖：校验权限（作者或版主），支持移动主题与标题更新。
  - 删除回帖：校验权限与主题状态。
- 关键路由与模型
  - 路由：/post-create-{tid}-{quick?}-{quotepid?}（GET/POST）、/post-update-{pid}（GET/POST）、/post-delete-{pid}（POST）。
  - 模型：回帖创建/更新/删除、引用处理、统计更新。
- 请求参数
  - 新建：message（内容）、doctype、return_html、quotepid。
  - 更新：subject（仅首帖）、message、doctype、fid（仅首帖）。
  - 删除：POST。
- 响应
  - 快速回复可直接返回HTML片段；统一消息返回操作结果。
- 示例流程（新建回帖）

```mermaid
sequenceDiagram
participant Client as "客户端"
participant PostRoute as "route/post.php"
participant ThreadModel as "model/thread.func.php"
participant PostModel as "model/post.func.php"
Client->>PostRoute : "POST /post-create-{tid}"
PostRoute->>PostRoute : "user_login_check()"
PostRoute->>ThreadModel : "thread_read(tid)"
ThreadModel-->>PostRoute : "主题信息"
PostRoute->>PostRoute : "权限校验 allowpost"
PostRoute->>PostRoute : "参数校验 message"
PostRoute->>PostModel : "post_create(post)"
PostModel-->>PostRoute : "回帖ID"
PostRoute-->>Client : "统一消息(可选返回HTML)"
```

**图表来源**
- [route/post.php](file://route/post.php#L11-L99)
- [model/post.func.php](file://model/post.func.php#L50-L89)

**章节来源**
- [route/post.php](file://route/post.php#L11-L99)
- [model/post.func.php](file://model/post.func.php#L50-L89)

### 内容浏览 API
- 功能概述
  - 主题详情：读取主题与首帖，分页加载回帖列表，高亮关键词，统计浏览量。
  - 版块列表：首页聚合多版块主题，支持默认排序与置顶合并。
- 关键路由与模型
  - 路由：/thread-{tid}-{page}-{keyword?}（详情）、/（首页聚合）。
  - 模型：主题读取、回帖分页、置顶合并、统计更新。
- 请求参数
  - 主题详情：tid、page、keyword（关键词高亮）。
  - 首页：page、order（默认来自配置）。
- 响应
  - 主题详情返回首帖与回帖列表；首页返回聚合主题列表。
- 示例流程（主题详情）

```mermaid
sequenceDiagram
participant Client as "客户端"
participant ThreadRoute as "route/thread.php"
participant ThreadModel as "model/thread.func.php"
participant PostModel as "model/post.func.php"
Client->>ThreadRoute : "GET /thread-{tid}-{page}-{keyword?}"
ThreadRoute->>ThreadModel : "thread_read(tid)"
ThreadModel-->>ThreadRoute : "主题信息"
ThreadRoute->>PostModel : "post_find_by_tid(tid, page)"
PostModel-->>ThreadRoute : "回帖列表"
ThreadRoute->>ThreadRoute : "高亮关键词/统计浏览"
ThreadRoute-->>Client : "主题详情 + 分页"
```

**图表来源**
- [route/thread.php](file://route/thread.php#L79-L142)
- [model/thread.func.php](file://model/thread.func.php#L158-L164)
- [model/post.func.php](file://model/post.func.php#L200-L217)

**章节来源**
- [route/thread.php](file://route/thread.php#L79-L142)
- [model/thread.func.php](file://model/thread.func.php#L158-L164)
- [model/post.func.php](file://model/post.func.php#L200-L217)

### 权限验证与内容审核
- 权限验证
  - 用户权限：allowread/allowthread/allowpost等。
  - 版主权限：allowtop/allowmove/allowupdate/allowdelete等。
  - 权限判断：基于用户组与版块访问策略，支持缓存加速。
- 内容审核
  - 内容类型doctype：0-HTML、1-TXT、2-Markdown、3-UBB。
  - HTML安全过滤：对用户输入进行白名单过滤，防止XSS。
- 示例流程（权限判断）

```mermaid
flowchart TD
Start(["进入权限判断"]) --> CheckAccess["读取用户组与版块访问策略"]
CheckAccess --> AllowRead{"allowread?"}
AllowRead --> |否| Deny["拒绝访问"]
AllowRead --> |是| AllowThread{"allowthread?"}
AllowThread --> |否| Deny
AllowThread --> |是| AllowPost{"allowpost?"}
AllowPost --> |否| Deny
AllowPost --> |是| Pass["通过"]
```

**图表来源**
- [model/forum_access.func.php](file://model/forum_access.func.php#L126-L139)
- [model/misc.func.php](file://model/misc.func.php#L156-L280)

**章节来源**
- [model/forum_access.func.php](file://model/forum_access.func.php#L126-L139)
- [model/misc.func.php](file://model/misc.func.php#L156-L280)

### 置顶推荐 API
- 功能概述
  - 置顶变更：将主题置顶至全局或版块级别。
  - 置顶列表：首页与版块首页合并置顶主题。
- 关键模型
  - 置顶变更：thread_top_change；置顶列表：thread_top_find；缓存管理：thread_top_cache_delete。
- 示例流程（置顶合并）

```mermaid
sequenceDiagram
participant IndexRoute as "route/index.php"
participant TopModel as "model/thread_top.func.php"
participant ThreadModel as "model/thread.func.php"
IndexRoute->>TopModel : "thread_top_find(0)"
TopModel-->>IndexRoute : "全局置顶主题"
IndexRoute->>ThreadModel : "thread_find_by_fids(fids, page, pagesize, order)"
ThreadModel-->>IndexRoute : "普通主题列表"
IndexRoute->>IndexRoute : "合并置顶 + 权限过滤"
```

**图表来源**
- [route/index.php](file://route/index.php#L30-L37)
- [model/thread_top.func.php](file://model/thread_top.func.php#L32-L43)
- [model/thread.func.php](file://model/thread.func.php#L277-L287)

**章节来源**
- [route/index.php](file://route/index.php#L30-L37)
- [model/thread_top.func.php](file://model/thread_top.func.php#L32-L43)
- [model/thread.func.php](file://model/thread.func.php#L277-L287)

### 分页机制、排序规则与搜索
- 分页
  - 配置：pagesize、postlist_pagesize。
  - 生成：bootstrap风格分页函数，支持上一页/下一页与省略号。
- 排序
  - 默认排序：lastpid（最后回复时间）。
  - 可选排序：tid（创建时间）。
- 搜索
  - 标题搜索：按subject模糊匹配，返回排序后的主题列表并高亮关键词。
- 示例流程（分页与排序）

```mermaid
flowchart TD
Params["解析 page/order"] --> ValidateOrder{"order 是否合法?"}
ValidateOrder --> |否| SetDefault["设置默认排序 lastpid"]
ValidateOrder --> |是| UseOrder["使用指定排序"]
SetDefault --> Query["查询主题列表"]
UseOrder --> Query
Query --> MergeTop{"首页且 page==1?"}
MergeTop --> |是| AddTop["合并置顶主题"]
MergeTop --> |否| Filter["权限过滤"]
AddTop --> Filter
Filter --> BuildPages["生成分页HTML"]
BuildPages --> Return["返回响应"]
```

**图表来源**
- [route/forum.php](file://route/forum.php#L11-L13)
- [route/index.php](file://route/index.php#L12-L14)
- [model/thread.func.php](file://model/thread.func.php#L218-L253)
- [model/thread_top.func.php](file://model/thread_top.func.php#L32-L43)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L371-L396)

**章节来源**
- [route/forum.php](file://route/forum.php#L11-L13)
- [route/index.php](file://route/index.php#L12-L14)
- [model/thread.func.php](file://model/thread.func.php#L218-L253)
- [model/thread_top.func.php](file://model/thread_top.func.php#L32-L43)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L371-L396)

## 依赖关系分析
- 路由到模型
  - 版块路由依赖版块与主题模型；主题路由依赖主题与帖子模型；帖子路由依赖帖子与主题模型。
- 模型间耦合
  - 主题模型依赖帖子模型（统计、引用）；帖子模型依赖版块模型（统计）。
- 配置与工具
  - 配置决定分页大小、默认排序、URL重写模式；工具函数提供URL生成与分页。
  
```mermaid
graph LR
RForum["route/forum.php"] --> MForum["model/forum.func.php"]
RForum --> MThread["model/thread.func.php"]
RThread["route/thread.php"] --> MThread
RThread --> MPost["model/post.func.php"]
RPost["route/post.php"] --> MPost
MThread --> MPost
MPost --> MForum
MAccess["model/forum_access.func.php"] --> MForum
MTop["model/thread_top.func.php"] --> MThread
MUrl["model/misc.func.php"] --> CConf["conf/conf.default.php"]
XMisc["xiunophp/misc.func.php"] --> CConf
```

**图表来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [model/forum.func.php](file://model/forum.func.php#L1-L210)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/thread_top.func.php](file://model/thread_top.func.php#L1-L82)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L371-L467)

**章节来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [model/forum.func.php](file://model/forum.func.php#L1-L210)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [model/post.func.php](file://model/post.func.php#L1-L425)
- [model/forum_access.func.php](file://model/forum_access.func.php#L1-L196)
- [model/thread_top.func.php](file://model/thread_top.func.php#L1-L82)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L371-L467)

## 性能考量
- 缓存策略
  - 版块列表缓存：减少重复查询；置顶列表缓存：降低热点主题查询开销。
  - 主题/帖子读取缓存：请求生命周期内的静态缓存，避免频繁数据库访问。
- 分页优化
  - 首页与版块列表默认按最后回复时间倒序，支持置顶合并；大页码场景限制与反向翻页优化。
- 统计更新
  - 浏览量更新可配置；回帖/主题统计在创建/删除时原子更新，避免后续统计成本。
- URL与模板
  - URL重写模式可选；模板中使用分页与面包屑，提升用户体验。

[本节为通用指导，无需特定文件分析]

## 故障排查指南
- 统一响应格式
  - 成功：code=0；业务错误：code>0（可定位到具体字段）；系统错误：code<0。
- 常见问题
  - 权限不足：检查用户组与版块访问策略；确认allowread/allowthread/allowpost。
  - 主题/帖子不存在：确认tid/pid是否正确；注意主题关闭状态。
  - 参数校验失败：subject/message长度限制；doctype取值范围。
- 调试建议
  - 使用浏览器开发者工具查看网络请求与响应；关注message中的错误描述与字段提示。

**章节来源**
- [model/misc.func.php](file://model/misc.func.php#L91-L124)
- [route/thread.php](file://route/thread.php#L48-L56)
- [route/post.php](file://route/post.php#L48-L52)

## 结论
本论坛API围绕“路由-模型-视图”清晰分层，通过统一的消息响应与严格的权限控制，实现了版块管理、主题发布、帖子回复与内容浏览的核心能力。置顶推荐、分页与排序、搜索与高亮等特性进一步完善了用户体验。建议在生产环境中启用缓存与合适的URL重写模式，并结合运行级别策略保障系统稳定。

[本节为总结，无需特定文件分析]

## 附录
- 配置项参考
  - 分页大小：pagesize、postlist_pagesize
  - 默认排序：order_default
  - URL重写：url_rewrite_on
- 模板引用
  - 版块列表模板：view/htm/forum.htm
  - 主题详情模板：view/htm/thread.htm

**章节来源**
- [conf/conf.default.php](file://conf/conf.default.php#L89-L114)
- [view/htm/forum.htm](file://view/htm/forum.htm#L1-L130)
- [view/htm/thread.htm](file://view/htm/thread.htm#L1-L200)