# 主题管理API

<cite>
**本文档引用的文件**
- [route/thread.php](file://route/thread.php)
- [model/thread.func.php](file://model/thread.func.php)
- [model/thread_top.func.php](file://model/thread_top.func.php)
- [route/forum.php](file://route/forum.php)
- [model/forum.func.php](file://model/forum.func.php)
- [route/mod.php](file://route/mod.php)
- [admin/route/thread.php](file://admin/route/thread.php)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php)
- [conf/conf.default.php](file://conf/conf.default.php)
- [model/forum_access.func.php](file://model/forum_access.func.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概览](#架构概览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
本文档详细描述了XiunoBBS主题管理API的设计与实现，涵盖主题列表获取、主题详情查询、主题创建、主题编辑、主题删除等RESTful接口。同时记录了主题置顶、精华标记、锁定状态等功能的API实现，包括分页加载、排序规则、搜索过滤和权限验证机制。文档还提供了主题数据模型、关联查询和性能优化的实现细节，帮助开发者快速理解和使用该API系统。

## 项目结构
主题管理API由三层组成：
- 路由层：处理HTTP请求，解析参数并调用相应的控制器
- 模型层：封装数据库操作和业务逻辑
- 视图层：渲染页面模板（对于API场景，通常返回JSON数据）

```mermaid
graph TB
subgraph "路由层"
RT["route/thread.php<br/>主题路由"]
RF["route/forum.php<br/>论坛路由"]
RM["route/mod.php<br/>版主操作路由"]
RAdmin["admin/route/thread.php<br/>后台主题管理"]
end
subgraph "模型层"
MT["model/thread.func.php<br/>主题模型"]
MTT["model/thread_top.func.php<br/>置顶主题模型"]
MF["model/forum.func.php<br/>论坛模型"]
MFA["model/forum_access.func.php<br/>权限验证"]
end
subgraph "工具层"
PAG["xiunophp/misc.func.php<br/>分页工具"]
CONF["conf/conf.default.php<br/>配置文件"]
end
RT --> MT
RF --> MT
RF --> MF
RM --> MT
RM --> MTT
RAdmin --> MT
MT --> MFA
MT --> PAG
MT --> CONF
MF --> MFA
```

**图表来源**
- [route/thread.php](file://route/thread.php#L1-L146)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)
- [model/thread_top.func.php](file://model/thread_top.func.php#L1-L82)

**章节来源**
- [route/thread.php](file://route/thread.php#L1-L146)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)

## 核心组件
主题管理API的核心组件包括：

### 主题路由组件
- **主题列表获取**：`/forum-{fid}-{page}` - 获取指定版块的主题列表
- **主题详情查询**：`/thread-{tid}-{page}-{keyword}` - 获取主题详情和回帖列表
- **主题创建**：`/thread-create-{fid}` - 创建新主题

### 主题模型组件
- **主题CURD操作**：`thread__create()`, `thread__read()`, `thread__update()`, `thread__delete()`
- **主题列表查询**：`thread_find_by_fid()` 支持分页和排序
- **主题统计**：`thread_count()`, `thread_maxid()`

### 权限验证组件
- **用户权限**：`forum_access_user()` 检查用户在特定版块的权限
- **版主权限**：`forum_access_mod()` 检查版主在特定版块的操作权限

**章节来源**
- [route/thread.php](file://route/thread.php#L10-L146)
- [model/thread.func.php](file://model/thread.func.php#L7-L216)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)

## 架构概览
主题管理API采用经典的MVC架构模式，通过路由层接收HTTP请求，模型层处理业务逻辑，视图层负责数据展示。系统支持多种排序方式和权限控制，确保数据安全和性能优化。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Route as "路由层"
participant Model as "模型层"
participant DB as "数据库"
participant Cache as "缓存层"
Client->>Route : GET /forum-1-1
Route->>Model : thread_find_by_fid(fid, page)
Model->>Cache : forum_list_cache()
Cache-->>Model : forumlist数据
Model->>DB : 查询主题列表
DB-->>Model : 主题数据
Model->>Model : thread_format() 格式化数据
Model-->>Route : 格式化后的主题列表
Route-->>Client : HTML页面或JSON数据
Note over Client,DB : 权限验证和分页处理
```

**图表来源**
- [route/forum.php](file://route/forum.php#L25-L32)
- [model/thread.func.php](file://model/thread.func.php#L220-L275)
- [model/forum.func.php](file://model/forum.func.php#L137-L149)

## 详细组件分析

### 主题列表获取API
主题列表获取API支持多种排序方式和分页功能：

#### 接口定义
- **URL模式**：`/forum-{fid}-{page}?orderby={tid|lastpid}`
- **HTTP方法**：GET
- **参数说明**：
  - `fid`：版块ID（必填）
  - `page`：页码（默认1）
  - `orderby`：排序字段（tid或lastpid，默认lastpid）

#### 实现流程
```mermaid
flowchart TD
Start(["请求进入"]) --> ValidateFid["验证版块ID"]
ValidateFid --> CheckAccess["检查用户权限"]
CheckAccess --> LoadForum["加载版块信息"]
LoadForum --> GetThreads["获取主题列表"]
GetThreads --> CheckTop["检查置顶主题"]
CheckTop --> FormatData["格式化数据"]
FormatData --> Pagination["生成分页"]
Pagination --> Render["渲染页面"]
Render --> End(["响应完成"])
```

**图表来源**
- [route/forum.php](file://route/forum.php#L15-L32)
- [model/thread.func.php](file://model/thread.func.php#L220-L275)

#### 排序规则
系统支持两种排序方式：
- **按最后回复时间排序**：`lastpid`（默认），适用于实时性要求高的场景
- **按发帖时间排序**：`tid`，适用于历史记录查看

#### 分页机制
- **每页数量**：默认20条，可通过配置修改
- **分页算法**：智能分页，支持大页码优化
- **缓存策略**：前10页结果缓存，提升性能

**章节来源**
- [route/forum.php](file://route/forum.php#L6-L32)
- [model/thread.func.php](file://model/thread.func.php#L220-L275)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L371-L396)

### 主题详情查询API
主题详情查询API提供完整的话题内容和回帖列表：

#### 接口定义
- **URL模式**：`/thread-{tid}-{page}-{keyword}`
- **HTTP方法**：GET
- **参数说明**：
  - `tid`：主题ID（必填）
  - `page`：页码（默认1）
  - `keyword`：搜索关键词（可选）

#### 实现细节
```mermaid
sequenceDiagram
participant Client as "客户端"
participant ThreadRoute as "主题路由"
participant ThreadModel as "主题模型"
participant PostModel as "回帖模型"
participant ForumModel as "论坛模型"
Client->>ThreadRoute : GET /thread-123-1-keyword
ThreadRoute->>ThreadModel : thread_read(tid)
ThreadModel->>ThreadModel : thread_format()
ThreadRoute->>PostModel : post_find_by_tid(tid, page)
PostModel-->>ThreadRoute : 回帖列表
ThreadRoute->>ForumModel : forum_read(fid)
ForumModel-->>ThreadRoute : 版块信息
ThreadRoute-->>Client : 完整主题详情
```

**图表来源**
- [route/thread.php](file://route/thread.php#L80-L142)
- [model/thread.func.php](file://model/thread.func.php#L158-L164)

#### 数据格式化
系统对主题数据进行统一格式化，包括：
- 用户信息关联：用户名、头像URL
- 时间格式化：人性化时间显示
- URL生成：主题链接、用户链接
- 权限标识：置顶样式类

**章节来源**
- [route/thread.php](file://route/thread.php#L80-L142)
- [model/thread.func.php](file://model/thread.func.php#L305-L341)

### 主题创建API
主题创建API支持用户发表新主题：

#### 接口定义
- **URL模式**：`/thread-create-{fid}`
- **HTTP方法**：GET/POST
- **参数说明**：
  - `fid`：版块ID（必填）
  - `subject`：主题标题（必填，最大128字符）
  - `message`：主题内容（必填，最大2,028,000字符）
  - `doctype`：内容类型（默认0，支持0-10）

#### 创建流程
```mermaid
flowchart TD
Start(["创建请求"]) --> ValidateUser["验证用户登录"]
ValidateUser --> CheckForum["检查版块存在性"]
CheckForum --> CheckPrivilege["检查发帖权限"]
CheckPrivilege --> ValidateInput["验证输入参数"]
ValidateInput --> CreatePost["创建首帖"]
CreatePost --> CreateThread["创建主题记录"]
CreateThread --> UpdateStats["更新统计信息"]
UpdateStats --> AssocAttach["关联附件"]
AssocAttach --> ClearCache["清理缓存"]
ClearCache --> Success["创建成功"]
```

**图表来源**
- [route/thread.php](file://route/thread.php#L10-L77)
- [model/thread.func.php](file://model/thread.func.php#L48-L118)

#### 权限验证
- **用户组权限**：必须属于允许发帖的用户组
- **版块权限**：版块必须允许用户发帖
- **内容限制**：标题长度限制、内容大小限制

**章节来源**
- [route/thread.php](file://route/thread.php#L10-L77)
- [model/thread.func.php](file://model/thread.func.php#L48-L118)

### 主题编辑API
主题编辑API支持修改主题信息：

#### 接口定义
- **URL模式**：`/thread-update-{tid}`
- **HTTP方法**：POST
- **参数说明**：
  - `tid`：主题ID（必填）
  - `subject`：新主题标题
  - `message`：新内容

#### 编辑逻辑
```mermaid
flowchart TD
Start(["编辑请求"]) --> CheckAccess["检查编辑权限"]
CheckAccess --> ValidateInput["验证输入"]
ValidateInput --> UpdateThread["更新主题记录"]
UpdateThread --> CheckSubjectChange["检查标题变更"]
CheckSubjectChange --> UpdateTop["更新置顶状态"]
UpdateTop --> ClearCache["清理相关缓存"]
ClearCache --> Success["编辑成功"]
```

**图表来源**
- [model/thread.func.php](file://model/thread.func.php#L121-L144)

#### 特殊处理
- **标题变更**：当主题被置顶时，需要清除置顶缓存
- **版块移动**：移动主题时需要更新相关统计数据
- **置顶状态**：移动主题时需要更新置顶记录

**章节来源**
- [model/thread.func.php](file://model/thread.func.php#L121-L144)

### 主题删除API
主题删除API支持删除主题及其所有回帖：

#### 接口定义
- **URL模式**：`/thread-delete-{tid}`
- **HTTP方法**：POST
- **参数说明**：
  - `tid`：主题ID（必填）

#### 删除流程
```mermaid
flowchart TD
Start(["删除请求"]) --> CheckAccess["检查删除权限"]
CheckAccess --> LoadThread["加载主题信息"]
LoadThread --> DeletePosts["删除所有回帖"]
DeletePosts --> DeleteMyThread["删除我的主题记录"]
DeleteMyThread --> ClearCache["清理缓存"]
ClearCache --> UpdateStats["更新统计信息"]
UpdateStats --> Success["删除成功"]
```

**图表来源**
- [model/thread.func.php](file://model/thread.func.php#L177-L208)

#### 数据完整性
删除操作遵循严格的事务性原则：
- 先删除所有相关回帖，确保数据一致性
- 更新用户和版块的统计信息
- 清理相关缓存，避免脏数据

**章节来源**
- [model/thread.func.php](file://model/thread.func.php#L177-L208)

### 主题置顶API
主题置顶API支持版主对主题进行置顶操作：

#### 接口定义
- **URL模式**：`/mod-top-{tid1}_{tid2}_...`
- **HTTP方法**：POST
- **参数说明**：
  - `tidarr`：主题ID数组（必填）
  - `top`：置顶级别（0-3）

#### 置顶机制
```mermaid
flowchart TD
Start(["置顶请求"]) --> ValidateMod["验证版主权限"]
ValidateMod --> CheckTopLevel["检查置顶级别"]
CheckTopLevel --> ChangeTop["更新置顶状态"]
ChangeTop --> UpdateTopTable["更新置顶表"]
UpdateTopTable --> ClearTopCache["清理置顶缓存"]
ClearTopCache --> LogAction["记录操作日志"]
LogAction --> Success["置顶完成"]
```

**图表来源**
- [route/mod.php](file://route/mod.php#L13-L56)
- [model/thread_top.func.php](file://model/thread_top.func.php#L7-L23)

#### 置顶级别
- **0级**：取消置顶
- **1级**：版块置顶
- **3级**：全局置顶（仅管理员可用）

**章节来源**
- [route/mod.php](file://route/mod.php#L13-L56)
- [model/thread_top.func.php](file://model/thread_top.func.php#L7-L23)

### 锁定状态API
锁定状态API支持版主对主题进行锁定/解锁操作：

#### 接口定义
- **URL模式**：`/mod-close-{tid1}_{tid2}_...`
- **HTTP方法**：POST
- **参数说明**：
  - `tidarr`：主题ID数组（必填）
  - `close`：锁定状态（0-1）

#### 锁定机制
```mermaid
flowchart TD
Start(["锁定请求"]) --> ValidateMod["验证版主权限"]
ValidateMod --> CheckCloseStatus["检查锁定状态"]
CheckCloseStatus --> UpdateThread["更新主题状态"]
UpdateThread --> LogAction["记录操作日志"]
LogAction --> Success["锁定完成"]
```

**图表来源**
- [route/mod.php](file://route/mod.php#L58-L97)

#### 状态管理
- **0级**：正常状态
- **1级**：锁定状态，禁止回复和编辑
- **权限控制**：仅版主及以上权限可操作

**章节来源**
- [route/mod.php](file://route/mod.php#L58-L97)

### 精华标记API
精华标记API支持对主题进行精华标记：

#### 数据模型
精华主题使用独立的表结构：
- **表名**：`bbs_thread_digest`
- **字段**：
  - `fid`：版块ID
  - `tid`：主题ID
  - `uid`：用户ID
  - `digest`：精华等级

#### 标记流程
```mermaid
flowchart TD
Start(["精华标记"]) --> ValidateMod["验证版主权限"]
ValidateMod --> CheckDigest["检查现有标记"]
CheckDigest --> UpdateDigest["更新精华状态"]
UpdateDigest --> UpdateUser["更新用户统计"]
UpdateUser --> ClearCache["清理相关缓存"]
ClearCache --> Success["标记完成"]
```

**图表来源**
- [tool/dx_to_xn4.php](file://tool/dx_to_xn4.php#L445-L477)

**章节来源**
- [tool/dx_to_xn4.php](file://tool/dx_to_xn4.php#L445-L477)

## 依赖关系分析

### 核心依赖关系
```mermaid
graph TB
subgraph "路由层依赖"
RT["route/thread.php"] --> MT["model/thread.func.php"]
RF["route/forum.php"] --> MT
RF --> MF["model/forum.func.php"]
RM["route/mod.php"] --> MT
RM --> MTT["model/thread_top.func.php"]
RAdmin["admin/route/thread.php"] --> MT
end
subgraph "模型层依赖"
MT --> MFA["model/forum_access.func.php"]
MT --> PAG["xiunophp/misc.func.php"]
MT --> CONF["conf/conf.default.php"]
MF --> MFA
end
subgraph "数据库依赖"
MT --> DB["MySQL数据库"]
MT --> TBL["bbs_thread表"]
MT --> TOP["bbs_thread_top表"]
MT --> POST["bbs_post表"]
MT --> FORUM["bbs_forum表"]
end
```

**图表来源**
- [route/thread.php](file://route/thread.php#L1-L146)
- [model/thread.func.php](file://model/thread.func.php#L1-L437)

### 权限验证机制
系统采用多层次的权限验证机制：

```mermaid
flowchart TD
Request["请求到达"] --> CheckUser["检查用户登录"]
CheckUser --> GetUserGroup["获取用户组信息"]
GetUserGroup --> CheckForumAccess["检查版块访问权限"]
CheckForumAccess --> CheckSpecificAccess["检查具体操作权限"]
CheckSpecificAccess --> AccessGranted["权限验证通过"]
CheckSpecificAccess --> AccessDenied["权限验证失败"]
subgraph "权限类型"
Read["查看权限"]
Thread["发帖权限"]
Post["回帖权限"]
Top["置顶权限"]
Move["移动权限"]
Delete["删除权限"]
end
```

**图表来源**
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)

**章节来源**
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)

## 性能考量

### 缓存策略
系统采用多层缓存策略提升性能：

#### 主题列表缓存
- **缓存范围**：前10页主题列表
- **缓存时间**：60秒
- **触发条件**：发帖、删帖、置顶等操作

#### 版块信息缓存
- **缓存范围**：完整版块列表
- **缓存时间**：60秒
- **触发条件**：版块信息变更

#### 置顶主题缓存
- **缓存范围**：置顶主题列表
- **缓存时间**：永久（直到手动清理）
- **触发条件**：置顶状态变更

### 数据库优化
```mermaid
flowchart TD
subgraph "索引优化"
TID["PRIMARY KEY(tid)"]
LASTPID["KEY(lastpid)"]
FID_TID["KEY(fid, tid)"]
FID_LASTPID["KEY(fid, lastpid)"]
end
subgraph "查询优化"
PageOpt["分页查询优化"]
CacheOpt["缓存命中优化"]
SortOpt["排序索引优化"]
FilterOpt["过滤条件优化"]
end
subgraph "性能监控"
QueryTime["查询时间监控"]
CacheRatio["缓存命中率"]
DBLoad["数据库负载"]
MemoryUsage["内存使用"]
end
```

**图表来源**
- [model/thread.func.php](file://model/thread.func.php#L35-L46)
- [model/thread.func.php](file://model/thread.func.php#L220-L275)

### 分页优化
系统实现了智能分页算法：
- **大页码优化**：对超过一定页码的请求进行优化处理
- **缓存策略**：前10页结果缓存，提升热门版块访问速度
- **动态调整**：根据总页数动态调整查询策略

**章节来源**
- [model/thread.func.php](file://model/thread.func.php#L220-L275)
- [xiunophp/misc.func.php](file://xiunophp/misc.func.php#L371-L396)

## 故障排除指南

### 常见问题及解决方案

#### 权限相关错误
- **错误现象**：用户无法访问某些版块或执行特定操作
- **可能原因**：
  - 用户组权限不足
  - 版块设置了访问控制
  - 版主权限验证失败
- **解决方法**：
  - 检查用户组权限配置
  - 验证版块访问控制设置
  - 确认版主身份验证

#### 数据一致性问题
- **错误现象**：主题删除后仍有残留数据
- **可能原因**：
  - 删除操作未完全执行
  - 缓存未及时清理
  - 数据库事务未提交
- **解决方法**：
  - 检查删除操作日志
  - 手动清理相关缓存
  - 验证数据库事务状态

#### 性能问题
- **错误现象**：页面加载缓慢或超时
- **可能原因**：
  - 缓存未启用
  - 查询语句未优化
  - 数据库索引缺失
- **解决方法**：
  - 启用并配置缓存
  - 优化查询语句
  - 添加必要索引

**章节来源**
- [model/thread.func.php](file://model/thread.func.php#L177-L208)
- [model/forum_access.func.php](file://model/forum_access.func.php#L125-L162)

## 结论
XiunoBBS主题管理API提供了完整的主题生命周期管理功能，包括列表获取、详情查询、创建、编辑、删除等核心操作。系统采用模块化的架构设计，支持灵活的权限控制和高效的缓存机制。通过合理的数据库设计和查询优化，能够满足大规模社区应用的需求。

API设计遵循RESTful原则，参数清晰明确，易于集成和扩展。权限验证机制完善，确保了系统的安全性和稳定性。性能优化策略得当，能够在高并发场景下保持良好的响应速度。

建议在实际部署中：
1. 根据业务需求调整分页大小和缓存策略
2. 定期监控数据库性能指标
3. 建立完善的日志记录和错误处理机制
4. 根据用户规模选择合适的缓存方案