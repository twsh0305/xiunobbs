# 用户API

<cite>
**本文档引用的文件**
- [route/user.php](file://route/user.php)
- [model/user.func.php](file://model/user.func.php)
- [model/session.func.php](file://model/session.func.php)
- [model/check.func.php](file://model/check.func.php)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php)
- [view/htm/user_login.htm](file://view/htm/user_login.htm)
- [view/htm/user_create.htm](file://view/htm/user_create.htm)
- [view/htm/my_password.htm](file://view/htm/my_password.htm)
- [view/htm/my_avatar.htm](file://view/htm/my_avatar.htm)
- [route/my.php](file://route/my.php)
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)
10. [附录](#附录)

## 简介
本文件面向开发者与集成方，系统性梳理用户相关API与功能，覆盖用户注册、登录、注销、重置密码、个人资料与头像管理等能力。文档同时阐述认证机制（会话与Token）、权限控制、数据校验规则、密码加密策略与安全措施，并提供完整调用示例与错误码说明。

## 项目结构
围绕用户模块的关键文件组织如下：
- 路由入口：route/user.php 提供用户域路由（登录、注册、注销、重置密码、验证码发送、同步登录等）
- 个人中心：route/my.php 提供密码修改、头像上传等个人资料管理
- 模型层：model/user.func.php 提供用户读写、Token、登录校验、头像URL格式化等
- 会话：model/session.func.php 提供基于数据库的会话存储与Cookie策略
- 校验：model/check.func.php 提供邮箱、用户名、密码等格式校验
- 加密：xiunophp/xn_encrypt.func.php 提供对称加密/解密与安全Key派生
- 视图：view/htm 下的用户相关页面模板，展示请求表单与交互流程

```mermaid
graph TB
subgraph "路由层"
U["route/user.php"]
M["route/my.php"]
end
subgraph "模型层"
UF["model/user.func.php"]
SF["model/session.func.php"]
CF["model/check.func.php"]
XF["xiunophp/xn_encrypt.func.php"]
end
subgraph "视图层"
UL["view/htm/user_login.htm"]
UC["view/htm/user_create.htm"]
MP["view/htm/my_password.htm"]
MA["view/htm/my_avatar.htm"]
end
U --> UF
U --> SF
U --> CF
U --> XF
M --> UF
M --> SF
M --> CF
U --> UL
U --> UC
M --> MP
M --> MA
```

图表来源
- [route/user.php](file://route/user.php#L1-L409)
- [route/my.php](file://route/my.php#L1-L126)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/session.func.php](file://model/session.func.php#L1-L246)
- [model/check.func.php](file://model/check.func.php#L1-L73)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L1-L160)
- [view/htm/user_login.htm](file://view/htm/user_login.htm#L1-L100)
- [view/htm/user_create.htm](file://view/htm/user_create.htm#L1-L151)
- [view/htm/my_password.htm](file://view/htm/my_password.htm#L1-L67)
- [view/htm/my_avatar.htm](file://view/htm/my_avatar.htm#L1-L50)

章节来源
- [route/user.php](file://route/user.php#L1-L409)
- [route/my.php](file://route/my.php#L1-L126)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/session.func.php](file://model/session.func.php#L1-L246)
- [model/check.func.php](file://model/check.func.php#L1-L73)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L1-L160)
- [view/htm/user_login.htm](file://view/htm/user_login.htm#L1-L100)
- [view/htm/user_create.htm](file://view/htm/user_create.htm#L1-L151)
- [view/htm/my_password.htm](file://view/htm/my_password.htm#L1-L67)
- [view/htm/my_avatar.htm](file://view/htm/my_avatar.htm#L1-L50)

## 核心组件
- 用户路由（route/user.php）
  - 登录、注册、注销、重置密码、发送验证码、同步登录等动作
  - 参数校验、错误消息返回、会话与Token设置
- 个人中心（route/my.php）
  - 密码修改、头像上传（含裁剪与缩略）
- 用户模型（model/user.func.php）
  - 用户读写、分组与头像URL格式化、Token生成/校验、登录检查
- 会话模型（model/session.func.php）
  - 基于数据库的会话存储、Cookie策略、在线统计
- 校验工具（model/check.func.php）
  - 邮箱、用户名、密码格式校验
- 加密工具（xiunophp/xn_encrypt.func.php）
  - 对称加密/解密、安全Key派生

章节来源
- [route/user.php](file://route/user.php#L53-L202)
- [route/my.php](file://route/my.php#L40-L122)
- [model/user.func.php](file://model/user.func.php#L301-L377)
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [model/check.func.php](file://model/check.func.php#L21-L69)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

## 架构总览
用户域请求在路由层解析动作与参数，随后调用模型层完成业务处理，最终通过统一的消息返回机制输出结果。会话与Token贯穿登录态维持与跨系统同步登录。

```mermaid
sequenceDiagram
participant C as "客户端"
participant R as "路由 : route/user.php"
participant U as "模型 : model/user.func.php"
participant S as "会话 : model/session.func.php"
participant E as "加密 : xiunophp/xn_encrypt.func.php"
C->>R : "POST /user-login"
R->>U : "校验邮箱/用户名与密码"
U-->>R : "校验结果"
R->>S : "设置会话(uid)"
R->>U : "生成/设置Token"
U->>E : "加密Token"
E-->>U : "返回加密Token"
U-->>R : "返回Token"
R-->>C : "code=0, message=登录成功, token"
```

图表来源
- [route/user.php](file://route/user.php#L53-L107)
- [model/user.func.php](file://model/user.func.php#L348-L377)
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

## 详细组件分析

### 用户登录 API
- HTTP 方法与URL
  - GET /user-login
  - POST /user-login
- 请求参数
  - email: 邮箱或用户名
  - password: 密码（前端已MD5）
- 成功响应
  - code: 0
  - message: 登录成功
  - extra: token（登录后生成）
- 错误响应
  - code: 字段名或负值
  - message: 对应错误文案（如邮箱为空、邮箱不存在、用户名不存在、密码错误等）

```mermaid
sequenceDiagram
participant C as "客户端"
participant V as "视图 : user_login.htm"
participant R as "路由 : route/user.php"
participant U as "模型 : model/user.func.php"
C->>V : "GET /user-login"
V-->>C : "渲染登录表单"
C->>R : "POST /user-login {email,password}"
R->>U : "校验邮箱/用户名与密码"
U-->>R : "校验通过"
R-->>C : "code=0, message=登录成功, token"
```

图表来源
- [view/htm/user_login.htm](file://view/htm/user_login.htm#L13-L96)
- [route/user.php](file://route/user.php#L53-L107)
- [model/user.func.php](file://model/user.func.php#L84-L95)

章节来源
- [route/user.php](file://route/user.php#L53-L107)
- [view/htm/user_login.htm](file://view/htm/user_login.htm#L13-L96)
- [model/user.func.php](file://model/user.func.php#L84-L95)
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php#L118-L123)

### 用户注册 API
- HTTP 方法与URL
  - GET /user-create
  - POST /user-create
- 请求参数
  - email: 邮箱
  - username: 用户名
  - password: 密码（前端已MD5）
  - code: 验证码（可选，取决于配置）
- 成功响应
  - code: 0
  - message: 注册成功
  - extra: token
- 错误响应
  - code: 字段名或负值
  - message: 对应错误文案（如邮箱为空、邮箱已被注册、用户名已被注册、验证码不正确等）

```mermaid
sequenceDiagram
participant C as "客户端"
participant V as "视图 : user_create.htm"
participant R as "路由 : route/user.php"
participant U as "模型 : model/user.func.php"
C->>V : "GET /user-create"
V-->>C : "渲染注册表单"
C->>R : "POST /user-create {email,username,password,code}"
R->>U : "校验邮箱/用户名/密码格式与唯一性"
U-->>R : "校验通过"
R-->>C : "code=0, message=注册成功, token"
```

图表来源
- [view/htm/user_create.htm](file://view/htm/user_create.htm#L14-L147)
- [route/user.php](file://route/user.php#L109-L188)
- [model/user.func.php](file://model/user.func.php#L160-L172)

章节来源
- [route/user.php](file://route/user.php#L109-L188)
- [view/htm/user_create.htm](file://view/htm/user_create.htm#L14-L147)
- [model/check.func.php](file://model/check.func.php#L21-L69)
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php#L131-L141)

### 注销 API
- HTTP 方法与URL
  - GET /user-logout
- 行为
  - 清空会话uid，清除Token，返回成功提示并跳转
- 成功响应
  - code: 0
  - message: 退出成功

章节来源
- [route/user.php](file://route/user.php#L190-L202)
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [model/user.func.php](file://model/user.func.php#L357-L362)

### 重置密码（第一步：校验与验证码）
- HTTP 方法与URL
  - GET /user-resetpw
  - POST /user-resetpw
- 请求参数
  - email: 邮箱
  - code: 验证码
- 成功响应
  - code: 0
  - message: 检测通过，进入下一步
- 错误响应
  - code: 字段名或负值
  - message: 对应错误文案（如邮箱为空、邮箱未注册、验证码不正确等）

章节来源
- [route/user.php](file://route/user.php#L204-L246)
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php#L141-L146)

### 重置密码（第三步：完成）
- HTTP 方法与URL
  - GET /user-resetpw_complete
  - POST /user-resetpw_complete
- 请求参数
  - password: 新密码（前端已MD5）
- 成功响应
  - code: 0
  - message: 修改成功
- 错误响应
  - code: 字段名或负值
  - message: 对应错误文案（如密码为空、格式不正确等）

章节来源
- [route/user.php](file://route/user.php#L249-L293)
- [model/check.func.php](file://model/check.func.php#L54-L69)

### 发送验证码 API
- HTTP 方法与URL
  - POST /user-send_code-user_create 或 /user-send_code-user_resetpw
- 请求参数
  - email: 邮箱
- 成功响应
  - code: 0
  - message: 发送成功
- 错误响应
  - code: 负值
  - message: 对应错误文案（如邮箱为空、邮箱不合法、未开启邮箱验证、发送失败等）

章节来源
- [route/user.php](file://route/user.php#L296-L358)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php#L140-L141)

### 同步登录 API
- HTTP 方法与URL
  - GET /user-synlogin
- 请求参数
  - token: 来自上游系统的加密Token
  - return_url: 回跳地址
- 行为
  - 解密token，校验UA一致性；若未登录则跳转登录页；已登录则加密用户信息回跳
- 成功响应
  - 重定向至 return_url?token=加密后的用户信息
- 错误响应
  - code: 负值
  - message: 对应错误文案（如未授权访问、授权获取失败、请求同步登录等）

章节来源
- [route/user.php](file://route/user.php#L364-L400)
- [model/user.func.php](file://model/user.func.php#L415-L429)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

### 个人中心：密码修改
- HTTP 方法与URL
  - GET /my-password
  - POST /my-password
- 请求参数
  - password_old: 旧密码（前端已MD5）
  - password_new: 新密码（前端已MD5）
  - password_new_repeat: 重复新密码（前端已MD5）
- 成功响应
  - code: 0
  - message: 密码修改成功
- 错误响应
  - code: 字段名或负值
  - message: 对应错误文案（如两次输入不一致、旧密码不正确、修改失败等）

章节来源
- [route/my.php](file://route/my.php#L40-L65)
- [view/htm/my_password.htm](file://view/htm/my_password.htm#L4-L67)
- [model/user.func.php](file://model/user.func.php#L57-L58)

### 个人中心：头像上传
- HTTP 方法与URL
  - GET /my-avatar
  - POST /my-avatar（Base64数据）
- 请求参数
  - width/height: 裁剪尺寸（可选）
  - action: clip（裁剪）
  - filetype: jpg（固定）
  - data: Base64编码的图片数据
- 成功响应
  - code: 0
  - message: { url: 头像URL }
- 错误响应
  - code: 负值
  - message: 对应错误文案（如数据为空、文件过大、目录创建失败、写入失败等）

章节来源
- [route/my.php](file://route/my.php#L85-L122)
- [view/htm/my_avatar.htm](file://view/htm/my_avatar.htm#L24-L48)
- [model/user.func.php](file://model/user.func.php#L201-L202)

## 依赖关系分析
- 路由依赖模型层进行用户读写、Token与会话处理
- 视图层负责表单渲染与前端交互（如MD5加密、进度条、上传回调）
- 校验工具提供统一的数据格式校验
- 加密工具提供Token与同步登录所需的对称加解密

```mermaid
graph LR
R["route/user.php"] --> UF["model/user.func.php"]
R --> SF["model/session.func.php"]
R --> CF["model/check.func.php"]
R --> XF["xiunophp/xn_encrypt.func.php"]
M["route/my.php"] --> UF
M --> SF
M --> CF
V1["view/htm/user_login.htm"] --> R
V2["view/htm/user_create.htm"] --> R
V3["view/htm/my_password.htm"] --> M
V4["view/htm/my_avatar.htm"] --> M
```

图表来源
- [route/user.php](file://route/user.php#L1-L409)
- [route/my.php](file://route/my.php#L1-L126)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/session.func.php](file://model/session.func.php#L1-L246)
- [model/check.func.php](file://model/check.func.php#L1-L73)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L1-L160)
- [view/htm/user_login.htm](file://view/htm/user_login.htm#L1-L100)
- [view/htm/user_create.htm](file://view/htm/user_create.htm#L1-L151)
- [view/htm/my_password.htm](file://view/htm/my_password.htm#L1-L67)
- [view/htm/my_avatar.htm](file://view/htm/my_avatar.htm#L1-L50)

## 性能考量
- 会话延迟更新：当会话数据变更频率较低时，仅更新必要字段，减少数据库写入压力
- 缓存与静态用户缓存：用户读取结果在请求生命周期内缓存，避免重复查询
- Token有效期与密码一致性：Token中携带密码摘要快照，定期校验密码是否被修改，确保Token有效性

章节来源
- [model/session.func.php](file://model/session.func.php#L139-L168)
- [model/user.func.php](file://model/user.func.php#L66-L102)
- [model/user.func.php](file://model/user.func.php#L332-L344)

## 故障排查指南
- 登录失败
  - 现象：密码错误或账号不存在
  - 排查：确认邮箱/用户名是否存在，密码是否正确（前端已MD5），检查校验规则
  - 参考
    - [route/user.php](file://route/user.php#L73-L87)
    - [model/check.func.php](file://model/check.func.php#L21-L69)
- 注册失败
  - 现象：邮箱/用户名已被占用、验证码不正确
  - 排查：确认邮箱/用户名唯一性，验证码是否匹配，发送验证码是否成功
  - 参考
    - [route/user.php](file://route/user.php#L138-L155)
    - [route/user.php](file://route/user.php#L296-L358)
- 密码修改失败
  - 现象：两次新密码不一致、旧密码不正确、更新失败
  - 排查：确认旧密码正确性与盐值匹配，新密码长度与格式
  - 参考
    - [route/my.php](file://route/my.php#L52-L62)
    - [model/check.func.php](file://model/check.func.php#L54-L69)
- 头像上传失败
  - 现象：数据为空、文件过大、目录创建失败、写入失败
  - 排查：确认Base64数据有效、文件大小限制、上传目录权限
  - 参考
    - [route/my.php](file://route/my.php#L97-L121)
- Token异常
  - 现象：未授权访问、解密失败、链接过期
  - 排查：确认Token生成与传递、解密Key一致、UA一致性
  - 参考
    - [model/user.func.php](file://model/user.func.php#L316-L344)
    - [model/user.func.php](file://model/user.func.php#L415-L429)
    - [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

章节来源
- [route/user.php](file://route/user.php#L73-L87)
- [route/user.php](file://route/user.php#L138-L155)
- [route/user.php](file://route/user.php#L296-L358)
- [route/my.php](file://route/my.php#L52-L62)
- [route/my.php](file://route/my.php#L97-L121)
- [model/user.func.php](file://model/user.func.php#L316-L344)
- [model/user.func.php](file://model/user.func.php#L415-L429)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

## 结论
本文档系统化梳理了用户域API与实现细节，明确了认证机制（会话与Token）、权限控制、数据校验与安全策略，并提供了端到端的调用示例与排障指引。建议在生产环境中严格遵循参数校验、密码加密与Token安全策略，结合会话延迟更新与缓存策略提升性能与稳定性。

## 附录

### 认证机制与安全
- 会话管理
  - 使用数据库存储会话，Cookie策略开启HttpOnly，降低XSS风险
  - 支持会话延迟更新，减少频繁写入
- Token验证
  - 登录成功后生成Token并写入Cookie，包含IP、时间戳、UID与密码摘要快照
  - 同步登录通过加密Token传递用户信息，校验UA一致性
- 密码加密策略
  - 前端对密码进行MD5处理；服务端存储密码与随机盐值，登录时按“MD5(明文+盐)”校验
- 安全措施
  - Cookie启用HttpOnly，降低脚本窃取风险
  - Token解密使用安全Key派生，支持扩展加速与降级算法

章节来源
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [model/user.func.php](file://model/user.func.php#L348-L377)
- [model/user.func.php](file://model/user.func.php#L316-L344)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L16-L48)

### 数据验证规则
- 邮箱
  - 长度限制与格式校验
- 用户名
  - 长度限制、不允许包含空格、允许字母数字及中/韩文字
- 密码
  - 长度需为32（MD5十六进制），不能为空

章节来源
- [model/check.func.php](file://model/check.func.php#L21-L69)

### 错误码与消息
- 统一返回结构
  - code: 0表示成功；正数或负数表示字段名或错误码
  - message: 对应语言包文案
- 常见错误
  - 邮箱为空、邮箱不存在、用户名不存在、密码错误
  - 邮箱已被注册、用户名已被注册
  - 验证码不正确、验证码发送失败
  - 旧密码不正确、两次输入不一致、密码修改失败
  - 数据为空、文件过大、目录创建失败、写入失败
  - 未授权访问、解密失败、链接过期

章节来源
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php#L118-L182)
- [route/user.php](file://route/user.php#L73-L87)
- [route/user.php](file://route/user.php#L138-L155)
- [route/user.php](file://route/user.php#L296-L358)
- [route/my.php](file://route/my.php#L52-L62)
- [route/my.php](file://route/my.php#L97-L121)