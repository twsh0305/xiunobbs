# 系统API

<cite>
**本文档引用的文件**
- [route/my.php](file://route/my.php)
- [route/browser.php](file://route/browser.php)
- [route/user.php](file://route/user.php)
- [admin/route/index.php](file://admin/route/index.php)
- [model/user.func.php](file://model/user.func.php)
- [model/misc.func.php](file://model/misc.func.php)
- [model/runtime.func.php](file://model/runtime.func.php)
- [model/kv.func.php](file://model/kv.func.php)
- [view/htm/my.htm](file://view/htm/my.htm)
- [view/htm/browser.htm](file://view/htm/browser.htm)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm)
- [conf/conf.default.php](file://conf/conf.default.php)
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php)
- [view/htm/message.htm](file://view/htm/message.htm)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)
10. [附录](#附录)

## 简介
本文件面向系统管理与用户中心相关API，覆盖以下能力：
- 用户个人中心：个人资料展示、密码修改、头像上传、我的主题列表
- 浏览器兼容性检测页面
- 系统状态查询：站点统计、服务器信息、在线人数
- 统计数据查询：主题数、回帖数、用户数、附件数、磁盘剩余空间
- API统一响应模型与错误码约定
- 调试工具与版本检查机制

本系统采用轻量PHP框架，路由层负责请求分发，模型层封装数据访问与业务逻辑，视图层负责渲染。

## 项目结构
围绕“系统API”的关键目录与文件如下：
- 路由层：route/my.php（个人中心）、route/browser.php（浏览器检测）、route/user.php（用户体系）
- 管理后台：admin/route/index.php（系统状态页）、admin/view/htm/index.htm（状态展示）
- 模型层：model/user.func.php（用户读写/令牌/登录校验）、model/misc.func.php（URL生成、message统一响应、HTML安全过滤）、model/runtime.func.php（实时运行数据）、model/kv.func.php（键值持久化）
- 视图层：view/htm/my.htm（个人中心页面）、view/htm/browser.htm（浏览器检测页面）、view/htm/message.htm（统一消息页）
- 配置与国际化：conf/conf.default.php（系统配置）、lang/zh-cn/bbs.php（语言包）

```mermaid
graph TB
subgraph "路由层"
RMy["route/my.php"]
RBrowser["route/browser.php"]
RUser["route/user.php"]
RAdminIndex["admin/route/index.php"]
end
subgraph "模型层"
MUser["model/user.func.php"]
MMisc["model/misc.func.php"]
MRuntime["model/runtime.func.php"]
MKV["model/kv.func.php"]
end
subgraph "视图层"
VMy["view/htm/my.htm"]
VBrowser["view/htm/browser.htm"]
VMsg["view/htm/message.htm"]
VAdmin["admin/view/htm/index.htm"]
end
RMy --> MUser
RMy --> MRuntime
RBrowser --> VBrowser
RUser --> MUser
RUser --> MMisc
RAdminIndex --> MRuntime
RAdminIndex --> MKV
RAdminIndex --> VAdmin
RMy --> VMy
MMisc --> VMsg
```

图表来源
- [route/my.php](file://route/my.php#L1-L126)
- [route/browser.php](file://route/browser.php#L1-L23)
- [route/user.php](file://route/user.php#L1-L409)
- [admin/route/index.php](file://admin/route/index.php#L1-L111)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [model/runtime.func.php](file://model/runtime.func.php#L1-L82)
- [model/kv.func.php](file://model/kv.func.php#L1-L82)
- [view/htm/my.htm](file://view/htm/my.htm#L1-L22)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)
- [view/htm/message.htm](file://view/htm/message.htm#L1-L25)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm#L1-L94)

章节来源
- [route/my.php](file://route/my.php#L1-L126)
- [route/browser.php](file://route/browser.php#L1-L23)
- [route/user.php](file://route/user.php#L1-L409)
- [admin/route/index.php](file://admin/route/index.php#L1-L111)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [model/runtime.func.php](file://model/runtime.func.php#L1-L82)
- [model/kv.func.php](file://model/kv.func.php#L1-L82)
- [view/htm/my.htm](file://view/htm/my.htm#L1-L22)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm#L1-L94)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php#L1-L200)
- [view/htm/message.htm](file://view/htm/message.htm#L1-L25)

## 核心组件
- 路由与控制器
  - 个人中心：route/my.php 提供密码修改、头像上传、我的主题列表等入口
  - 浏览器检测：route/browser.php 提供浏览器兼容性检测页面
  - 用户体系：route/user.php 提供登录、注册、登出、重置密码、验证码发送、同步登录等
  - 管理后台首页：admin/route/index.php 展示站点统计与服务器信息
- 模型与服务
  - 用户模型：model/user.func.php 提供用户读写、安全信息、令牌生成/校验、登录校验、HTTP Referer处理等
  - 杂项工具：model/misc.func.php 提供URL生成、统一响应message、HTML安全过滤、运行级别检查等
  - 运行时统计：model/runtime.func.php 提供实时运行数据的读取、增减、持久化
  - 键值存储：model/kv.func.php 提供KV读写与缓存桥接
- 视图与国际化
  - 个人中心页面：view/htm/my.htm
  - 浏览器检测页面：view/htm/browser.htm
  - 统一消息页：view/htm/message.htm
  - 管理后台首页：admin/view/htm/index.htm
  - 语言包：lang/zh-cn/bbs.php

章节来源
- [route/my.php](file://route/my.php#L1-L126)
- [route/browser.php](file://route/browser.php#L1-L23)
- [route/user.php](file://route/user.php#L1-L409)
- [admin/route/index.php](file://admin/route/index.php#L1-L111)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [model/runtime.func.php](file://model/runtime.func.php#L1-L82)
- [model/kv.func.php](file://model/kv.func.php#L1-L82)
- [view/htm/my.htm](file://view/htm/my.htm#L1-L22)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm#L1-L94)
- [lang/zh-cn/bbs.php](file://lang/zh-cn/bbs.php#L1-L200)
- [view/htm/message.htm](file://view/htm/message.htm#L1-L25)

## 架构总览
系统API遵循“路由-模型-视图”三层结构：
- 路由层接收HTTP请求，解析动作与参数，调用模型层执行业务逻辑
- 模型层封装数据访问、业务规则与安全控制
- 视图层负责渲染结果或返回JSON响应（通过统一message机制）

```mermaid
sequenceDiagram
participant C as "客户端"
participant R as "路由(my.php)"
participant U as "用户模型(user.func.php)"
participant RT as "运行时(runtime.func.php)"
participant V as "视图(my.htm)"
C->>R : 请求个人中心主页
R->>U : 校验登录(user_login_check)
U-->>R : 当前用户信息
R->>RT : 读取实时统计(runtime_get)
RT-->>R : 统计数据
R->>V : 渲染个人中心页面
V-->>C : HTML响应
```

图表来源
- [route/my.php](file://route/my.php#L1-L126)
- [model/user.func.php](file://model/user.func.php#L381-L389)
- [model/runtime.func.php](file://model/runtime.func.php#L29-L49)
- [view/htm/my.htm](file://view/htm/my.htm#L1-L22)

## 详细组件分析

### 个人中心API
- 功能概览
  - 密码修改：校验旧密码、校验新密码一致性、更新用户密码
  - 头像上传：接收Base64数据、校验大小、写入头像目录、更新用户头像字段
  - 我的主题：按用户UID分页查询主题列表
- 接口定义
  - 路由：/route/my.php
  - 方法：GET/POST（根据具体动作）
  - 认证：需登录（user_login_check）
- 数据流与流程
  - 登录校验通过后，根据动作分支处理
  - 密码修改：参数校验→旧密码校验→更新→返回统一响应
  - 头像上传：参数校验→Base64解码→文件大小限制→写入→更新用户头像→返回统一响应
  - 我的主题：计算分页→查询主题列表→渲染页面

```mermaid
flowchart TD
Start(["进入个人中心"]) --> CheckLogin["校验登录"]
CheckLogin --> Action{"动作类型"}
Action --> |password| PGet["GET: 显示密码修改页"]
Action --> |password| PPost["POST: 参数校验"]
PPost --> OldPwd["校验旧密码"]
OldPwd --> NewMatch{"新密码一致?"}
NewMatch --> |否| ErrOld["返回错误: 两次密码不一致"]
NewMatch --> |是| UpdatePwd["更新密码"]
UpdatePwd --> Done(["完成"])
Action --> |avatar| AGet["GET: 显示头像页"]
Action --> |avatar| APost["POST: 参数校验"]
APost --> Decode["Base64解码"]
Decode --> SizeCheck{"文件大小<=40K?"}
SizeCheck --> |否| ErrSize["返回错误: 文件过大"]
SizeCheck --> |是| WriteFile["写入头像文件"]
WriteFile --> UpdateAvatar["更新用户头像字段"]
UpdateAvatar --> Done
Action --> |thread| ListThread["分页查询主题列表"]
ListThread --> Done
```

图表来源
- [route/my.php](file://route/my.php#L40-L122)
- [model/user.func.php](file://model/user.func.php#L381-L389)
- [model/misc.func.php](file://model/misc.func.php#L91-L124)

章节来源
- [route/my.php](file://route/my.php#L1-L126)
- [model/user.func.php](file://model/user.func.php#L381-L389)
- [model/misc.func.php](file://model/misc.func.php#L91-L124)

### 浏览器兼容性检测API
- 功能概览
  - 提供浏览器兼容性检测页面，引导用户下载推荐浏览器
  - 支持下载链接跳转（Chrome/Firefox/IE）
- 接口定义
  - 路由：/route/browser.php
  - 方法：GET/POST
  - 行为：非download动作渲染检测页；download动作根据类型跳转下载链接
- 数据流
  - 渲染检测页：返回静态HTML
  - 下载：根据类型构造外部链接并跳转

```mermaid
sequenceDiagram
participant C as "客户端"
participant R as "路由(browser.php)"
participant V as "视图(browser.htm)"
C->>R : GET /browser
alt action == download
R->>R : 解析类型
R-->>C : 302跳转至对应下载页
else 默认
R->>V : 渲染浏览器检测页
V-->>C : HTML响应
end
```

图表来源
- [route/browser.php](file://route/browser.php#L1-L23)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)

章节来源
- [route/browser.php](file://route/browser.php#L1-L23)
- [view/htm/browser.htm](file://view/htm/browser.htm#L1-L24)

### 系统状态查询API
- 功能概览
  - 管理后台首页展示站点统计与服务器信息
  - 统计项：主题数、回帖数、用户数、附件数、磁盘剩余空间、在线人数
  - 服务器信息：操作系统、Web服务器、PHP版本、数据库类型与版本、上传/内存/执行时间限制等
- 接口定义
  - 路由：/admin/route/index.php
  - 方法：GET
  - 认证：后台登录（admin_token_set）
- 数据流
  - 读取运行时统计（runtime_get）
  - 读取数据库版本（db->version）
  - 读取PHP配置项（ini_get）
  - 渲染管理后台首页

```mermaid
sequenceDiagram
participant A as "管理员"
participant AR as "路由(admin/route/index.php)"
participant RT as "运行时(runtime.func.php)"
participant DB as "数据库"
participant V as "视图(admin/view/htm/index.htm)"
A->>AR : GET /admin/index
AR->>RT : runtime_get("onlines")
RT-->>AR : 在线人数
AR->>DB : version()
DB-->>AR : 数据库版本
AR->>V : 渲染系统状态页
V-->>A : HTML响应
```

图表来源
- [admin/route/index.php](file://admin/route/index.php#L58-L91)
- [model/runtime.func.php](file://model/runtime.func.php#L29-L49)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm#L1-L94)

章节来源
- [admin/route/index.php](file://admin/route/index.php#L1-L111)
- [model/runtime.func.php](file://model/runtime.func.php#L1-L82)
- [admin/view/htm/index.htm](file://admin/view/htm/index.htm#L1-L94)

### 统计数据查询API
- 功能概览
  - 提供主题数、回帖数、用户数、附件数、磁盘剩余空间等统计数据
  - 通过运行时统计与计数函数聚合
- 数据来源
  - 主题数/回帖数：thread_count()/post_count()
  - 用户数：user_count()
  - 附件数：attach_count()
  - 磁盘剩余：disk_free_space(APP_PATH)
- 使用建议
  - 对高频访问的统计数据可结合缓存与运行时统计，降低数据库压力

章节来源
- [admin/route/index.php](file://admin/route/index.php#L79-L84)
- [model/runtime.func.php](file://model/runtime.func.php#L5-L27)

### 用户体系API
- 功能概览
  - 登录：邮箱/用户名+密码，校验密码，更新登录信息，设置令牌
  - 注册：邮箱/用户名/密码校验，生成盐值与哈希，创建用户
  - 登出：清除会话与令牌
  - 重置密码：验证码校验→修改密码
  - 发送验证码：邮件发送随机码
  - 同步登录：基于令牌在子系统间传递用户信息
- 接口定义
  - 路由：/route/user.php
  - 方法：GET/POST（根据动作）
  - 认证：部分动作需登录（如重置密码第二步）
- 数据流
  - 登录：参数校验→用户查找→密码校验→更新登录信息→设置令牌→统一响应
  - 注册：参数校验→邮箱/用户名唯一性→生成盐值与哈希→创建用户→设置令牌→统一响应
  - 重置密码：验证码校验→设置会话→完成步骤→统一响应
  - 发送验证码：生成随机码→写入会话→发送邮件→统一响应

```mermaid
sequenceDiagram
participant C as "客户端"
participant R as "路由(user.php)"
participant U as "用户模型(user.func.php)"
participant M as "杂项(misc.func.php)"
participant S as "SMTP"
C->>R : POST /user-login
R->>U : 校验邮箱/用户名与密码
U-->>R : 用户信息
R->>U : 更新登录IP/时间/次数
R->>U : 设置令牌(user_token_set)
R-->>C : 统一响应(成功)
C->>R : POST /user-send_code/user_create
R->>M : 生成随机码
R->>S : 发送邮件
S-->>R : 发送结果
R-->>C : 统一响应(成功/失败)
```

图表来源
- [route/user.php](file://route/user.php#L53-L107)
- [route/user.php](file://route/user.php#L109-L188)
- [route/user.php](file://route/user.php#L204-L293)
- [route/user.php](file://route/user.php#L296-L358)
- [model/user.func.php](file://model/user.func.php#L348-L377)
- [model/misc.func.php](file://model/misc.func.php#L91-L124)

章节来源
- [route/user.php](file://route/user.php#L1-L409)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)

## 依赖关系分析
- 路由对模型的依赖
  - 个人中心依赖用户模型进行登录校验与头像更新
  - 用户体系依赖用户模型与杂项工具进行参数校验、令牌与邮件发送
  - 管理后台依赖运行时统计与KV存储进行状态展示
- 模型间的耦合
  - 用户模型与运行时统计紧密配合，用于在线人数等指标
  - KV模型与设置系统配合，提供全局配置读取与缓存
- 视图与路由/模型的交互
  - 路由根据动作选择视图或返回统一响应
  - 统一响应通过message机制输出JSON或HTML

```mermaid
graph LR
RMy["route/my.php"] --> MU["model/user.func.php"]
RMy --> MR["model/runtime.func.php"]
RUser["route/user.php"] --> MU
RUser --> MM["model/misc.func.php"]
RAdmin["admin/route/index.php"] --> MR
RAdmin --> MKV["model/kv.func.php"]
MU --> MM
```

图表来源
- [route/my.php](file://route/my.php#L1-L126)
- [route/user.php](file://route/user.php#L1-L409)
- [admin/route/index.php](file://admin/route/index.php#L1-L111)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [model/runtime.func.php](file://model/runtime.func.php#L1-L82)
- [model/kv.func.php](file://model/kv.func.php#L1-L82)

章节来源
- [route/my.php](file://route/my.php#L1-L126)
- [route/user.php](file://route/user.php#L1-L409)
- [admin/route/index.php](file://admin/route/index.php#L1-L111)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/misc.func.php](file://model/misc.func.php#L1-L284)
- [model/runtime.func.php](file://model/runtime.func.php#L1-L82)
- [model/kv.func.php](file://model/kv.func.php#L1-L82)

## 性能考量
- 缓存策略
  - 用户信息读取支持静态缓存与缓存层，减少数据库压力
  - 运行时统计在请求结束时持久化，避免频繁读写
- I/O优化
  - 头像上传限制文件大小，避免大文件写入
  - 统一响应message在AJAX场景直接输出JSON，减少模板渲染开销
- 数据库与网络
  - 管理后台统计项尽量使用计数函数与运行时数据，避免复杂JOIN
  - SMTP发送验证码异步化，失败记录日志便于追踪

## 故障排查指南
- 统一响应与错误码
  - 统一响应结构：包含code、message与额外数据
  - 错误码约定：小于0为全局错误；等于0为成功；大于0为业务错误（可定位到具体字段）
- 常见问题
  - 登录失败：检查邮箱/用户名是否存在、密码校验是否通过、登录次数与IP更新是否成功
  - 注册失败：检查邮箱/用户名唯一性、密码强度、验证码是否匹配
  - 修改密码失败：确认旧密码正确、新密码与重复输入一致、更新是否成功
  - 头像上传失败：检查Base64数据、文件大小限制、目录创建与写入权限
  - 发送验证码失败：检查SMTP配置、邮件发送返回值、日志记录
- 调试工具
  - 管理后台PHPINFO：/admin/index-phpinfo（注意隐藏敏感配置）
  - 版本检查：管理后台首页包含版本检查脚本，用于获取最新版本信息

章节来源
- [model/misc.func.php](file://model/misc.func.php#L91-L124)
- [admin/route/index.php](file://admin/route/index.php#L50-L57)
- [admin/route/index.php](file://admin/route/index.php#L96-L108)
- [view/htm/message.htm](file://view/htm/message.htm#L1-L25)

## 结论
本系统API围绕用户中心、浏览器检测、系统状态与统计数据查询构建，采用统一的路由-模型-视图架构与message统一响应机制，具备清晰的错误码约定与调试工具。通过缓存与运行时统计优化性能，满足中小型站点的日常运营需求。建议在生产环境中进一步完善鉴权、限流与监控，并对敏感配置与日志进行隔离与保护。

## 附录

### API版本管理
- 版本号来源：conf/conf.default.php中的version字段
- 建议：在管理后台首页展示当前版本，结合版本检查脚本获取最新版本信息

章节来源
- [conf/conf.default.php](file://conf/conf.default.php#L119-L120)
- [admin/route/index.php](file://admin/route/index.php#L96-L108)

### 错误码定义
- 统一响应结构：code、message、extra
- 错误码语义：小于0为全局错误；等于0为成功；大于0为业务错误（字段级）

章节来源
- [model/misc.func.php](file://model/misc.func.php#L91-L124)

### 调试工具使用指南
- 管理后台PHPINFO：/admin/index-phpinfo（查看PHP配置与扩展）
- 统一消息页：view/htm/message.htm（查看统一响应输出）
- 日志：SMTP发送失败会记录日志，便于定位问题

章节来源
- [admin/route/index.php](file://admin/route/index.php#L50-L57)
- [view/htm/message.htm](file://view/htm/message.htm#L1-L25)