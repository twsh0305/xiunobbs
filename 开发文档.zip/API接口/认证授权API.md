# 认证授权API

<cite>
**本文档引用的文件**
- [model/session.func.php](file://model/session.func.php)
- [model/user.func.php](file://model/user.func.php)
- [route/user.php](file://route/user.php)
- [admin/route/user.php](file://admin/route/user.php)
- [model/check.func.php](file://model/check.func.php)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php)
- [xiunophp/xn_html_safe.func.php](file://xiunophp/xn_html_safe.func.php)
- [xiunophp/db.func.php](file://xiunophp/db.func.php)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php)
- [conf/conf.default.php](file://conf/conf.default.php)
- [view/htm/user_login.htm](file://view/htm/user_login.htm)
- [view/htm/user_create.htm](file://view/htm/user_create.htm)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)
10. [附录](#附录)

## 简介
本文件面向系统认证与授权机制，提供完整的API文档与实现细节说明。重点覆盖以下方面：
- 会话管理：Cookie与Session持久化、在线状态统计、会话垃圾回收
- Token生成与验证：自动登录Token、跨系统同步登录Token、Token有效期与一致性校验
- 登录认证与权限检查：用户名/邮箱登录、密码校验、登录状态维护
- 访问控制：基于用户组与权限的访问过滤
- 安全特性：Cookie安全标志、XSS过滤、输入校验、SQL注入防护
- 扩展认证：同步登录接口、第三方登录接入思路

## 项目结构
围绕认证授权的关键模块分布如下：
- 路由层：用户相关路由处理（登录、注册、登出、验证码发送、同步登录）
- 模型层：用户模型、会话模型、输入校验、加密工具、HTML安全过滤
- 配置层：Cookie域与路径、会话保持时长、在线更新间隔等安全相关配置
- 视图层：登录与注册页面模板及前端脚本

```mermaid
graph TB
subgraph "视图层"
V1["登录页<br/>view/htm/user_login.htm"]
V2["注册页<br/>view/htm/user_create.htm"]
end
subgraph "路由层"
R1["用户路由<br/>route/user.php"]
R2["后台用户路由<br/>admin/route/user.php"]
end
subgraph "模型层"
M1["用户模型<br/>model/user.func.php"]
M2["会话模型<br/>model/session.func.php"]
M3["输入校验<br/>model/check.func.php"]
M4["加密工具<br/>xiunophp/xn_encrypt.func.php"]
M5["HTML安全过滤<br/>xiunophp/xn_html_safe.func.php"]
M6["数据库封装<br/>xiunophp/db.func.php"]
M7["PDO MySQL实现<br/>xiunophp/db_pdo_mysql.class.php"]
end
subgraph "配置层"
C1["默认配置<br/>conf/conf.default.php"]
end
V1 --> R1
V2 --> R1
R1 --> M1
R1 --> M2
R1 --> M3
R1 --> M4
R1 --> M5
R1 --> M6
M6 --> M7
C1 -.-> M2
C1 -.-> M4
```

**图表来源**
- [route/user.php](file://route/user.php#L1-L409)
- [admin/route/user.php](file://admin/route/user.php#L1-L198)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/session.func.php](file://model/session.func.php#L1-L246)
- [model/check.func.php](file://model/check.func.php#L1-L73)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L1-L160)
- [xiunophp/xn_html_safe.func.php](file://xiunophp/xn_html_safe.func.php#L1-L800)
- [xiunophp/db.func.php](file://xiunophp/db.func.php#L1-L58)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php#L113-L156)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)

**章节来源**
- [route/user.php](file://route/user.php#L1-L409)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/session.func.php](file://model/session.func.php#L1-L246)
- [model/check.func.php](file://model/check.func.php#L1-L73)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L1-L160)
- [xiunophp/xn_html_safe.func.php](file://xiunophp/xn_html_safe.func.php#L1-L800)
- [xiunophp/db.func.php](file://xiunophp/db.func.php#L1-L58)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php#L113-L156)
- [conf/conf.default.php](file://conf/conf.default.php#L1-L123)

## 核心组件
- 会话管理器：负责Cookie与Session生命周期、数据持久化、在线统计与垃圾回收
- 用户模型：用户读取、创建、更新、密码校验、Token生成与校验、登录状态检查
- 输入校验：邮箱、用户名、密码格式与长度校验
- 加密工具：对称加密/解密、安全Key生成、URL安全编码
- HTML安全过滤：标签与属性白名单、CSS过滤、XSS防护
- 数据库访问：PDO封装与MySQL实现，统一错误处理

**章节来源**
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [model/user.func.php](file://model/user.func.php#L301-L377)
- [model/check.func.php](file://model/check.func.php#L21-L69)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L15-L48)
- [xiunophp/xn_html_safe.func.php](file://xiunophp/xn_html_safe.func.php#L1311-L1760)
- [xiunophp/db.func.php](file://xiunophp/db.func.php#L1-L58)

## 架构总览
认证授权的整体流程包括：用户提交凭据 → 路由层接收并校验 → 模型层进行身份验证与状态维护 → 会话模型持久化 → 返回结果。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant View as "登录页<br/>view/htm/user_login.htm"
participant Route as "用户路由<br/>route/user.php"
participant Model as "用户模型<br/>model/user.func.php"
participant Session as "会话模型<br/>model/session.func.php"
participant DB as "数据库"
Client->>View : 打开登录页
View->>Route : 提交登录表单(邮箱/用户名, 密码)
Route->>Model : 校验邮箱/用户名与密码
Model->>DB : 查询用户信息
DB-->>Model : 返回用户记录
Model-->>Route : 校验通过
Route->>Session : 写入会话(uid, ip, ua)
Session->>DB : 插入/更新session表
DB-->>Session : 成功
Session-->>Route : 会话持久化完成
Route-->>Client : 登录成功(含消息/跳转)
```

**图表来源**
- [view/htm/user_login.htm](file://view/htm/user_login.htm#L1-L100)
- [route/user.php](file://route/user.php#L53-L107)
- [model/user.func.php](file://model/user.func.php#L380-L429)
- [model/session.func.php](file://model/session.func.php#L99-L169)
- [xiunophp/db.func.php](file://xiunophp/db.func.php#L49-L58)

**章节来源**
- [view/htm/user_login.htm](file://view/htm/user_login.htm#L60-L98)
- [route/user.php](file://route/user.php#L53-L107)
- [model/user.func.php](file://model/user.func.php#L380-L429)
- [model/session.func.php](file://model/session.func.php#L99-L169)

## 详细组件分析

### 会话管理（Cookie与Session）
- Cookie策略
  - 名称：bbs_sid
  - 仅限HttpOnly，禁止JS访问，降低XSS风险
  - Secure关闭（仅HTTPS启用），允许Cookie在非HTTPS下传输
  - 有效期：1000天
  - 路径与域：空值表示当前目录与子目录
- Session生命周期
  - 启动：设置Save Handler为自定义函数，启动session
  - 读取：根据sid查询session与session_data，合并到全局会话
  - 写入：合并uid/fid等必要字段，按延迟更新策略写入
  - 销毁：删除对应sid的两条表记录
  - 垃圾回收：按gc概率与阈值清理过期会话
- 在线统计
  - 在线人数：直接统计session表
  - 在线列表：缓存最近活跃用户，包含用户名、组、IP、最后在线时间

```mermaid
flowchart TD
Start(["会话启动"]) --> SetHandler["设置自定义Session处理器"]
SetHandler --> StartSession["启动Session"]
StartSession --> Read["读取sid并查询session/session_data"]
Read --> Decode["解析会话数据到全局会话"]
Decode --> Write["写入会话(合并uid/fid等)"]
Write --> DelayUpdate{"延迟更新策略?"}
DelayUpdate --> |是| PartialUpdate["仅更新部分字段"]
DelayUpdate --> |否| FullUpdate["完整更新"]
PartialUpdate --> Persist["持久化到数据库"]
FullUpdate --> Persist
Persist --> Destroy["销毁会话(删除记录)"]
Persist --> GC["垃圾回收(过期清理)"]
Destroy --> End(["结束"])
GC --> End
```

**图表来源**
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [model/session.func.php](file://model/session.func.php#L28-L52)
- [model/session.func.php](file://model/session.func.php#L105-L169)
- [model/session.func.php](file://model/session.func.php#L171-L185)

**章节来源**
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [model/session.func.php](file://model/session.func.php#L28-L52)
- [model/session.func.php](file://model/session.func.php#L105-L169)
- [model/session.func.php](file://model/session.func.php#L171-L185)

### 用户认证与Token机制
- 登录流程
  - 接收邮箱或用户名与密码
  - 根据类型查询用户，校验密码哈希
  - 更新登录IP、时间与次数
  - 写入全局uid到会话，设置自动登录Token
- 自动登录Token
  - 生成：包含客户端IP、时间戳、uid、密码摘要
  - 校验：解密后验证时间窗口与密码一致性
  - 使用：用于sid过期后的自动登录
- 同步登录（跨系统）
  - 接收token与return_url
  - 解密校验UA一致性
  - 若已登录，将用户信息加密回传至return_url

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Route as "用户路由<br/>route/user.php"
participant Model as "用户模型<br/>model/user.func.php"
participant Session as "会话模型<br/>model/session.func.php"
participant Encrypt as "加密工具<br/>xn_encrypt.func.php"
Client->>Route : POST 登录(邮箱/用户名, 密码)
Route->>Model : 校验凭据
Model-->>Route : 校验通过
Route->>Session : 写入会话(uid)
Route->>Model : 生成自动登录Token
Model->>Encrypt : 对称加密生成token
Encrypt-->>Model : 返回加密token
Model-->>Route : 设置Cookie(bbs_token)
Route-->>Client : 登录成功
```

**图表来源**
- [route/user.php](file://route/user.php#L69-L107)
- [model/user.func.php](file://model/user.func.php#L380-L429)
- [model/user.func.php](file://model/user.func.php#L348-L377)
- [model/session.func.php](file://model/session.func.php#L99-L169)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

**章节来源**
- [route/user.php](file://route/user.php#L69-L107)
- [model/user.func.php](file://model/user.func.php#L380-L429)
- [model/user.func.php](file://model/user.func.php#L348-L377)
- [model/session.func.php](file://model/session.func.php#L99-L169)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

### 注册与验证码
- 注册流程
  - 校验邮箱/用户名唯一性与格式
  - 可选邮箱验证码（需先发送）
  - 生成盐值与密码哈希，创建用户
  - 写入会话并设置自动登录Token
- 验证码发送
  - 支持注册与重置密码两种场景
  - 将随机码写入会话，通过SMTP发送

```mermaid
sequenceDiagram
participant Client as "客户端"
participant View as "注册页<br/>view/htm/user_create.htm"
participant Route as "用户路由<br/>route/user.php"
participant Model as "用户模型<br/>model/user.func.php"
participant SMTP as "邮件服务"
Client->>View : 打开注册页
View->>Route : 提交注册(邮箱, 用户名, 密码)
Route->>Model : 校验唯一性与格式
Model-->>Route : 通过
Route->>SMTP : 发送验证码
SMTP-->>Route : 发送成功
Route->>Model : 创建用户并写入会话
Model-->>Route : 返回成功
Route-->>Client : 注册成功
```

**图表来源**
- [view/htm/user_create.htm](file://view/htm/user_create.htm#L1-L151)
- [route/user.php](file://route/user.php#L109-L189)
- [model/user.func.php](file://model/user.func.php#L41-L52)

**章节来源**
- [view/htm/user_create.htm](file://view/htm/user_create.htm#L97-L149)
- [route/user.php](file://route/user.php#L109-L189)
- [model/user.func.php](file://model/user.func.php#L41-L52)

### 权限检查与访问控制
- 登录检查
  - 未登录重定向至登录页
- 权限过滤
  - 帖子列表访问过滤：根据用户组与版块权限过滤不可见主题
- 管理后台
  - 用户列表、创建、更新、删除等操作均进行权限校验与数据校验

```mermaid
flowchart TD
A["进入受保护页面"] --> B{"是否已登录?"}
B --> |否| C["重定向到登录页"]
B --> |是| D["根据用户组/权限过滤内容"]
D --> E["渲染页面"]
```

**图表来源**
- [model/user.func.php](file://model/user.func.php#L380-L389)
- [route/user.php](file://route/user.php#L47-L48)
- [admin/route/user.php](file://admin/route/user.php#L9-L44)

**章节来源**
- [model/user.func.php](file://model/user.func.php#L380-L389)
- [route/user.php](file://route/user.php#L47-L48)
- [admin/route/user.php](file://admin/route/user.php#L9-L44)

### 安全特性与防护
- CSRF防护
  - 通过Token机制与UA校验实现跨系统同步登录的安全性
  - 建议在表单中增加CSRF Token并在服务端校验
- XSS防护
  - 使用HTML安全过滤器对富文本进行白名单与CSS过滤
  - Cookie HttpOnly开启，阻止JavaScript读取
- SQL注入防护
  - 使用PDO封装与参数化执行，避免字符串拼接
- 输入校验
  - 邮箱、用户名、密码格式与长度严格校验

```mermaid
classDiagram
class 安全防护 {
+CSRF校验(Token+UA)
+XSS过滤(HTML白名单/CSS过滤)
+SQL注入防护(PDO/参数化)
+输入校验(邮箱/用户名/密码)
}
class 加密工具 {
+对称加密/解密
+安全Key生成
+URL安全编码
}
class HTML安全过滤 {
+标签与属性白名单
+CSS注释移除
+危险字符过滤
}
安全防护 --> 加密工具 : "Token/同步登录"
安全防护 --> HTML安全过滤 : "输出净化"
```

**图表来源**
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L15-L48)
- [xiunophp/xn_html_safe.func.php](file://xiunophp/xn_html_safe.func.php#L1311-L1760)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php#L113-L156)
- [model/check.func.php](file://model/check.func.php#L21-L69)

**章节来源**
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L15-L48)
- [xiunophp/xn_html_safe.func.php](file://xiunophp/xn_html_safe.func.php#L1311-L1760)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php#L113-L156)
- [model/check.func.php](file://model/check.func.php#L21-L69)

### 第三方登录与OAuth集成
- 同步登录接口
  - 接口：/user-synlogin
  - 参数：token（加密的用户信息）、return_url（回调地址）
  - 校验：解密token并校验UA一致性
  - 行为：若已登录，将用户信息加密回传至return_url；否则重定向登录
- OAuth集成建议
  - 通过同步登录接口实现第三方登录后的用户信息回传
  - 建议在第三方回调后生成短期Token并跳转至同步登录接口

```mermaid
sequenceDiagram
participant Third as "第三方平台"
participant Route as "用户路由<br/>route/user.php"
participant Encrypt as "加密工具<br/>xn_encrypt.func.php"
participant Client as "客户端"
Third->>Route : 回调携带用户信息
Route->>Encrypt : 解密token并校验UA
Encrypt-->>Route : 校验通过
Route->>Client : 重定向至return_url并附带加密用户信息
Client-->>Third : 接收用户信息
```

**图表来源**
- [route/user.php](file://route/user.php#L364-L400)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

**章节来源**
- [route/user.php](file://route/user.php#L364-L400)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L37-L48)

## 依赖关系分析
- 路由依赖模型与会话
  - 用户路由依赖用户模型进行登录/注册/验证码等处理
  - 依赖会话模型进行会话持久化
- 模型依赖工具与数据库
  - 用户模型依赖加密工具生成Token
  - 依赖数据库封装与PDO实现进行数据访问
- 配置影响行为
  - Cookie域与路径、会话保持时长、在线更新间隔等配置影响安全与性能

```mermaid
graph LR
RouteUser["用户路由<br/>route/user.php"] --> UserModel["用户模型<br/>model/user.func.php"]
RouteUser --> SessionModel["会话模型<br/>model/session.func.php"]
UserModel --> Encrypt["加密工具<br/>xn_encrypt.func.php"]
UserModel --> DBFunc["数据库封装<br/>xiunophp/db.func.php"]
DBFunc --> DBMySQL["PDO MySQL实现<br/>xiunophp/db_pdo_mysql.class.php"]
Config["配置<br/>conf/conf.default.php"] --> SessionModel
Config --> Encrypt
```

**图表来源**
- [route/user.php](file://route/user.php#L1-L409)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/session.func.php](file://model/session.func.php#L1-L246)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L1-L160)
- [xiunophp/db.func.php](file://xiunophp/db.func.php#L1-L58)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php#L113-L156)
- [conf/conf.default.php](file://conf/conf.default.php#L85-L94)

**章节来源**
- [route/user.php](file://route/user.php#L1-L409)
- [model/user.func.php](file://model/user.func.php#L1-L434)
- [model/session.func.php](file://model/session.func.php#L1-L246)
- [xiunophp/xn_encrypt.func.php](file://xiunophp/xn_encrypt.func.php#L1-L160)
- [xiunophp/db.func.php](file://xiunophp/db.func.php#L1-L58)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php#L113-L156)
- [conf/conf.default.php](file://conf/conf.default.php#L85-L94)

## 性能考量
- 会话延迟更新
  - 通过配置项控制，减少频繁更新useragent/url字段带来的写压力
- 在线统计缓存
  - 在线列表缓存5分钟，降低数据库查询频率
- 数据库连接与日志
  - PDO封装统一错误处理，便于定位慢查询与异常

**章节来源**
- [model/session.func.php](file://model/session.func.php#L139-L145)
- [model/session.func.php](file://model/session.func.php#L226-L244)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php#L113-L156)

## 故障排查指南
- 登录失败
  - 检查邮箱/用户名是否存在、密码是否正确
  - 确认会话写入是否成功（查看session表）
- Token失效
  - 校验时间窗口与密码一致性
  - 确认auth_key一致且未被篡改
- XSS显示异常
  - 检查HTML安全过滤是否生效
  - 确认输出前经过净化
- SQL错误
  - 查看PDO错误日志与异常栈
  - 确认SQL语句与参数绑定

**章节来源**
- [route/user.php](file://route/user.php#L73-L87)
- [model/user.func.php](file://model/user.func.php#L316-L345)
- [xiunophp/xn_html_safe.func.php](file://xiunophp/xn_html_safe.func.php#L1311-L1760)
- [xiunophp/db_pdo_mysql.class.php](file://xiunophp/db_pdo_mysql.class.php#L113-L156)

## 结论
本系统通过自定义Session处理器、严格的输入校验、对称加密与HTML安全过滤，构建了较为完善的认证与授权体系。配合延迟更新与缓存策略，在保证安全性的同时兼顾性能。建议在现有基础上进一步完善CSRF Token与第三方OAuth接入规范，以满足更复杂的业务场景。

## 附录
- 关键配置项
  - Cookie域与路径、会话保持时长、在线更新间隔、上传路径与URL等
- 前端交互
  - 登录页与注册页通过MD5加密密码后提交，确保传输安全

**章节来源**
- [conf/conf.default.php](file://conf/conf.default.php#L85-L94)
- [view/htm/user_login.htm](file://view/htm/user_login.htm#L58-L98)
- [view/htm/user_create.htm](file://view/htm/user_create.htm#L95-L149)