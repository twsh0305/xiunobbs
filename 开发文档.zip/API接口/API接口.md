# API接口

<cite>
**本文引用的文件**
- [index.php](file://index.php)
- [index.inc.php](file://index.inc.php)
- [model.inc.php](file://model.inc.php)
- [route/index.php](file://route/index.php)
- [route/user.php](file://route/user.php)
- [route/thread.php](file://route/thread.php)
- [route/post.php](file://route/post.php)
- [route/forum.php](file://route/forum.php)
- [model/user.func.php](file://model/user.func.php)
- [model/thread.func.php](file://model/thread.func.php)
- [model/post.func.php](file://model/post.func.php)
- [model/session.func.php](file://model/session.func.php)
- [admin/admin.func.php](file://admin/admin.func.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考量](#性能考量)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)
10. [附录](#附录)

## 简介
本文件为 XiunoBBS 4.0 的 API 接口文档，聚焦于面向客户端的公开 REST 风格端点与交互流程。文档覆盖以下要点：
- 公开端点清单：HTTP 方法、URL 模式、请求参数、响应格式
- 认证与授权：会话 Cookie、Token 登录、管理员 Token、权限控制
- 数据校验与输入约束：长度、类型、范围等
- API 版本管理与兼容策略：版本号、配置兼容
- 性能与优化：缓存、延迟更新、分页、视图计数策略
- 故障排除：常见错误码与处理建议

注意：本版本仓库未提供独立的“API SDK”或“OpenAPI 规范文件”，本文档基于现有路由与模型代码进行归纳总结。

## 项目结构
围绕 API 的关键文件与职责如下：
- 入口与路由分发
  - index.php：应用入口，加载配置、初始化框架与路由
  - index.inc.php：全局上下文初始化（语言、用户组、论坛、会话、路由分发）
  - model.inc.php：模型聚合与压缩加载
- 路由层
  - route/user.php：用户相关接口（登录、注册、登出、重置密码、验证码、同步登录）
  - route/thread.php：主题相关接口（创建主题、主题详情）
  - route/post.php：回帖相关接口（创建、编辑、删除）
  - route/forum.php：版块主题列表
  - route/index.php：首页主题列表
- 模型层
  - model/session.func.php：会话与 Cookie 策略、在线统计
  - model/user.func.php：用户读写、Token 生成/校验
  - model/thread.func.php：主题创建/读取/更新/删除、视图计数
  - model/post.func.php：回帖创建/更新/删除、消息格式化

```mermaid
graph TB
A["index.php<br/>应用入口"] --> B["index.inc.php<br/>上下文初始化"]
B --> C["model.inc.php<br/>模型聚合"]
B --> D["路由分发<br/>route/*.php"]
D --> D1["route/user.php<br/>用户接口"]
D --> D2["route/thread.php<br/>主题接口"]
D --> D3["route/post.php<br/>回帖接口"]
D --> D4["route/forum.php<br/>版块接口"]
D --> D5["route/index.php<br/>首页接口"]
D1 --> E1["model/user.func.php<br/>用户/Token"]
D2 --> E2["model/thread.func.php<br/>主题"]
D3 --> E3["model/post.func.php<br/>回帖"]
D1 --> F1["model/session.func.php<br/>会话/Cookie"]
D2 --> F1
D3 --> F1
D4 --> F1
```

图表来源
- [index.php](file://index.php#L24-L52)
- [index.inc.php](file://index.inc.php#L49-L80)
- [model.inc.php](file://model.inc.php#L10-L62)
- [route/user.php](file://route/user.php#L1-L409)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [route/forum.php](file://route/forum.php#L1-L46)
- [route/index.php](file://route/index.php#L1-L49)
- [model/user.func.php](file://model/user.func.php#L316-L362)
- [model/thread.func.php](file://model/thread.func.php#L48-L118)
- [model/post.func.php](file://model/post.func.php#L50-L89)
- [model/session.func.php](file://model/session.func.php#L187-L220)

章节来源
- [index.php](file://index.php#L24-L52)
- [index.inc.php](file://index.inc.php#L49-L80)
- [model.inc.php](file://model.inc.php#L10-L62)

## 核心组件
- 会话与认证
  - 会话：基于 Cookie 名称 bbs_sid 的 PHP 原生命中会话，持久化存储于数据库表，支持延迟更新以降低写压力
  - Token 登录：用户登录后生成 bbs_token Cookie，用于后续接口调用的身份识别
  - 管理员 Token：后台管理使用 bbs_admin_token，具备绑定 IP 或用户代理的校验与有效期
- 权限控制
  - 用户组与版块访问权限：按 gid 与版块 access 控制（允许阅读、发帖、删贴、移动等）
  - 登录检查：多数写操作需登录态（如主题/回帖创建、编辑、删除）

章节来源
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [model/user.func.php](file://model/user.func.php#L316-L362)
- [admin/admin.func.php](file://admin/admin.func.php#L8-L44)
- [route/thread.php](file://route/thread.php#L14-L14)
- [route/post.php](file://route/post.php#L7-L7)

## 架构总览
下图展示一次典型“主题详情”请求的端到端流程，包括会话/Token 校验、权限过滤与数据渲染。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Router as "路由 : thread.php"
participant Session as "会话 : session.func.php"
participant Model as "模型 : thread.func.php/post.func.php"
participant View as "视图 : thread.htm"
Client->>Router : GET /thread-{tid}-{page}
Router->>Session : 读取/校验会话/Token
Session-->>Router : 当前用户(uid,gid)
Router->>Model : thread_read(tid)/post_find_by_tid(tid,page)
Model-->>Router : 主题/回帖数据
Router->>Router : 权限校验(allowread/allowpost)
Router->>View : 渲染模板并输出
View-->>Client : HTML 响应
```

图表来源
- [route/thread.php](file://route/thread.php#L80-L142)
- [model/thread.func.php](file://model/thread.func.php#L158-L164)
- [model/post.func.php](file://model/post.func.php#L199-L200)
- [model/session.func.php](file://model/session.func.php#L187-L220)

## 详细组件分析

### 用户接口（route/user.php）
- 登录
  - 方法：POST
  - URL：/user-login
  - 请求参数
    - email：邮箱或用户名
    - password：明文密码（服务端做盐值哈希校验）
  - 成功响应：返回通用消息结构，包含 token 字段（见“响应格式”）
  - 失败响应：返回错误码与提示
  - 认证方式：登录成功后设置 bbs_sid 会话 Cookie；同时生成 bbs_token Cookie
- 注册
  - 方法：GET/POST
  - URL：/user-create
  - 请求参数
    - email、username、password、code（可选，启用邮箱验证码时）
  - 成功响应：返回通用消息结构，携带 token
  - 失败响应：返回错误码与提示
- 登出
  - 方法：GET
  - URL：/user-logout
  - 行为：清空会话与 bbs_token
- 重置密码（步骤一：获取验证码）
  - 方法：POST
  - URL：/user-send_code-user_resetpw
  - 请求参数：email
  - 成功响应：发送成功
- 重置密码（步骤二：校验验证码）
  - 方法：POST
  - URL：/user-resetpw
  - 请求参数：email、code
  - 成功响应：继续下一步
- 重置密码（步骤三：完成）
  - 方法：POST
  - URL：/user-resetpw_complete
  - 请求参数：password
  - 成功响应：修改成功
- 同步登录（外部系统回调）
  - 方法：GET
  - URL：/user-synlogin?token=...&return_url=...
  - 行为：校验 token，若已登录则加密返回用户信息并跳转回源地址

响应格式
- 统一结构：{状态码, 提示信息, 可选数据}
- 示例字段：token、jump、data 等（根据具体接口而定）

章节来源
- [route/user.php](file://route/user.php#L53-L107)
- [route/user.php](file://route/user.php#L109-L188)
- [route/user.php](file://route/user.php#L190-L202)
- [route/user.php](file://route/user.php#L204-L246)
- [route/user.php](file://route/user.php#L249-L293)
- [route/user.php](file://route/user.php#L296-L358)
- [route/user.php](file://route/user.php#L364-L400)
- [model/user.func.php](file://model/user.func.php#L348-L355)

### 主题接口（route/thread.php）
- 创建主题
  - 方法：POST
  - URL：/thread-create
  - 请求参数
    - fid：目标版块 ID
    - subject：标题（最大长度限制）
    - message：内容（最大长度限制）
    - doctype：文档类型（有限制）
  - 成功响应：创建成功
  - 失败响应：返回错误码与提示
- 主题详情
  - 方法：GET
  - URL：/thread-{tid}-{page}
  - 行为：读取主题与回帖列表，处理关键字高亮、分页、权限校验与视图计数

章节来源
- [route/thread.php](file://route/thread.php#L10-L77)
- [route/thread.php](file://route/thread.php#L79-L142)
- [model/thread.func.php](file://model/thread.func.php#L48-L118)
- [model/post.func.php](file://model/post.func.php#L199-L200)

### 回帖接口（route/post.php）
- 创建回帖
  - 方法：POST
  - URL：/post-create-{tid}
  - 请求参数
    - message：内容（最大长度限制）
    - doctype：文档类型
    - quotepid：可选，引用楼层
    - return_html：可选，是否直接返回 HTML
  - 成功响应：创建成功；若 return_html=1 返回回帖 HTML
- 编辑回帖
  - 方法：GET/POST
  - URL：/post-update-{pid}
  - 请求参数（POST）
    - subject：仅首楼可用（标题长度限制）
    - message：内容（最大长度限制）
    - doctype：文档类型
  - 成功响应：更新成功
- 删除回帖
  - 方法：POST
  - URL：/post-delete-{pid}
  - 行为：根据权限与主题状态判断是否允许删除

章节来源
- [route/post.php](file://route/post.php#L11-L99)
- [route/post.php](file://route/post.php#L101-L181)
- [route/post.php](file://route/post.php#L183-L222)
- [model/post.func.php](file://model/post.func.php#L50-L89)
- [model/post.func.php](file://model/post.func.php#L91-L114)

### 版块接口（route/forum.php）
- 版块主题列表
  - 方法：GET
  - URL：/forum-{fid}-{page}?orderby={tid|lastpid}
  - 行为：读取置顶主题与普通主题，处理分页与权限

章节来源
- [route/forum.php](file://route/forum.php#L1-L46)

### 首页接口（route/index.php）
- 首页主题列表
  - 方法：GET
  - URL：/ 或 /index-{page}
  - 行为：按默认排序读取主题列表，处理置顶主题与分页

章节来源
- [route/index.php](file://route/index.php#L1-L49)

## 依赖关系分析
- 路由到模型
  - 用户：user_read、user_create、user_token_* 等
  - 主题：thread_read、thread_create、thread_update、thread_delete、thread_inc_views
  - 回帖：post_read、post_create、post_update、post_delete
  - 会话：sess_*、online_*（用于在线统计）
- 路由到会话/权限
  - 登录检查：user_login_check（在写操作路由中前置）
  - 权限检查：forum_access_user、forum_access_mod、forum_access_user('allowread'|...)

```mermaid
graph LR
U["route/user.php"] --> MU["model/user.func.php"]
T["route/thread.php"] --> MT["model/thread.func.php"]
P["route/post.php"] --> MP["model/post.func.php"]
U --> S["model/session.func.php"]
T --> S
P --> S
F["route/forum.php"] --> S
```

图表来源
- [route/user.php](file://route/user.php#L1-L409)
- [route/thread.php](file://route/thread.php#L1-L146)
- [route/post.php](file://route/post.php#L1-L226)
- [route/forum.php](file://route/forum.php#L1-L46)
- [model/user.func.php](file://model/user.func.php#L316-L362)
- [model/thread.func.php](file://model/thread.func.php#L158-L164)
- [model/post.func.php](file://model/post.func.php#L116-L122)
- [model/session.func.php](file://model/session.func.php#L187-L220)

## 性能考量
- 会话延迟更新
  - 通过延迟更新在线状态与少量字段，降低写入频率，提升吞吐
- 视图计数
  - 默认开启视图计数，但可通过配置选择低优先级更新或关闭，以平衡实时性与性能
- 分页与缓存
  - 主题/回帖列表分页；部分读取使用静态缓存与后端缓存，减少数据库压力
- 在线统计
  - 在线用户列表缓存，定期刷新

章节来源
- [model/session.func.php](file://model/session.func.php#L139-L146)
- [model/thread.func.php](file://model/thread.func.php#L146-L156)
- [model/session.func.php](file://model/session.func.php#L226-L244)

## 故障排除指南
- 常见错误码与含义
  - 通用错误：-1（业务错误）、0（成功）、其他（特定业务错误）
  - 示例场景：邮箱/用户名不存在、密码错误、权限不足、主题/回帖不存在、方法不被允许、验证码错误等
- 登录失败排查
  - 检查 bbs_sid 与 bbs_token 是否正确下发与携带
  - 确认邮箱/用户名与密码格式与长度符合要求
- 权限不足
  - 确认用户组对目标版块的 allowread/allowpost/allowthread/allowupdate/allowdelete 权限
- 数据异常
  - 主题/回帖不存在：确认 tid/pid 是否正确
  - 数据畸形：检查数据一致性与索引完整性

章节来源
- [route/user.php](file://route/user.php#L73-L105)
- [route/thread.php](file://route/thread.php#L48-L56)
- [route/post.php](file://route/post.php#L48-L52)
- [route/post.php](file://route/post.php#L117-L120)

## 结论
本接口文档基于现有路由与模型实现，提供了用户、主题、回帖、版块等核心 REST 端点的规范说明。认证采用会话与 Token 双重机制，权限控制基于用户组与版块访问策略。建议在生产环境中结合会话延迟更新、缓存与分页策略，确保性能与稳定性。

## 附录

### 认证与授权策略
- 会话 Cookie
  - 名称：bbs_sid
  - 属性：HttpOnly、非 Secure（可按部署调整）、较长生命周期
- Token 登录
  - 名称：bbs_token
  - 生成：登录成功后设置
  - 用途：接口调用身份识别
- 管理员 Token
  - 名称：bbs_admin_token
  - 生成：后台登录后设置
  - 校验：结合 IP 与用户代理，有效期约 1 小时，半时刷新
- 权限控制
  - 用户组 gid 与版块 access 控制（允许阅读/发帖/删贴/移动等）
  - 登录检查：写操作需登录态

章节来源
- [model/session.func.php](file://model/session.func.php#L187-L220)
- [model/user.func.php](file://model/user.func.php#L316-L362)
- [admin/admin.func.php](file://admin/admin.func.php#L8-L44)
- [route/thread.php](file://route/thread.php#L14-L14)
- [route/post.php](file://route/post.php#L7-L7)

### 数据验证与输入约束
- 用户
  - 邮箱/用户名唯一性校验
  - 密码强度校验
- 主题
  - subject 长度上限
  - message 长度上限
  - doctype 有限制
- 回帖
  - message 长度上限
  - 首楼 subject 长度上限
- 版块
  - orderby 限定为 tid/lastpid

章节来源
- [route/user.php](file://route/user.php#L130-L155)
- [route/thread.php](file://route/thread.php#L48-L56)
- [route/post.php](file://route/post.php#L148-L155)
- [route/forum.php](file://route/forum.php#L12-L13)

### API 版本管理与兼容
- 版本号：conf 中定义版本号，便于追踪与兼容策略制定
- 配置兼容：旧版本配置项迁移与默认值设定

章节来源
- [index.php](file://index.php#L32-L32)
- [index.php](file://index.php#L27-L32)

### 客户端集成与调用示例（说明性）
- 登录
  - 步骤：提交邮箱/用户名与密码 → 成功后读取 bbs_sid 与 bbs_token → 后续接口携带 bbs_token
- 注册
  - 步骤：提交邮箱/用户名/密码 → 可选先获取验证码 → 提交验证码 → 成功后携带 token
- 创建主题
  - 步骤：登录 → 准备 fid/subject/message → 提交 → 成功后获得提示
- 创建回帖
  - 步骤：登录 → 准备 tid/message → 可选 return_html → 提交 → 成功后获得提示或 HTML
- 删除/编辑
  - 步骤：登录 → 检查权限 → 提交 → 成功后获得提示

（以上为流程说明，不包含具体代码片段）

### 限流、缓存与性能优化建议
- 限流：可在网关或应用层引入基于 IP/用户/接口维度的限流策略
- 缓存：利用现有缓存与静态缓存（如在线列表、用户信息），减少数据库压力
- 分页：严格使用分页参数，避免一次性拉取大量数据
- 视图计数：根据业务需求选择实时更新或延迟更新

（本节为通用建议，不涉及具体文件分析）