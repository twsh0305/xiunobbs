# 版块导航与SEO

<cite>
**本文档引用的文件**
- [model/forum.func.php](file://model/forum.func.php)
- [route/forum.php](file://route/forum.php)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm)
- [admin/view/htm/header_nav.inc.htm](file://admin/view/htm/header_nav.inc.htm)
- [view/htm/footer_nav.inc.htm](file://view/htm/footer_nav.inc.htm)
- [view/htm/index.htm](file://view/htm/index.htm)
- [view/htm/forum.htm](file://view/htm/forum.htm)
- [model/thread.func.php](file://model/thread.func.php)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php)
- [model/kv.func.php](file://model/kv.func.php)
- [model/runtime.func.php](file://model/runtime.func.php)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构总览](#架构总览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考虑](#性能考虑)
8. [故障排查指南](#故障排查指南)
9. [结论](#结论)
10. [附录](#附录)

## 简介
本文件聚焦于“版块导航与SEO优化”主题，系统阐述以下内容：
- 版块导航菜单的生成机制与多级结构
- 面包屑导航的实现与交互
- SEO友好的URL设计、页面标题与描述优化
- 导航缓存机制与性能优化策略
- 导航响应式设计与可访问性
- 导航数据结构、渲染流程与扩展机制

## 项目结构
围绕导航与SEO的关键文件分布如下：
- 路由层：负责接收请求、解析参数、加载数据并设置页面元信息
- 模型层：提供版块、主题、用户等数据的读取、格式化与缓存
- 视图层：提供头部导航、面包屑、页脚等UI模板
- 缓存层：提供统一的缓存接口，支撑导航与运行时数据的高性能读取

```mermaid
graph TB
RouteForum["路由: route/forum.php"] --> ModelForum["模型: model/forum.func.php"]
RouteForum --> ModelThread["模型: model/thread.func.php"]
ModelForum --> Cache["缓存: xiunophp/cache.func.php"]
ModelThread --> Cache
ModelForum --> KV["持久化KV: model/kv.func.php"]
ModelThread --> Runtime["运行时统计: model/runtime.func.php"]
ViewHeader["视图: view/htm/header_nav.inc.htm"] --> RouteForum
ViewForum["视图: view/htm/forum.htm"] --> RouteForum
ViewFooter["视图: view/htm/footer_nav.inc.htm"] --> RouteForum
AdminHeader["视图: admin/view/htm/header_nav.inc.htm"] --> RouteForum
```

**图表来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/thread.func.php](file://model/thread.func.php#L210-L275)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L23-L57)
- [model/kv.func.php](file://model/kv.func.php#L37-L53)
- [model/runtime.func.php](file://model/runtime.func.php#L5-L27)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L35-L69)
- [view/htm/forum.htm](file://view/htm/forum.htm#L8-L15)
- [view/htm/footer_nav.inc.htm](file://view/htm/footer_nav.inc.htm#L1-L16)
- [admin/view/htm/header_nav.inc.htm](file://admin/view/htm/header_nav.inc.htm#L24-L61)

**章节来源**
- [route/forum.php](file://route/forum.php#L1-L46)
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/thread.func.php](file://model/thread.func.php#L210-L275)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L23-L57)
- [model/kv.func.php](file://model/kv.func.php#L37-L53)
- [model/runtime.func.php](file://model/runtime.func.php#L5-L27)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L35-L69)
- [view/htm/forum.htm](file://view/htm/forum.htm#L8-L15)
- [view/htm/footer_nav.inc.htm](file://view/htm/footer_nav.inc.htm#L1-L16)
- [admin/view/htm/header_nav.inc.htm](file://admin/view/htm/header_nav.inc.htm#L24-L61)

## 核心组件
- 版块数据与缓存
  - 版块列表缓存：通过统一缓存接口读取/写入，避免每次请求重复查询数据库
  - 版块读取与格式化：提供图标URL、访问权限列表、版主列表等字段
  - 访问控制过滤：根据用户组权限对版块列表进行过滤
- 主题列表与分页
  - 支持按创建时间或最后回复时间排序
  - 分页组件与URL构造
- 页面元信息（SEO）
  - 标题：优先使用版块自定义SEO标题，否则使用“版块名-站点名”
  - 描述：使用版块简介
  - 关键词：预留字段（当前为空）
- 导航渲染
  - 头部导航：PC端/移动端通用，包含首页链接、版块列表、用户操作
  - 面包屑：版块详情页展示当前位置
  - 页脚：通用信息与性能指标

**章节来源**
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/forum.func.php](file://model/forum.func.php#L104-L120)
- [model/forum.func.php](file://model/forum.func.php#L165-L183)
- [route/forum.php](file://route/forum.php#L34-L38)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L35-L69)
- [view/htm/forum.htm](file://view/htm/forum.htm#L8-L15)

## 架构总览
导航与SEO涉及从前端到后端的完整链路：请求进入路由层，路由层调用模型层获取数据并设置页面元信息，随后由视图层渲染导航与内容。

```mermaid
sequenceDiagram
participant U as "用户"
participant R as "路由 : route/forum.php"
participant MF as "模型 : model/forum.func.php"
participant MT as "模型 : model/thread.func.php"
participant C as "缓存 : xiunophp/cache.func.php"
participant V as "视图 : view/htm/forum.htm"
U->>R : 请求版块页
R->>MF : 读取版块信息
MF->>C : 读取/写入版块列表缓存
MF-->>R : 返回格式化后的版块数据
R->>MT : 加载主题列表与分页
MT->>C : 读取/写入相关缓存
MT-->>R : 返回主题列表
R->>R : 设置页面标题/描述等SEO信息
R-->>V : 传递数据并渲染
V-->>U : 输出HTML含面包屑、导航
```

**图表来源**
- [route/forum.php](file://route/forum.php#L15-L38)
- [model/forum.func.php](file://model/forum.func.php#L60-L71)
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/thread.func.php](file://model/thread.func.php#L210-L275)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L23-L57)
- [view/htm/forum.htm](file://view/htm/forum.htm#L8-L15)

## 详细组件分析

### 版块导航菜单生成机制
- 数据来源
  - 版块列表来自缓存，若缓存未命中则查询数据库并写入缓存
  - 版块读取时会进行格式化，补充图标URL、访问权限列表、版主列表等
- 渲染逻辑
  - 头部导航模板遍历版块列表，生成导航项，包含链接与名称
  - 使用data-active属性与fid标识当前激活状态，便于前端高亮
- 权限过滤
  - 根据用户组权限对版块列表进行过滤，隐藏无访问权限的版块

```mermaid
flowchart TD
Start(["开始"]) --> LoadCache["读取版块列表缓存"]
LoadCache --> HasCache{"缓存命中？"}
HasCache --> |是| UseCache["使用缓存数据"]
HasCache --> |否| QueryDB["查询数据库"]
QueryDB --> Format["格式化版块数据"]
Format --> SetCache["写入缓存"]
UseCache --> Filter["按权限过滤"]
SetCache --> Filter
Filter --> Render["渲染头部导航"]
Render --> End(["结束"])
```

**图表来源**
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/forum.func.php](file://model/forum.func.php#L104-L120)
- [model/forum.func.php](file://model/forum.func.php#L165-L183)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L41-L47)

**章节来源**
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/forum.func.php](file://model/forum.func.php#L104-L120)
- [model/forum.func.php](file://model/forum.func.php#L165-L183)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L41-L47)

### 面包屑导航实现
- 位置标记
  - 在版块详情页顶部渲染面包屑，包含首页与当前版块路径
  - 面包屑在小屏设备上默认隐藏，以减少占用
- 动态高亮
  - 通过data-active属性与jQuery选择器在渲染后添加active类，突出当前版块

```mermaid
sequenceDiagram
participant V as "视图 : view/htm/forum.htm"
participant U as "用户"
V->>V : 渲染面包屑结构
V-->>U : 展示面包屑导航
Note over V,U : 渲染后执行脚本高亮当前版块
```

**图表来源**
- [view/htm/forum.htm](file://view/htm/forum.htm#L8-L15)
- [view/htm/forum.htm](file://view/htm/forum.htm#L126-L128)

**章节来源**
- [view/htm/forum.htm](file://view/htm/forum.htm#L8-L15)
- [view/htm/forum.htm](file://view/htm/forum.htm#L126-L128)

### 多级导航与层级结构
- 当前实现
  - 导航以“首页-版块”为主，未见深层级子分类的直接渲染
  - 若存在父子版块关系，通常通过版块列表中的fid组织，但模板未显式渲染层级
- 扩展建议
  - 在模型层增加层级计算与扁平转树形结构的方法
  - 在视图层增加递归渲染或条件缩进，以支持多级导航

**章节来源**
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L41-L47)

### SEO友好URL与页面元信息
- URL设计
  - 版块页采用“forum-fid-页码”的伪静态风格，利于搜索引擎抓取与用户记忆
  - 主题列表支持orderby参数切换，形成不同URL以覆盖不同排序场景
- 页面标题与描述
  - 标题优先使用版块自定义SEO标题；否则使用“版块名-站点名”
  - 描述使用版块简介，有助于提升搜索摘要质量
- 关键词
  - 当前预留字段为空；建议结合版块主题与站点特性动态生成

```mermaid
flowchart TD
Req["请求版块页"] --> BuildURL["构建SEO友好URL"]
BuildURL --> SetMeta["设置页面标题/描述"]
SetMeta --> Render["渲染页面"]
Render --> Done["完成"]
```

**图表来源**
- [route/forum.php](file://route/forum.php#L30-L38)
- [route/forum.php](file://route/forum.php#L34-L38)

**章节来源**
- [route/forum.php](file://route/forum.php#L30-L38)
- [route/forum.php](file://route/forum.php#L34-L38)

### 导航缓存机制与性能优化
- 缓存策略
  - 版块列表缓存：读取时若未命中则查询数据库并写入缓存，生命周期为60秒
  - 运行时统计缓存：实时运行数据初始化后写入缓存，请求结束时持久化
  - KV持久化：提供键值对的缓存封装，兼顾内存与持久化
- 性能影响点
  - 版块列表缓存显著降低数据库压力
  - 主题列表分页与排序控制可避免大页扫描
  - 前端高亮脚本仅在渲染后执行一次，开销极低

```mermaid
classDiagram
class ForumModel {
+forum_list_cache()
+forum_list_cache_delete()
+forum_read(fid)
+forum_format(forum)
}
class ThreadModel {
+thread_find_by_fid(fid, page, pagesize, order)
+thread_read_cache(tid)
}
class Cache {
+cache_get(key)
+cache_set(key, value, life)
+cache_delete(key)
}
class KV {
+kv_cache_get(key)
+kv_cache_set(key, value, life)
}
class Runtime {
+runtime_init()
+runtime_get(key)
+runtime_set(key, value)
}
ForumModel --> Cache : "读写版块列表缓存"
ThreadModel --> Cache : "读写主题相关缓存"
KV --> Cache : "KV封装"
Runtime --> Cache : "运行时数据缓存"
```

**图表来源**
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/thread.func.php](file://model/thread.func.php#L167-L174)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L23-L57)
- [model/kv.func.php](file://model/kv.func.php#L37-L53)
- [model/runtime.func.php](file://model/runtime.func.php#L5-L27)

**章节来源**
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/thread.func.php](file://model/thread.func.php#L167-L174)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L23-L57)
- [model/kv.func.php](file://model/kv.func.php#L37-L53)
- [model/runtime.func.php](file://model/runtime.func.php#L5-L27)

### 导航渲染流程与扩展机制
- 渲染流程
  - 路由层准备数据并设置SEO信息
  - 视图层包含头部导航、面包屑、主体内容与页脚
  - 头部导航模板支持钩子，便于插件扩展
- 扩展点
  - 模板钩子：header_nav_forum_start/end、loop_start/end等
  - 路由扩展：$extra参数预留给插件注入额外参数
  - 模型扩展：在读取与格式化阶段插入钩子

```mermaid
sequenceDiagram
participant R as "路由"
participant M as "模型"
participant V as "视图"
R->>M : 读取版块/主题数据
M-->>R : 返回格式化数据
R->>V : 传入数据并渲染
V-->>V : 执行钩子与模板替换
V-->>R : 输出最终HTML
```

**图表来源**
- [route/forum.php](file://route/forum.php#L15-L44)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L9-L69)
- [view/htm/forum.htm](file://view/htm/forum.htm#L3-L124)

**章节来源**
- [route/forum.php](file://route/forum.php#L15-L44)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L9-L69)
- [view/htm/forum.htm](file://view/htm/forum.htm#L3-L124)

### 响应式设计与可访问性
- 响应式
  - 头部导航使用Bootstrap类，移动端通过折叠菜单适配
  - 面包屑在小屏设备默认隐藏，避免拥挤
- 可访问性
  - 导航按钮包含aria-label与aria-controls等语义属性
  - 链接与按钮具备清晰的文本标签

**章节来源**
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L10-L14)
- [view/htm/header_nav.inc.htm](file://view/htm/header_nav.inc.htm#L35-L69)
- [view/htm/forum.htm](file://view/htm/forum.htm#L8-L15)

### 导航样式定制与动画效果
- 定制建议
  - 通过CSS覆盖Bootstrap默认样式，如颜色、间距、字体大小
  - 使用CSS过渡与悬停效果增强交互体验
- 动画建议
  - 折叠菜单使用CSS transition
  - 高亮状态切换使用平滑过渡

[本节为通用指导，无需特定文件引用]

## 依赖关系分析
- 路由依赖模型层提供的数据读取与格式化能力
- 模型层依赖缓存与KV持久化，保障性能与可靠性
- 视图层依赖路由提供的数据与SEO配置

```mermaid
graph LR
Route["route/forum.php"] --> ForumModel["model/forum.func.php"]
Route --> ThreadModel["model/thread.func.php"]
ForumModel --> Cache["xiunophp/cache.func.php"]
ThreadModel --> Cache
ForumModel --> KV["model/kv.func.php"]
ThreadModel --> Runtime["model/runtime.func.php"]
View["view/htm/*"] --> Route
```

**图表来源**
- [route/forum.php](file://route/forum.php#L15-L44)
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/thread.func.php](file://model/thread.func.php#L210-L275)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L23-L57)
- [model/kv.func.php](file://model/kv.func.php#L37-L53)
- [model/runtime.func.php](file://model/runtime.func.php#L5-L27)
- [view/htm/index.htm](file://view/htm/index.htm#L1-L79)
- [view/htm/forum.htm](file://view/htm/forum.htm#L1-L130)

**章节来源**
- [route/forum.php](file://route/forum.php#L15-L44)
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/thread.func.php](file://model/thread.func.php#L210-L275)
- [xiunophp/cache.func.php](file://xiunophp/cache.func.php#L23-L57)
- [model/kv.func.php](file://model/kv.func.php#L37-L53)
- [model/runtime.func.php](file://model/runtime.func.php#L5-L27)
- [view/htm/index.htm](file://view/htm/index.htm#L1-L79)
- [view/htm/forum.htm](file://view/htm/forum.htm#L1-L130)

## 性能考虑
- 缓存优先：尽量利用现有缓存接口，减少数据库查询
- 分页与排序：合理设置分页大小与排序索引，避免全表扫描
- 静态资源：合并与压缩CSS/JS，减少请求数
- CDN：静态资源与图片可使用CDN加速
- 延迟加载：面包屑与侧边信息可在首屏后异步加载

[本节为通用指导，无需特定文件引用]

## 故障排查指南
- 版块列表为空
  - 检查版块列表缓存是否过期或被清空
  - 确认版块数据是否正确写入数据库
- 权限导致的导航缺失
  - 核对用户组权限与版块访问控制设置
- 面包屑不显示
  - 确认模板中面包屑区域未被隐藏
  - 检查当前页面是否为版块详情页
- SEO信息异常
  - 检查路由层是否正确设置标题与描述
  - 确认版块数据中SEO字段是否填写

**章节来源**
- [model/forum.func.php](file://model/forum.func.php#L137-L162)
- [model/forum.func.php](file://model/forum.func.php#L165-L183)
- [view/htm/forum.htm](file://view/htm/forum.htm#L8-L15)
- [route/forum.php](file://route/forum.php#L34-L38)

## 结论
本项目在导航与SEO方面已具备较为完善的实现：基于缓存的高效数据读取、清晰的导航渲染与面包屑、以及可扩展的模板钩子。建议后续在多级导航、关键词填充与更细粒度的SEO配置方面进一步完善，以提升用户体验与搜索引擎表现。

## 附录
- 管理后台导航
  - 管理端头部导航使用独立模板，包含菜单与用户操作入口
- 页脚信息
  - 页脚包含版权与性能指标，便于监控与展示

**章节来源**
- [admin/view/htm/header_nav.inc.htm](file://admin/view/htm/header_nav.inc.htm#L24-L61)
- [view/htm/footer_nav.inc.htm](file://view/htm/footer_nav.inc.htm#L1-L16)